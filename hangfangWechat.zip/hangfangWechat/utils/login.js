function login(url){
  let userInfo = wx.getStorageSync('userInfo');
  if(userInfo.id){
    wx.navigateTo({
      url: url,
    })
  }else{
    wx.showModal({
      title: '提示',
      content: '您还没有登录,是否立即登录?',
      success:function(res){
        if(res.confirm){
          wx.navigateTo({
            url: '/pages/login/index',
          })
        }
      }
    })
  }
}
module.exports = {
  login
}