//远程图片no found情况下指引  
function errImgFun(e, that) {
  var _errImg = e.target.dataset.errImg;
  var _errObj = {};
  var _objImg = "'" + _errImg + "'";
  _errObj[_errImg] = '../uploadDefult.jpg';
  //console.log(e.target.dataset);
  //console.log(e.detail.errMsg + "----" + _errObj[_errImg] + "----" + '.........' + _objImg);
  // console.log(_errObj);
  that.setData(_errObj);
}

module.exports = {
  errImgFun: errImgFun
}
