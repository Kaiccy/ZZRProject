// pages/login/grant/grant.js
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getStorage({
      key: 'loginInfo',
      success: function (res) {
        console.log('获取用户信息');
        console.log(res);
        if (res.data != null){
          // 判决角色进入不同页面
          if (res.data.usertype.code == 1) {
            // 用车人页面
            wx.redirectTo({
              url: '../userTaskList/userTaskList'
            })
          } else if (res.data.usertype.code == 2) {
            // 班长页面
            wx.redirectTo({
              url: '../monitorIndex/monitorIndex'
            })
          } else if (res.data.usertype.code == 3) {
            // 司机页面
            if (res.data.issq == 1){
              //未授权
              wx.redirectTo({
                url: '../driverTaskList/driverTaskList'
              })
            }else{
              //已授权
              wx.redirectTo({
                url: '../AuthorizedDriver/AuthorizedDriver'
              })
            }
          }
        }else{
          getUserInfo();
        }
      },
    })
  },
  
  // 点击授权按钮
  getUserInfo: function (e) {
    var userInfo = e.detail.userInfo; // 点击允许按钮获取到的个人信息+
    if (userInfo) {
      //用户按了允许授权按钮
      wx.showLoading({
        title: '加载中...',
        mask: true
      });

      wx.login({ // 登录获取code
        success: res => {
          let code = res.code;
          let params = {
            code: code
          };
          console.log('code= '+code);
          // 用code向后台换取微信信息
          ajax.POST({
            ajaxPoint: 'AccountWebService/addWxInfo',
            params: params,
            success: function (res) {
              console.log(res.data);
              console.log('以上是新的用户数据');

              if (res.data.retcode == 0){
                // 将获取到的登录信息存储到缓存中
                wx.setStorage({
                  key: 'loginInfo',
                  data: res.data,
                  success: function () {
                    wx.hideLoading();
                  },
                  fail: function (res) {
                    wx.hideLoading();
                  }
                })
                // 判决角色进入不同页面
                if (res.data.uid == null){
                  wx.redirectTo({
                    url: '../login/login'
                  })
                }else{
                  if (res.data.usertype.code == 1) {
                    // 用车人页面
                    wx.redirectTo({
                      url: '../userTaskList/userTaskList'
                    })
                  } else if (res.data.usertype.code == 2){
                    // 班长页面
                    wx.redirectTo({
                      url: '../monitorIndex/monitorIndex'
                    })
                  } else if (res.data.usertype.code == 3){
                    // 司机页面
                    if (res.data.issq == 1) {
                      //未授权
                      wx.redirectTo({
                        url: '../driverTaskList/driverTaskList'
                      })
                    } else {
                      //已授权
                      wx.redirectTo({
                        url: '../AuthorizedDriver/AuthorizedDriver'
                      })
                    }
                  }
                }
              }else{
                wx.hideLoading();
                wx.showToast({
                  title: res.data.meg,
                  icon: 'none'
                })
              }  
            }
          })
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '登录出错,请检查网络',
            icon: 'none',
            mask: true
          })
        }
      })
    } else {
      //用户按了拒绝按钮
      wx.showModal({
        title: '提示',
        content: '小程序需要您的微信授权才能使用哦！'
      })
    }
  }
})