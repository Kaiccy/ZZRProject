// pages/monitorIndex/monitorIndex.js

var dateTimePicker = require('../../utils/dateTimePicker.js');
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    department:[],
    users:[],
    drivers:[],
    cars:[],
    personNum:[0,1,2,3,4,5,6,7,8,9,10],
    numIndex:null,
    departmentIndex:-1,
    userIndex:null,  
    driverIndex:null,  
    carIndex:null,
    dateTimeArray1: null,
    dateTime1: null,
    startYear: 2018,
    endYear: 5020,
    startTime:'', //出发时间
    reason:'', //用车事由
    hideLeftBtn:false,
    hideRightBtn:true,
    taskList:[], //任务记录
    hideTaskView:true, //隐藏任务记录
    startPlace:'', //出发地
    endPlace: '', //目的地
    hideTip: true, //隐藏替代图
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 获取完整的年月日 时分秒，以及默认显示的数组
    var obj1 = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    // 精确到分的处理，将数组的秒去掉
    var lastArray = obj1.dateTimeArray.pop();
    var lastTime = obj1.dateTime.pop();

    this.setData({
      dateTimeArray1: obj1.dateTimeArray,
      dateTime1: obj1.dateTime
    });

    //请求数据
    this.getDepartmentList();
    this.getDriverList();
    this.getCarList();
  },

  //页面显示时
  onShow: function () {
    this.getTaskList();
    //this.getUserList();
  },

  //刷新
  refreshTap: function (e) {
    this.getTaskList();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.getTaskList();
  },

  //任务列表
  getTaskList: function() {
    let that = this;
    let userInfo = wx.getStorageSync('loginInfo');
    wx.showLoading({
      title: '加载中...'
    });
    ajax.GET({
      ajaxPoint: 'SubService/getTaskInfo',
      params: {
        id: userInfo.uid
      },
      success: function (res) {
        wx.hideLoading();
        var arr = res.data.NewTask;
        if(arr.length == 0){
          that.setData({
            hideTip: false
          })
          return;
        }
        that.setData({
          hideTip: true
        })
        for(var i = 0; i < arr.length; i ++){
          arr[i]["hideMore"] = true;
          arr[i]["isSelf"] = false;
          if (arr[i].driverid == userInfo.uid && arr[i].status.code==1){
            arr[i]["isSelf"] = true;
          }

          //处理途径地
          if (arr[i].way != null) {
            let passPlace = arr[i].way.split(',');
            arr[i]['way'] = passPlace;
          } 

          //处理是否可以显示更多信息
          if(arr[i].status.code == 1){
            arr[i]['hideShowMoreBtn'] = true;
          }else{
            arr[i]['hideShowMoreBtn'] = false;
          }
        }
        console.log(arr);
        if (res.data.retcode == '0') {
          //
          that.setData({
            taskList: arr
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  //指派车辆
  sendCar: function() {
    this.setData({
      hideLeftBtn: false,
      hideRightBtn: true,
      hideTaskView:true
    })
  },

  //任务记录
  showHistory: function () {
    this.getTaskList();
    this.setData({
      hideLeftBtn: true,
      hideRightBtn: false,
      hideTaskView: false
    })
  },

  //展开查看
  showMore: function (e) {
    let that = this;
    var idx = e.currentTarget.dataset.idx;
    var arr = that.data.taskList;
    arr[idx]['hideMore'] = false;
    that.setData({
      taskList : arr
    })
  },

  hideMore: function (e) {
    let that = this;
    var idx = e.currentTarget.dataset.idx;
    var arr = that.data.taskList;
    arr[idx]['hideMore'] = true;
    that.setData({
      taskList : arr
    })
  },

  //立即接单
  accetpOrder: function (e) {
    let that = this;
    var idx = e.currentTarget.dataset.idx;
    var arr = that.data.taskList;
    wx.navigateTo({
      url: '/pages/driverIndex/driverIndex?task=' + JSON.stringify(arr[idx]),
    })
  },

  //请求部门信息
  getDepartmentList: function (e) {
    let that = this;
    wx.showLoading({
      title: '加载中...'
    });
    ajax.GET({
      ajaxPoint: 'SubService/getDepartmentInfo',
      params: {
        
      },
      success: function (res) {
        console.log(res.data);
        wx.hideLoading();
        if (res.data.retcode == '0') {
          //
          that.setData({
            department: res.data.departmentData
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  // 选择部门
  pickDepartmentChange: function (e) {
    console.log(e.detail.value)
    this.setData({
      departmentIndex: e.detail.value,
      userIndex: null
    })
    this.getUserList();
  },

  //请求乘车人
  getUserList: function (e) {
    let that = this;
    wx.showLoading({
      title: '加载中...'
    });
    let did = that.data.department[that.data.departmentIndex].did;
    ajax.GET({
      ajaxPoint: 'SubService/getLeaderInfo',
      params: {
        depid: did
      },
      success: function (res) {
        console.log(res.data);
        wx.hideLoading();
        if (res.data.retcode == '0') {
          // 
          var leaderArr = res.data.leaderData;
          let noneLeader = { 'username': '无','leaderid':''};
          leaderArr.unshift(noneLeader);
          that.setData({
            users: leaderArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  // 选择乘车人
  pickUserChange: function (e) {
    this.setData({
      userIndex: e.detail.value
    })
  },

  //随车人数
  pickNumChange: function (e) {
    this.setData({
      numIndex: e.detail.value
    })
  },

  //请求司机列表
  getDriverList: function (e) {
    let that = this;
    wx.showLoading({
      title: '加载中...'
    });
    ajax.GET({
      ajaxPoint: 'SubService/getDriverInfo',
      params: {

      },
      success: function (res) {
        console.log(res.data);
        wx.hideLoading();
        if (res.data.retcode == '0') {
          // 
          var driverArr = res.data.driverData;
          let noneDriver = { 'username': '无','driverid':''};
          driverArr.unshift(noneDriver);
          that.setData({
            drivers: driverArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  // 选择司机
  pickDriverChange: function (e) {
    this.setData({
      driverIndex: e.detail.value,
      carIndex: null
    })
    this.getCarList();
  },

  //请求车辆列表
  getCarList: function (e) {
    let that = this;
    wx.showLoading({
      title: '加载中...'
    });
    var param = {};
    console.log(that.data.driverIndex);
    if (that.data.driverIndex != null){
      let drvid = that.data.drivers[that.data.driverIndex].driverid;
      param['driverid'] = drvid
    }
    ajax.GET({
      ajaxPoint: 'SubService/getCarInfo',
      params: param,
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == '0') {
          // 
          let carArr = res.data.carData;
          console.log(res);
          that.setData({
            cars: carArr
          })
          if (carArr.length != 0 && that.data.driverIndex != null){
            that.setData({
              carIndex: 0
            })
          }else (
            that.setData({
              carIndex: null
            })
          )
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  // 选择车辆
  pickCarChange: function (e) {
    this.setData({
      carIndex: e.detail.value
    })
  },

  //用车事由
  getReason: function (e) {
    this.setData({
      reason: e.detail.value
    })
  },

  //出发地
  getStartPlace: function (e) {
    this.setData({
      startPlace: e.detail.value
    })
  },

  //目的地
  getEndPlace: function (e) {
    this.setData({
      endPlace: e.detail.value
    })
  },

  // 确定
  sureAction: function () {
    let that = this;
    console.log(that.departmentIndex, that.data.carIndex, that.data.numIndex,that.data.driverIndex)
    console.log('出发地 ' + that.data.startPlace + '目的地' + that.data.endPlace)
    console.log(that.data.reason+' '+ that.data.startTime);
    if (that.data.reason == '' || that.departmentIndex == -1 || that.data.startTime == '' || that.data.carIndex == null || that.data.numIndex == null || that.data.startPlace == '' || that.data.endPlace == ''){
      wx.showToast({
        title: '请完善信息',
        icon: 'none'
      })
      return;
    }
    let userInfo = wx.getStorageSync('loginInfo');
    let dataTimeArr = that.data.dateTimeArray1;
    let dateTime = that.data.dateTime1;
    let time = that.data.startTime;
    let num = that.data.personNum[that.data.numIndex];
    console.log(num, that.data.carIndex);
    var params = {
      did:that.data.department[that.data.departmentIndex].did,
      stime: time,
      carid: that.data.cars[that.data.carIndex].carid,
      reason: that.data.reason,
      num: num,
      splace: that.data.startPlace,
      eplace: that.data.endPlace,
      uid: userInfo.uid
    }
    if (that.data.driverIndex != null){
      params['driverid'] = that.data.drivers[that.data.driverIndex].driverid;
    }
    if (that.data.userIndex != null) {
      params['leaderid'] = that.data.users[that.data.userIndex].leaderid;
    }

    console.log('params=='+params.did+' '+params.leaderid+' '+params.stime+' '+params.driverid+' '+params.carid+' '+params.bid)

    wx.showLoading({
      title: '',
      mask:'true'
    })
    ajax.POST({
      ajaxPoint: 'SubService/addTaskInfo',
      params: params,
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == '0') {
          // 
          wx.showToast({
            title: '发布成功',
          })
          that.setData({
            departmentIndex: -1,
            userIndex: null,
            driverIndex: null,
            carIndex: null,
            numIndex: null,
            startTime:'',
            reason:null,
            startPlace:'',
            endPlace:''
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  //时间选择
  changeDateTime1(e) {
    let that = this;
    let dateTimeArr = that.data.dateTimeArray1;
    let dateTime = e.detail.value;
    let time = dateTimeArr[0][dateTime[0]] + '-' + dateTimeArr[1][dateTime[1]] + '-' + dateTimeArr[2][dateTime[2]] + ' ' + dateTimeArr[3][dateTime[3]] + ':' + dateTimeArr[4][dateTime[4]];
    
    console.log('time=='+that.data.startTime)
    var currentTime = new Date().getTime();
    var selectTime = new Date(time.replace(/-/g, "/")).getTime();
    var difference = selectTime - currentTime;
    console.log(difference);
    if(difference < 0){
      that.setData({
        startTime: ''
      });
      wx.showToast({
        title: '所选时间不能小于当前时间哦',
        icon: 'none'
      })
    }else{
      that.setData({
        startTime: time
      });
    }
  },

  //滚动选项触发
  // changeDateTimeColumn1(e) {
  //   var arr = this.data.dateTime1, dateArr = this.data.dateTimeArray1;
  //   arr[e.detail.column] = e.detail.value;
  //   dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
  //   this.setData({
  //     dateTimeArray1: dateArr,
  //     dateTime1: arr
  //   });
  // },

})