// pages/driverIndex/driverIndex.js

var dateTimePicker = require('../../utils/dateTimePicker.js');
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    passPlace:[],//途径地
    task:{},
    mileage:'', //行驶里程
    backTime:'', //返回时间

    dateTimeArray1: null,
    dateTime1: null,
    startYear: 2018,
    endYear: 5020,

    hideTip: true, //隐藏提示
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    
    var task = JSON.parse(options.task)
    console.log(task);
    that.setData({
      task: task,
      hideTip: true
    })

    var obj1 = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear, that.data.task.stime);
    // 精确到分的处理，将数组的秒去掉
    var lastArray = obj1.dateTimeArray.pop();
    var lastTime = obj1.dateTime.pop();

    that.setData({
      dateTimeArray1: obj1.dateTimeArray,
      dateTime1: obj1.dateTime
    });
  },

  //行驶里程
  getMileage: function (e) {
    this.setData({
      mileage: e.detail.value
    })
  },

  //返回时间选择
  changeDateTime1(e) {
    let that = this;
    let dateTimeArr = that.data.dateTimeArray1;
    let dateTime = e.detail.value;
    let time = dateTimeArr[0][dateTime[0]] + '-' + dateTimeArr[1][dateTime[1]] + '-' + dateTimeArr[2][dateTime[2]] + ' ' + dateTimeArr[3][dateTime[3]] + ':' + dateTimeArr[4][dateTime[4]];

    var currentTime = new Date(that.data.task.stime.replace(/-/g, "/")).getTime();
    var selectTime = new Date(time.replace(/-/g, "/")).getTime();
    var difference = selectTime - currentTime;
    console.log(difference);
    if (difference < 0) {
      that.setData({
        backTime: ''
      });
      wx.showToast({
        title: '所选时间不能小于出发时间哦',
        icon: 'none'
      })
    } else {
      that.setData({
        backTime: time
      });
    }
  },

  //获取途径地值
  getMiddlePlace: function (e) {    
    let that = this;
    let index = e.currentTarget.dataset.index;
    var arr = that.data.passPlace;
    arr[index] = e.detail.value
    this.setData({
      passPlace: arr
    })
  },

  // 添加途经地
  addPassPlace: function () {
    let that = this;
    var arr = that.data.passPlace;
    arr.push('');
    that.setData({
      passPlace: arr
    })
  },

  // 删除途经地
  deletePassPlace: function (e) {
    let that = this;
    let index = e.currentTarget.dataset.id;
    var arr = that.data.passPlace;
    arr.splice(index, 1);
    that.setData({
      passPlace: arr
    })
  },

  // 结束行程
  sureAction: function () {
    let that = this;
    let mileage = that.data.mileage;
    let backTime = that.data.backTime;
    let passPlace = that.data.passPlace.join(',');
    if(mileage.length == 0  || backTime.length == 0){
      wx.showToast({
        title: '请填写完整信息',
        icon : 'none'
      })
    } else {
      var params = {
        id : that.data.task.id,
        distance : mileage,
        ftime : backTime,
        way: passPlace
      }

      if (that.data.task.leaderid == null){
        params['leaderid'] = '';
      }else{
        params['leaderid'] = that.data.task.leaderid;
      }
      
      wx.showLoading({
        title: '',
      })
      ajax.POST({
        ajaxPoint: 'SubService/updateTaskInfo',
        params: params,
        success: function (res) {
          wx.hideLoading();
          console.log(res);
          if (res.data.retcode == '0') {
            wx.showToast({
              title: "上传成功",
              icon: 'none'
            })
            that.setData({
              task:{},
              reason:'',
              mileage:'',
              backTime:'',
              passPlace:[],
              // hideTip:false
            })
            wx.navigateBack({
              
            })
          } else {
            wx.showToast({
              title: res.data.meg,
              icon: 'none'
            })
          }
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '上传出错,请检查网络',
            icon: 'none',
            mask: true
          })
        }
      })
    }
  },

})