// pages/userTaskList/userTaskList.js

const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    taskList: null,
    userName:'',
    evaluateRank: ['非常满意', '满意', '基本满意', '不满意'],
    selectId: -1,
    hideEvaluateView: true, //隐藏评价
    evaluateTaskId:'', //要评价的任务
    hideTip:true
  },

  onLoad: function (options) {
    let userInfo = wx.getStorageSync('loginInfo');
    this.setData({
      userName: userInfo.username
    })
  },

  //页面显示时
  onShow: function () {
    this.getTaskList();
  },

  //请求数据
  getTaskList: function () {
    let that = this;
    let userInfo = wx.getStorageSync('loginInfo');
    wx.showLoading({
      title: '加载中...'
    });
    console.log('用车人 '+userInfo.uid);
    ajax.GET({
      ajaxPoint: 'SubService/getArrive',
      params: {
        leaderid: userInfo.uid
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res);
        var arr = res.data.leaderTask;
        if (arr.length == 0) {
          // wx.showToast({
          //   title: '暂无任务',
          //   icon: 'none'
          // })
          that.setData({
            hideTip: false
          })
          return;
        }
        that.setData({
          hideTip: true
        })
        for (var i = 0; i < arr.length; i++) {
          arr[i]["hideMore"] = true;
          arr[i]["isSelf"] = false;
          if (arr[i].driverid == null && arr[i].status.code == 1) {
            arr[i]["isSelf"] = true;
          }

          //处理途径地
          if (arr[i].way != null) {
            let passPlace = arr[i].way.split(',');
            arr[i]['way'] = passPlace;
          }

          //处理是否可以显示更多信息
          if (arr[i].status.code == 1) {
            arr[i]['hideShowMoreBtn'] = true;
          } else {
            arr[i]['hideShowMoreBtn'] = false;
          }
        }
        console.log(arr);
        if (res.data.retcode == '0') {
          //
          that.setData({
            taskList: arr
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  //刷新
  refreshTap: function (e) {
    this.getTaskList();
  },
  
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.getTaskList();
  },

  //展开查看
  showMore: function (e) {
    let that = this;
    var idx = e.currentTarget.dataset.idx;
    var arr = that.data.taskList;
    arr[idx]['hideMore'] = false;
    that.setData({
      taskList: arr
    })
  },

  hideMore: function (e) {
    let that = this;
    var idx = e.currentTarget.dataset.idx;
    var arr = that.data.taskList;
    arr[idx]['hideMore'] = true;
    that.setData({
      taskList: arr
    })
  },

  //立即接单
  accetpOrder: function (e) {
    let that = this;
    var idx = e.currentTarget.dataset.idx;
    var arr = that.data.taskList;
    wx.navigateTo({
      url: '/pages/driverIndex/driverIndex?task=' + JSON.stringify(arr[idx]),
    })
  },

  //确认
  finishOrder: function (e) {
    let that = this;
    var idx = e.currentTarget.dataset.idx;
    var arr = that.data.taskList;
    wx.navigateTo({
      url: '/pages/carUser/carUser?task=' + JSON.stringify(arr[idx]),
    })
  },

  //去评价
  evaluateOrder: function (e) {
    let that = this;
    var idx = e.currentTarget.dataset.idx;
    var arr = that.data.taskList;
    that.setData({
      hideEvaluateView:false,
      evaluateTaskId:arr[idx].id
    })
  },

  //选择评价
  selectThis: function (e) {
    let that = this;
    let itemId = e.currentTarget.dataset.id;
    that.setData({
      selectId: itemId
    })
  },

  // 提交评价
  submitEvaluate: function (e) {
    let that = this;
    that.setData({
      hideEvaluateView: true
    })
    wx.showLoading({
      title: '',
    })
    ajax.GET({
      ajaxPoint: 'SubService/evaluate',
      params: {
        id: that.data.evaluateTaskId,
        pj: that.data.selectId + 1
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == '0') {
          //
          wx.showToast({
            title: "评价成功"
          })
          that.setData({
            hideEvaluateView: true,
            // hideTip: false
          })
          that.getTaskList();
        } else {
          wx.showToast({
            title: "评价失败",
            icon: 'none'
          })
        }
      },
      fail: function () {
        wx.hideLoading();
        wx.showToast({
          title: '请检查网络',
          icon: 'none',
          mask: true
        })
      }
    })
  },

  //关闭评价
  closeEvaluate: function () {
    this.hideEvaluateView();
  },
  
  //点击空白隐藏评价
  hideEvaluateView: function () {
    this.setData({
      hideEvaluateView: true
    })    
  }

})