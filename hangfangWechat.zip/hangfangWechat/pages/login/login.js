// pages/login/login.js

const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phoneNum:'',
    code:'',
    timer: null,//定时器名字
    countDownNum: 0,//倒计时初始值
    canGetCode:true
  },

  //倒计时
  countDown: function () {
    let that = this;
    clearInterval(that.data.timer);
    let countNum = 60;//获取倒计时初始值
    //如果将定时器设置在外面，那么用户就看不到countDownNum的数值动态变化，所以要把定时器存进data里面
    that.setData({
      timer: setInterval(function () {//这里把setInterval赋值给变量名为timer的变量
        //每隔一秒countDownNum就减一，实现同步
        countNum--;
        //然后把countDownNum存进data，好让用户知道时间在倒计着
        that.setData({
          countDownNum: countNum
        })
        //在倒计时还未到0时，这中间可以做其他的事情，按项目需求来
        if (countNum == 0) {
          //这里特别要注意，计时器是始终一直在走的，如果你的时间为0，那么就要关掉定时器！不然相当耗性能
          //因为timer是存在data里面的，所以在关掉时，也要在data里取出后再关闭
          clearInterval(that.data.timer);
          console.log('倒计时结束了');
          //关闭定时器之后，可作其他处理codes go here
          that.setData({
            canGetCode: true,
            timer:null
          })
        }
      }, 1000)
    })
  },

  // 确定
  sureAction: function () {
    let that = this;
    //获取用户信息
    let openid = '';
    wx.getStorage({
      key: 'loginInfo',
      success: function(res) {
        openid = res.data.openid
        wx.showLoading({
          title: '',
          mask: true
        })
        let params = {
          phone: that.data.phoneNum,
          code: that.data.code,
          openid: openid
        }
        ajax.GET({
          ajaxPoint: 'AccountWebService/judgeLogin',
          params: params,
          success: function (res) {
            console.log(res.data);
            if (res.data.retcode == 0) {
              // 将获取到的登录信息存储到缓存中
              wx.setStorage({
                key: 'loginInfo',
                data: res.data,
                success: function () {
                  wx.hideLoading();
                },
                fail: function (res) {
                  wx.hideLoading();
                }
              })
              // 判决角色进入不同页面
              if (res.data.usertype.code == 1) {
                // 用车人页面
                wx.redirectTo({
                  url: '../userTaskList/userTaskList'
                })
              } else if (res.data.usertype.code == 2) {
                // 班长页面
                wx.redirectTo({
                  url: '../monitorIndex/monitorIndex'
                })
              } else {
                // 司机页面
                if (res.data.issq == 1) {
                  //未授权
                  wx.redirectTo({
                    url: '../driverTaskList/driverTaskList'
                  })
                } else {
                  //已授权
                  wx.redirectTo({
                    url: '../AuthorizedDriver/AuthorizedDriver'
                  })
                }
              }

            } else {
              wx.hideLoading();
              wx.showToast({
                title: res.data.meg,
                icon: 'none'
              })
            }
          }
        })
      },
    })
  },

  //发送验证码
  sendCodeAction: function () {
    let that = this;
    if(that.data.phoneNum.length < 11){
      wx.showToast({
        title: '请输入正确手机号',
        icon: 'none'
      })
      return;
    }
    wx.showLoading({
      title: '',
      mask: true
    })
    ajax.GET({
      ajaxPoint: 'AccountWebService/getCode',
      params: {
        phone:that.data.phoneNum
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == 0) {
          // 
          that.countDown();
          that.setData({
            canGetCode: false
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  //获取手机号
  getPhomeNum: function (e) {
    this.setData({
      phoneNum: e.detail.value
    })
  },

  //获取验证码
  getCode: function (e) {
    this.setData({
      code: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  onUnload: function () {
    var that = this;
    //清除计时器  即清除setInter
    clearInterval(that.data.timer)
  },

})