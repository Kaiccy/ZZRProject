// pages/carUser/carUser.js

const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    task:null,
    evaluateRank: ['非常满意', '满意', '基本满意', '不满意'],
    selectId: -1,
    hideEvaluateView: true, //隐藏评价
    hideTip: false, //隐藏提示
    hideOrangePoint:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    var task = JSON.parse(options.task)
    console.log(task);
    that.setData({
      task: task,
      hideTip: true
    })

    if(task.way[0].length == 0){
      that.setData({
        hideOrangePoint: true
      })
    }
  },

  //确认送达
  sureAction: function (e) {
    let that = this;
    wx.showLoading({
      title: '',
    })
    ajax.GET({
      ajaxPoint: 'SubService/ConfirmTask',
      params: {
        id: that.data.task.id
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == '0') {
          //
          wx.showToast({
            title: "提交成功"
          })
          that.setData({
            hideEvaluateView: false,
            // hideTip: false
          })
        } else {
          wx.showToast({
            title: "提交失败",
            icon: 'none'
          })
        }
      },
      fail: function () {
        wx.hideLoading();
        wx.showToast({
          title: '请检查网络',
          icon: 'none',
          mask: true
        })
      }
    })
  },

  //选择评价
  selectThis: function (e) {
    let that = this;
    let itemId = e.currentTarget.dataset.id;
    that.setData({
      selectId: itemId
    })
  },

  // 提交评价
  submitEvaluate: function (e) {
    let that = this;
    that.setData({
      hideEvaluateView: true
    })
    wx.showLoading({
      title: '',
    })
    ajax.GET({
      ajaxPoint: 'SubService/evaluate',
      params: {
        id: that.data.task.id,
        pj: that.data.selectId + 1
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == '0') {
          //
          wx.showToast({
            title: "评价成功"
          })
          that.setData({
            hideEvaluateView: true,
            // hideTip: false
          })
          wx.navigateBack({
            
          })
        } else {
          wx.showToast({
            title: "评价失败",
            icon: 'none'
          })
        }
      },
      fail: function () {
        wx.hideLoading();
        wx.showToast({
          title: '请检查网络',
          icon: 'none',
          mask: true
        })
      }
    })
  },

  //关闭评价
  closeEvaluate: function () {
    this.hideEvaluateView();
  },

  //点击空白隐藏评价
  hideEvaluateView: function () {
    this.setData({
      hideEvaluateView: true
    })
    wx.navigateBack({
      
    })
  }

})