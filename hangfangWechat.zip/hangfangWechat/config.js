

var config = {

  // 正式接口地址
  ajaxUrl: 'https://wxapp.hzhfdc.com/'
  
  // 测试接口
  // ajaxUrl: 'http://192.168.0.60:86/hfycOSP/'
  
};

module.exports = config;