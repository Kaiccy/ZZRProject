// component/payModal/index.js


Component({
  properties: {
    payNum: {
      type: String,
      value: ''
    },
    ishow: {
      type: Boolean,
      value: false
    }
  },
  methods:{
    changeSelect(e){
      let that = this;
      that.setData({
        selectId: e.currentTarget.dataset.id
      })
    },
    goPay:function(){
      var that = this;
      var myEventDetail = { payModal: false, payWay: that.data.selectId ,type: 'cancel' } // detail对象，提供给事件监听函数
      this.triggerEvent('action', myEventDetail) //myevent自定义名称事件，父组件中使用
    },
    closePayModal:function(){
      var that = this;
      var myEventDetail = { payModal: false, type: 'cancel' } // detail对象，提供给事件监听函数
      this.triggerEvent('closeModal', myEventDetail) //myevent自定义名称事件，父组件中使用
    }
  },
  data: {
    selectId: 0,
    payWay: [
      { name: '微信支付', id: 0, imgUrl: '/static/images/wxpay.png' }
      , { name: '余额支付', id: 1, imgUrl: '/static/images/yue.png' }]
  }
})
