

var config = {

  // 接口地址
  ajaxUrl: 'https://zf.cube-tech.cn/',
  imgUrl: 'https://zf.cube-tech.cn/pic/'

};

module.exports = config;