// pages/home/home.js
const ajax = require('../../utils/request.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wxInfo: wx.getStorageSync('wxInfo'),
    number: '',                                // 团队的人数
    getUserModal: false //授权窗口
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    
  },
  goInvite: function () {
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  shopClick:function(){
    wx.navigateTo({
      url: '../homePages/pages/shop/shop',
    })
  },
  editClick:function(){
    wx.navigateTo({
      url: '../homePages/pages/editInfo/editInfo',
    })
  },

  getTeamList:function(){
    var wxInfo = wx.getStorageSync('wxInfo');
    var that = this;
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zfaccount/getTeamList',
      params: {
        loginid: wxInfo.aid
      },
      success: function (res) {
        // console.log(res.data.data)
        if (res.data.code == '0') {

          that.setData({
            number: parseInt(res.data.data.firTeamCount + res.data.data.secTeamCount)
          })
          setTimeout(function () {
            wx.hideLoading();
          }, 500)

        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 获取团队人数
    let that = this;

    // that.getLocation();
    if (wx.getStorageSync('wxInfo')) {
      let userInfo = wx.getStorageSync('wxInfo');
      if (userInfo.aid == '') {　 // 已授权未登录
        wx.hideLoading();
        wx.redirectTo({
          url: '../login/login'
        })
      } else {
        that.getTeamList();

        // 每次进入重新获取登录信息
        that.login();
      }
    } else {
      that.setData({
        getUserModal: true
      })
    }

    
    
  },
  // 刷新用户信息
  login: function () {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    let loginid = wx.getStorageSync('loginid');
    let token = wx.getStorageSync('token');

    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    ajax.GET({
      ajaxPoint: 'zfaccount/getAccountInfo',
      params: {
        aid: userInfo.aid,
        loginid: userInfo.loginid
      },
      success: function (res) {
        // console.log(res.data.data);
        if (res.data.code == '0') {
          // 将获取到的个人信息存储到缓存中
          let data = res.data.data;
          data.token = token;
          data.loginid = loginid;
          //console.log(data);
          wx.setStorage({
            key: 'wxInfo',
            data: data,
            success: function () {
              wx.hideLoading();
              that.setData({
                wxInfo: data
              })
            },
            fail: function (res) {
              wx.hideLoading();
              wx.showToast({
                title: '缓存出错！',
                icon: 'none'
              })
            }
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      },
      fail: function (res) {
        wx.hideLoading();
        wx.showToast({
          title: '网络错误！',
          icon: 'none'
        })
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    const wxInfo = wx.getStorageSync('wxInfo');
    // console.log(wxInfo)
    return {
      title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
      path: 'pages/index/index?inviterphone=' + wxInfo.regphone,
      imageUrl: '../../static/images/shaBj.png',
      success: function (res) {
        // 转发成功
        console.log("转发成功:");
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:");
      }
    }
  },
  /* 获取用户授权 */
  getUserInfo: function (e) {
    // console.log(e)
    let that = this;
    var userInfo = e.detail.userInfo; // 点击允许按钮获取到的个人信息+
    if (userInfo) {
      //用户按了允许授权按钮
      // console.log('用户按了允许授权按钮');
      var encryptedData = e.detail.encryptedData;
      var iv = e.detail.iv;
      // console.log('encryptedData:' + encryptedData)
      // console.log('iv:' + iv)
      wx.showLoading({
        title: '加载中...',
        mask: true
      });
      wx.login({ // 登录获取code
        success: res => {
          let code = res.code;
          // console.log('code:' + code);
          let params = {
            code: code,
            encryptedData: encodeURIComponent(encryptedData),
            iv: encodeURIComponent(iv),
            nickname: userInfo.nickName,
            headimgurl: userInfo.avatarUrl
          };
          // 用code向后台换取微信信息
          ajax.POST({
            ajaxPoint: 'https://zf.cube-tech.cn/zfaccount/getWxOpenId',
            // ajaxPoint: 'http://192.168.0.181:4002/getWxOpenId',
            params: params,
            success: function (res) {
              // console.log(res.data);
              wx.hideLoading();
              that.setData({
                getUserModal: false
              })
              if (res.data.code == '0') {
                // 将获取到的个人信息存储到缓存中
                // 保存loginid
                wx.setStorage({
                  key: 'loginid',
                  data: res.data.data.loginid
                })
                // 保存token
                wx.setStorage({
                  key: 'token',
                  data: res.data.data.token
                })
                // 保存微信信息
                wx.setStorage({
                  key: 'wxInfo',
                  data: res.data.data,
                  success: function () {
                    wx.hideLoading();
                  },
                  fail: function (res) {
                    wx.hideLoading();
                  }
                })
                if (res.data.data.aid == '') {
                  wx.redirectTo({
                    url: '/pages/login/login'
                  })
                } else {
                  wx.reLaunch({
                    url: '/pages/index/index',
                  })
                }
              } else {
                wx.hideLoading();
                wx.showToast({
                  title: res.data.message,
                  icon: 'none'
                })
              }

            }
          })
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '登录出错,请检查网络',
            icon: 'none',
            mask: true
          })
        }
      })
    } else {
      //用户按了拒绝按钮
      // console.log('用户按了拒绝按钮');
      wx.showModal({
        title: '提示',
        content: '小程序需要您的微信授权才能使用哦！'
      })
    }
  }
})