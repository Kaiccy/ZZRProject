// pages/home/myTeam/myTeam.js
var ajax = require('../../../../utils/request.js');
var config = require('../../../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wxInfo: wx.getStorageSync('wxInfo'),
    teamList: [],        // 团队信息
    firstState: true,    // 一级团队查看更多的状态 
    secondState: true,   // 二级团队查看更多的状态
  },
  goInvite: function () {
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  load: function () {
    var wxInfo = wx.getStorageSync('wxInfo');
    var that = this;
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zfaccount/getTeamList',
      params: {
        loginid: wxInfo.loginid
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == '0') {
          that.setData({
            teamList: res.data.data
          })
          setTimeout(function () {
            wx.hideLoading();
          }, 500)
        }else{
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
  },

  // 一级团队查看更多
  firstMore:function(){
    this.setData({
      firstState: !this.data.firstState
    })
  },

  // 二级团队查看更多
  secondMore:function(){
    this.setData({
      secondState: !this.data.secondState
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.load()
  },
  dtClick:function(e){
    console.log(e.currentTarget.dataset.aid)
    wx.navigateTo({
      url: '../personPageOther/index?aid=' + e.currentTarget.dataset.aid,
    })
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    const wxInfo = wx.getStorageSync('wxInfo');
    console.log(wxInfo)
    return {
      title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
      path: 'pages/index/index?inviterphone=' + wxInfo.regphone,
      imageUrl: '../../../../static/images/shaBj.png',
      success: function (res) {
        // 转发成功
        console.log("转发成功:");
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:");
      }
    }
  }
})