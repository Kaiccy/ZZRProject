// pages/homePages/pages/personalPage/index.js
const ajax = require('../../../../utils/request.js');
const config = require('../../../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:[],
    envelopeList:[],
    userType:0,
    pager: 1,
    pagesize: 10,
    total:0
  },
  goInvite:function(){
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    that.getUserInfo()
  },
  viewImg: function (e) {
    let index_pra = e.currentTarget.dataset.index;
    let index = e.currentTarget.dataset.id;
    let that = this;
    wx.previewImage({
      current: that.data.envelopeList[index_pra].pic[index],
      urls: that.data.envelopeList[index_pra].pic,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    let that = this;
    that.setData({
      pager:1,
      pagesize:10,
      total:0
    });
    that.getUserInfo(that.data.userInfo.aid)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    let that = this;
    if(that.data.total>that.data.pager*that.data.pagesize){
      that.getSendList(that.data.pager+1,that.data.pagesize);
      that.setData({
        pager: that.data.pager+1
      })
    }else{
      wx.showToast({
        icon:'none',
        title: '没有更多数据了',
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    let that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    // console.log(wxInfo.aid)
    return {
      title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
      imageUrl: "../../static/images/shaBj.png",
      path: '/pages/index/index?inviterphone=' + wxInfo.regphone,
      // imageUrl: '../../../static/images/33@2x.png'
      success: function (res) {
        // 转发成功
        console.log("转发成功:");
        ajax.GET({
          ajaxPoint: 'zfaccount/shareIntegralInfo',
          params: {
            loginid: wxInfo.loginid,
            share_type: 1
          }
        })
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:");
      }
    }
  },

  /*获取用户信息 */
  getUserInfo:function(){
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    wx.stopPullDownRefresh();
    if (userInfo){
      ajax.GET({
        ajaxPoint:'zfaccount/getPersonInfo',
        params:{
          aid:userInfo.aid,
          loginid: userInfo.loginid
        },
        success:function(res){
          if(res.data.code==0){
            res.data.data.account.nickname = decodeURIComponent(res.data.data.account.nickname);
            that.setData({
              userInfo: res.data.data.account,
              userType: userInfo.level_type.code
            })
          }
        }
      });
      ajax.GET({
        ajaxPoint: 'zfaccount/getSendRedPackageLog',
        params: {
          aid: userInfo.aid,
          loginid: userInfo.loginid,
          pager: that.data.pager,
          pagesize: that.data.pagesize
        },
        success: function (res) {
          if (res.data.code == 0) {
            for (let i = 0; i < res.data.data.infolist.length; i++) {
              if (res.data.data.infolist[i].pic !== '') {
                res.data.data.infolist[i].pic = res.data.data.infolist[i].pic.split(',')
              }
              var reg = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
              var dateStr = res.data.data.infolist[i].create_time.substr(0, 10).match(reg);
              let month = dateStr[2];
              let day = dateStr[3]
              //console.log(RegExp.$3);
              res.data.data.infolist[i].create_time = { month: month, day: day };
            };
            that.setData({
              envelopeList: res.data.data.infolist,
              total:res.data.data.total
            })
          }
        },
        fail: function (res) {
          wx.hideLoading();
          wx.showToast({
            icon: 'none',
            title: '网络出错',
          })
        }
      })
    }
  },
  /*获取 */
  viewDetail:function(e){
    //console.log(e.currentTarget.dataset.envelopeid);
    let that = this;
    let wxInfo = wx.getStorageSync('wxInfo');
    if (wxInfo.envelope_times + wxInfo.envelope_times_add == 0) { //如果没有抢红包次数.直接跳转 noTimes表示无可用次数
      console.log('noTimes表示无可用次数')
      wx.navigateTo({
        url: '/pages/envelopeDetail/index?noTimes=1&envelopeId=' + e.currentTarget.dataset.envelopeid,
      })
    } else if (e.currentTarget.dataset.recive == 0){  //如果有次数,但是没有抢过这个红包,先抢跳转
      console.log('先抢再跳转')
      wx.showLoading({
        title: '努力加载中..',
      });
      if (wxInfo) {
        ajax.GET({
          ajaxPoint: 'zfenvelope/grabEnvelope',
          params: {
            loginid: wxInfo.loginid,
            envelope_id: e.currentTarget.dataset.envelopeid
          },
          success: function (res) {
            wx.hideLoading();
            if (res.data.code == 0) { //抢到了 更改一下可用次数。跳转
              let userInfo = wx.getStorageSync('wxInfo');
              wxInfo.envelope_times = res.data.data.envelope_times;
              wxInfo.envelope_times_add = res.data.data.envelope_times_add;
              wx.setStorage({
                key: 'wxInfo',
                data: wxInfo,
                success: function (res) {
                  wx.navigateTo({
                    url: '/pages/envelopeDetail/index?envelopeId=' + e.currentTarget.dataset.envelopeid,
                  })
                }
              })
            }else{ //没抢到，直接跳转
              wx.navigateTo({
                url: '/pages/envelopeDetail/index?envelopeId=' + e.currentTarget.dataset.envelopeid,
              })
            }
          }
        })
      }
    }else{//其他状态直接跳转
      console.log('其他状态直接跳转')
        wx.navigateTo({
          url: '/pages/envelopeDetail/index?envelopeId=' + e.currentTarget.dataset.envelopeid,
        })
    }
  },
  getSendList:function(pager,pagesize){
    let userInfo = wx.getStorageSync('wxInfo');
    let that = this;
    ajax.GET({
      ajaxPoint: 'zfaccount/getSendRedPackageLog',
      params: {
        aid: userInfo.aid,
        loginid: userInfo.loginid,
        pager: pager,
        pagesize: that.data.pagesize
      },
      success: function (res) {
        if (res.data.code == 0) {
          let list = that.data.envelopeList;
          for (let i = 0; i < res.data.data.infolist.length; i++) {
            if (res.data.data.infolist[i].pic !== '') {
              res.data.data.infolist[i].pic = res.data.data.infolist[i].pic.split(',')
            }
            var reg = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
            var dateStr = res.data.data.infolist[i].create_time.substr(0, 10).match(reg);
            let month = dateStr[2];
            let day = dateStr[3]
            //console.log(RegExp.$3);
            res.data.data.infolist[i].create_time = { month: month, day: day };
            list.push(res.data.data.infolist[i])
          };
          that.setData({
            envelopeList: list
          })
        }
      },
      fail: function (res) {
        wx.hideLoading();
        wx.showToast({
          icon: 'none',
          title: '网络出错',
        })
      }
    })
  }
})