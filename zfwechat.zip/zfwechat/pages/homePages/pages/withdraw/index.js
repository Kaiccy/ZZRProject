// pages/home/withdraw/index.js
const ajax = require('../../../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    txNum:'',
    userInfo:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo')
    if(options.txNum){
      that.setData({
        txNum: options.txNum,
      })
    }
    that.setData({
      userInfo: userInfo
    })
  },
  getDetail: function (e) {
    let that = this;
    console.log(e);
    that.setData({
      txNum: e.detail.value
    })
  },
  txNow: function () {
    let that = this;
    var num = that.data.txNum;
    let userInfo = wx.getStorageSync('wxInfo');
    console.log(num);
    if (num == '') {
      wx.showModal({
        content: '提现金额不能为空',
      })
    } else if (String(num).length - (String(num).indexOf(".") + 1) > 2 && String(num).indexOf(".") > -1) {
      wx.showModal({
        content: '最多支持两位小数',
      })
    } else if (num<0.3) {
      wx.showModal({
        content: '提现金额不能小于0.3',
      })
    }else if (userInfo.amount < num) {
      wx.showModal({
        content: '提现金额不能超过余额',
      })
    } else {
      wx.showLoading({
        title: '请稍后',
      })
      ajax.GET({
        ajaxPoint:'zforder/transfersMoney',
        params:{
          aid: userInfo.aid,
          money: num,
          thirdpay_id:2,
          loginid:userInfo.loginid,
          fromto:1
        },
        success:function(res){
          wx.hideLoading();
          if(res.data.code==0){
            wx.showToast({
              title: '提现成功',
            });
            that.login();
          }else{
            wx.showToast({
              icon:'none',
              title: res.data.message,
            })
          }
        },
        fail:function(res){
          wx.hideLoading();
          wx.showToast({
            icon: 'none',
            title: '提现失败请重试',
          })
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.login()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  login: function () {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    let loginid = wx.getStorageSync('loginid');
    let token = wx.getStorageSync('token');

    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    ajax.GET({
      ajaxPoint: 'zfaccount/getAccountInfo',
      params: {
        aid: userInfo.aid,
        loginid: userInfo.loginid
      },
      success: function (res) {
        console.log(res.data.data);
        if (res.data.code == '0') {
          // 将获取到的个人信息存储到缓存中
          let data = res.data.data;
          data.token = token;
          data.loginid = loginid;
          //console.log(data);
          wx.setStorage({
            key: 'wxInfo',
            data: data,
            success: function () {
              wx.hideLoading();
              that.setData({
                userInfo: data
              })
            },
            fail: function (res) {
              wx.hideLoading();
              wx.showToast({
                title: '缓存出错！',
                icon: 'none'
              })
            }
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      },
      fail: function (res) {
        wx.hideLoading();
        wx.showToast({
          title: '网络错误！',
          icon: 'none'
        })
      }
    })
  }
})