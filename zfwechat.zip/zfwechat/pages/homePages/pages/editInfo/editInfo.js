

const ajax = require('../../../../utils/request.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:{},
    nickname:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    try {
      // 获取缓存的用户信息
      const value = wx.getStorageSync('wxInfo')
      if (value) {
        // console.log(value);
        that.setData({
          userInfo : value,
          nickname: value.nickname
        })
      }
    } catch (e) {
      // Do something when catch error
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    if (wx.getStorageSync('wxInfo')) {
      const value = wx.getStorageSync('wxInfo')
      // console.log(value);
      this.setData({
        userInfo: value,
        nickname: value.nickname
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  //修改昵称
  changeNickName: function (){
    // console.log("修改昵称");
    wx.navigateTo({
      url: '../changeNickname/changeNickname',
    })
  },

  //会员身份
  becomeVip: function (){
    // console.log("成为会员");
    wx.navigateTo({
      url: '../openVip/openVip',
    })
  }

});