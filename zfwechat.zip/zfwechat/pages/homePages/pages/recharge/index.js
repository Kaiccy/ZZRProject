// pages/home/recharge/index.js
const ajax = require('../../../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    money:'',
    userInfo:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getMoney:function(e){
    let that = this;
    let money = e.detail.value;
    if(money>0){
      that.setData({
        money: money
      })
    }
  },
  goPay:function(){
    let that = this;
    let money = that.data.money;
    let userInfo = wx.getStorageSync('wxInfo');

    if (money == '') {
      wx.showModal({
        content: '充值金额不能为空',
      })
    } else if (String(money).length - (String(money).indexOf(".") + 1) > 2 && String(money).indexOf(".") > -1) {
      wx.showModal({
        content: '最多支持两位小数',
      })
    }else {
      wx.showLoading({
        title: '请等待',
      })
      ajax.GET({
        ajaxPoint: 'zforder/addRechargeOrder',
        params: {
          money: money,
          aid: userInfo.aid,
          order_type: 4,
          loginid: userInfo.loginid
        },
        success: function (res) {
          if (res.data.code == 0) {
            let orderId = res.data.data.order_id;
            ajax.GET({
              ajaxPoint: 'zforder/orderPayRecharge',
              params: {
                order_id: orderId,
                pay_type: 1,
                thirdpay_id: 2,
                thirdpay_type: 2,
                loginid: userInfo.loginid
              },
              success: function (resdata) {
                if (res.data.code == 0) {
                  let payInfo = resdata.data.data;
                  wx.requestPayment({
                    timeStamp: payInfo.timeStamp,
                    nonceStr: payInfo.nonceStr,
                    package: payInfo.package,
                    signType: 'MD5',
                    paySign: payInfo.paySign,
                    success(res) {
                      wx.hideLoading()
                      wx.showModal({
                        content: '充值成功!去发个红包?',
                        success: function (res) {
                          if (res.confirm) {
                            wx.reLaunch({
                              url: '/pages/index/index',
                            })
                          }
                          that.setData({
                            money:''
                          })
                          that.login()
                        }
                      })
                    },
                    fail(res) {
                      wx.hideLoading()
                      wx.showModal({
                        showCancel: false,
                        title: '充值失败',
                        content: '请重新操作',
                      })
                    }
                  })
                } else {
                  wx.hideLoading()
                  wx.showModal({
                    showCancel: false,
                    title: '充值失败',
                    content: '请重新操作',
                  })
                }
              }
            })
          } else {
            wx.hideLoading()
            wx.showModal({
              showCancel: false,
              title: '充值失败',
              content: '请重新操作',
            })
          }
        }
      })
    }
  },
  login: function () {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    let loginid = wx.getStorageSync('loginid');
    let token = wx.getStorageSync('token');

    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    ajax.GET({
      ajaxPoint: 'zfaccount/getAccountInfo',
      params: {
        aid: userInfo.aid,
        loginid: userInfo.loginid
      },
      success: function (res) {
        console.log(res.data.data);
        if (res.data.code == '0') {
          // 将获取到的个人信息存储到缓存中
          let data = res.data.data;
          data.token = token;
          data.loginid = loginid;
          //console.log(data);
          wx.setStorage({
            key: 'wxInfo',
            data: data,
            success: function () {
              wx.hideLoading();
              that.setData({
                userInfo: data
              })
            },
            fail: function (res) {
              wx.hideLoading();
              wx.showToast({
                title: '缓存出错！',
                icon: 'none'
              })
            }
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      },
      fail: function (res) {
        wx.hideLoading();
        wx.showToast({
          title: '网络错误！',
          icon: 'none'
        })
      }
    })
  }
})