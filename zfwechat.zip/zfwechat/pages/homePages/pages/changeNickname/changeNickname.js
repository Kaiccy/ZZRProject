// pages/changeNickname/changeNickname.js
var ajax = require('../../../../utils/request.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  nameClick:function(e){
    // console.log(e.detail.value)
    this.setData({
      name: e.detail.value
    })
  },

  saveNickname: function (){
    // 修改昵称
    var that = this;
    var wxInfo = wx.getStorageSync('wxInfo');
    
    ajax.GET({
      ajaxPoint: 'zfaccount/editNickName',
      params: {
        aid: wxInfo.aid,
        loginid: wxInfo.aid,
        nickname: that.data.name
      },
      success: function (res) {
        // console.log(res.data)
        if (res.data.code == '0') {
          wx.showToast({
            title: '修改成功！',
            icon: 'success',
            duration: 1500,
            success: function () {

              // 修改缓存中的名称
              wxInfo.nickname = that.data.name;
              wx.setStorage({
                key: 'wxInfo',
                data: wxInfo,
                success: function (res) {
                  setTimeout(function(){
                    wx.navigateBack({
                      delta: 1
                    })
                  },1500)
                }
              })
            }
          })

        }
      }
    })
    
  }
})