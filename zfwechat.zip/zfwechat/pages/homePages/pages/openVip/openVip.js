// pages/home/openVip/openVip.js

const ajax = require('../../../../utils/request.js');
var QQMapWX = require('../../../../libs/qqmap-wx-jssdk.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    priceList: [],
    selectId:0,
    payWayList: [
      { name: '微信支付', img: '../../static/images/wxpay.png', select: true},
      { name: '余额', img: '../../static/images/yue.png', select: false}
    ],
    selectPayWayId:0,

    // 是否显示弹框
    showAlert: false,

    //用户信息
    userInfo: {},
    nickname: '',

    //缴纳的费用
    totalMoney:0,

    //充值月数
    month: 12,

    //位置编号
    adcode: '',

    //支付方式
    payType: 1,

    //三方支付方式
    thirdpayId: '2',

    jsbzState: true,          // 开启种树弹窗提示， 为true时关闭，为false打开
    vipid: ''                 // 接收rule页面传过来的参数
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.vipid){
      this.setData({
        vipid: options.vipid
      })
    }
    let that = this;
    try {
      // 获取缓存的用户信息
      const value = wx.getStorageSync('wxInfo')
      if (value) {
        value.level_time = value.level_time.substr(0, 10)
        that.setData({
          userInfo: value,
          nickname: decodeURIComponent(value.nickname)
        })
        // console.log(value);
      }
    } catch (e) {
      // Do something when catch error
    }
    //获取价格
    this.getVipPriceList();

    //获取当前位置
    wx.getSetting({
      success(res) {
        // console.log('用户权限===');
        // console.log(res.authSetting)
        //判断是否有定位权限
        if (res.authSetting['scope.userLocation'] == true) {
          that.choosePosition();
        } else {
          wx.showToast({
            title: '需要获取当前位置',
          })
        }
      }
    })
  },
  onShow: function(){
    
  },
  // 刷新用户信息
  login: function () {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    let loginid = wx.getStorageSync('loginid');
    let token = wx.getStorageSync('token');

    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    ajax.GET({
      ajaxPoint: 'zfaccount/getAccountInfo',
      params: {
        aid: userInfo.aid,
        loginid: userInfo.loginid
      },
      success: function (res) {
        console.log(res.data.data);
        if (res.data.code == '0') {
          // 将获取到的个人信息存储到缓存中
          let data = res.data.data;
          data.token = token;
          data.loginid = loginid;
          //console.log(data);
          wx.setStorage({
            key: 'wxInfo',
            data: data,
            success: function () {
              wx.hideLoading();
              data.level_time = data.level_time.substr(0, 10)
              that.setData({
                userInfo: data
              })
            },
            fail: function (res) {
              wx.hideLoading();
              wx.showToast({
                title: '缓存出错！',
                icon: 'none'
              })
            }
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      },
      fail: function (res) {
        wx.hideLoading();
        wx.showToast({
          title: '网络错误！',
          icon: 'none'
        })
      }
    })
  },

  //当前位置编号
  choosePosition: function () {
    let that = this;
    wx.getLocation({
      success: function (res) {
        // console.log('定位成功===');
        // console.log(res);
        let chooseLo = res;
        let qqmapSdk = new QQMapWX({
          key: 'FW4BZ-GNORF-MBVJT-JL3A6-UGCIZ-QOF4S'
        });
        qqmapSdk.reverseGeocoder({
          location: {
            latitude: chooseLo.latitude,
            longitude: chooseLo.longitude
          },
          success: function (resdata) {
            // console.log('定位编号');
            // console.log(resdata);
            that.setData({
              adcode: resdata.result.ad_info.adcode
            })
          }
        })
      }
    })
  },

  // 选择面额
  selectThis:function(e){
    let that = this;
    let itemId = e.currentTarget.dataset.id;
    let price = that.data.priceList[itemId].newPrice;
    that.setData({
      selectId: itemId,
      totalMoney: price,
      month: that.data.priceList[itemId].month
    })
  },

  // 选择支付方式
  selectPayWay: function(e){
    let that = this;
    let payWayId = e.currentTarget.dataset.id
    that.setData({
      selectPayWayId: payWayId,
    })
    if (payWayId == 0) {
      that.setData({
        payType: 1, //微信
        thirdpayId: '2'
      })
    }else{
      that.setData({
        payType: 2, //余额
        thirdpayId: ''
      })
    }
  },

// 确认支付，增加订单
  surePay: function(){
    wx.showLoading({
      title: '加载中...',
    })
    let that = this;
    // console.log('几个月啊====');
    // console.log(that.data.month);
    ajax.GET({
      ajaxPoint: 'zforder/addVipOrder',
      params: {
        month: that.data.month,
        aid: that.data.userInfo.aid,
        order_type: '3',
        loginid: that.data.userInfo.loginid,
        token: that.data.userInfo.token,
        district: that.data.adcode,
        dtype: 1

      },
      success: function (res) {
        // console.log('增加订单');
        // console.log(res.data);
        if (res.data.code == '0') {
          wx.hideLoading();
          let orderId = res.data.data.order_id;
          //支付
          that.payOrder(orderId);
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })
  },

  //会员订单支付
  payOrder: function (orderId){
    wx.showLoading({
      title: '加载中...',
    })
    let that = this;
    // console.log(that.data.thirdpayId);
    ajax.GET({
      ajaxPoint: 'zforder/orderPayVip',
      params: {
        order_id: orderId,
        pay_type: that.data.payType,
        thirdpay_id: that.data.thirdpayId,
        thirdpay_type: '2', //小程序
        loginid: that.data.userInfo.loginid,
        token: that.data.userInfo.token
      },
      success: function (res) {
        // console.log('支付数据===');
        // console.log(res.data);
        if (res.data.code == '0') {
          wx.hideLoading();
          if (that.data.thirdpayId == '2'){
            //微信支付
            that.wechatPay(res.data.data);
          }else{
            that.setData({
              showAlert: true
            })
            that.login();
          }

        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })
  },

  //调起微信支付
  wechatPay: function (payData){
    // console.log('支付字段===');
    // console.log(payData);
    var that = this
    wx.requestPayment({
      timeStamp: payData.timeStamp,
      nonceStr: payData.nonceStr,
      package: payData.package,
      signType: payData.signType,
      paySign: payData.paySign,
      
      success(res) { 
        that.setData({
          showAlert: true
        })
        that.login();
      },
      fail(res) { 
        // console.log(res);
        wx.showToast({
          icon:'none',
          title: '支付失败',
        })
      }
    })
  },

// 隐藏支付结果弹框
  hideResultAlert: function(e){
    this.setData({
      showAlert: false
    })
    // console.log('支付成功！')
    let wxInfo = wx.getStorageSync('wxInfo');
    if (wxInfo.window_status.code == '2') {
      this.setData({
        jsbzState: false
      })
    }
  },

  //获取会员价格表
  getVipPriceList: function(){
    wx.showLoading({
      title: '加载中...',
    })
    let that = this;
    ajax.GET({
      ajaxPoint: 'zfcommon/getConfigList',
      params: {
        code: 'vip_price'
      },
      success: function (res) {
        // console.log(res.data);
        if (res.data.code == '0') {
          wx.hideLoading();
          // console.log(res.data.data.vip_price);
          //计算价格
          that.calculateMoney(res.data.data.vip_price.value);
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })
  },

  //根据每月的价格计算包季，包年价格
  calculateMoney: function(mprice){
    let that = this;
    var seasonPrice = mprice * 3;
    var yearPrice = mprice * 12;
    // console.log(seasonPrice,yearPrice,mprice);
    that.setData({
      priceList: [
        { name: '包年', oldPrice: "0", newPrice: yearPrice, month: 12},
        { name: '包季', oldPrice: "0", newPrice: seasonPrice, month: 3},
        { name: "包月", oldPrice: "0", newPrice: mprice, month: 1}
      ],
      totalMoney: yearPrice
    })
  },

  // 关闭开启种树提示的弹窗
  openTree: function (e) {
    
    if (e.currentTarget.dataset.id){
      var id = e.currentTarget.dataset.id;
      // console.log(id)
    }
    

    const wxInfo = wx.getStorageSync('wxInfo');
    var that = this;
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zfaccount/editWindowStatus',
      params: {
        loginid: wxInfo.aid
      },
      success: function (res) {
        // console.log('-------------关闭种树提示---------------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          wx.hideLoading();
          that.setData({
            jsbzState: true
          })
          if(id){
            if(id=='1'){
              wx.navigateBack({
                delta: 1,
              })
            }else{
              wx.navigateTo({
                url: '../../../treePages/pages/myTree/myTree',
              })
            }
            
          }
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })

  },

})