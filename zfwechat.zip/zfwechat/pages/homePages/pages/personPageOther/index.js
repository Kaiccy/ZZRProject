// pages/homePages/pages/personalPage/index.js
const ajax = require('../../../../utils/request.js');
const config = require('../../../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: [],
    envelopeList: [],
    noTimes:false,//次数用完
    show:false,//为true显示红包
    selectRp:[],
    pager:1,
    pagesize:10,
    total:0,
    aid:0
  },
  goInvite: function () {
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let aid = options.aid;
    that.setData({
      aid:aid
    })
    //that.getUserInfo(aid)
  },
  closeRedPoint(e) {
    //console.log(e);
    let that = this;
    that.setData({
      show: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this;
    that.setData({
      show: false,//为true显示红包
      selectRp: [],
      pager: 1,
      pagesize: 10,
      total: 0,
      envelopeList: [],
    });
    that.getUserInfo(that.data.aid)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    let that = this;
    that.setData({
      pager: 1,
      pagesize:10,
      total:0
    });
    that.getUserInfo(that.data.userInfo.aid)
  },
  closeinviteContent:function(){
    let that = this;
    that.setData({
      noTimes:false
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    let that = this;
    if (that.data.total > that.data.pager * that.data.pagesize) {
      that.getSendList(that.data.pager + 1, that.data.pagesize);
      that.setData({
        pager: that.data.pager + 1
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: '没有更多数据了',
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    let that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    // console.log(wxInfo.aid)
    return {
      title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
      imageUrl: "../../static/images/shaBj.png",
      path: '/pages/index/index?inviterphone=' + wxInfo.regphone,
      // imageUrl: '../../../static/images/33@2x.png'
      success: function (res) {
        // 转发成功
        console.log("转发成功:");
        ajax.GET({
          ajaxPoint: 'zfaccount/shareIntegralInfo',
          params: {
            loginid: wxInfo.loginid,
            share_type: 1
          }
        })
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:");
      }
    }
  },

  /*获取用户信息 */
  getUserInfo: function (aid) {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    wx.showLoading({
      title: '正在加载',
    });
    wx.stopPullDownRefresh()
    if (userInfo) {
      ajax.GET({
        ajaxPoint: 'zfaccount/getPersonInfo',
        params: {
          aid: aid,
          loginid: userInfo.loginid
        },
        success: function (res) {
          if (res.data.code == 0) {
            res.data.data.account.nickname = decodeURIComponent(res.data.data.account.nickname);
            that.setData({
              userInfo: res.data.data.account
            })
          }
        }
      });
      ajax.GET({
        ajaxPoint: 'zfaccount/getSendRedPackageLog',
        params: {
          aid: aid,
          loginid: userInfo.loginid,
          pager: 1,
          pagesize: 10
        },
        success: function (res) {
          wx.hideLoading();
          if (res.data.code == 0) {
            for (let i = 0; i < res.data.data.infolist.length; i++) {
              if (res.data.data.infolist[i].pic !== '') {
                res.data.data.infolist[i].pic = res.data.data.infolist[i].pic.split(',')
              }
              var reg = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
              var dateStr = res.data.data.infolist[i].create_time.substr(0, 10).match(reg);
              let month = dateStr[2];
              let day = dateStr[3]
              //console.log(RegExp.$3);
              res.data.data.infolist[i].create_time = { month: month, day: day }
            };
            //console.log(res.data.data.infolist)
            that.setData({
              envelopeList: res.data.data.infolist,
              total: res.data.data.total
            })
          }
        },
        fail:function(res){
          wx.hideLoading();
          wx.showToast({
            icon:'none',
            title: '网络出错',
          })
        }
      })
    }
  },
  /*获取 */
  openRB:function(e){
    wx.showLoading({
      title: '打开红包',
    })
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo) {
      if (userInfo.envelope_times + userInfo.envelope_times_add !== 0) {
        ajax.GET({
          ajaxPoint: 'zfenvelope/grabEnvelope',
          params: {
            loginid: userInfo.loginid,
            envelope_id: that.data.selectRp.envelope_id
          },
          success: function (res) {
            wx.hideLoading();
            if (res.data.code == 0) {
              userInfo.envelope_times = res.data.data.envelope_times;
              userInfo.envelope_times_add = res.data.data.envelope_times_add;
              wx.navigateTo({
                url: '/pages/envelopeDetail/index?envelopeId=' + that.data.selectRp.envelope_id,
              })
            } else if (res.data.code == 9999) {
              wx.showModal({
                title: '提示',
                content: res.data.message,
              });
              that.setData({
                show: false,
                selectRp: []
              })
            } else {
              wx.navigateTo({
                url: '/pages/envelopeDetail/index?envelopeId=' + that.data.selectRp.envelope_id,
              })
            }
          }
        })
      } else {
        wx.hideLoading()
        that.setData({
          show: false,
          selectRp: [],
          noTimes: true
        })
        //红包次数不足,邀请弹窗出现
      }
    }
  },
  getHb:function(e){
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo.envelope_times + userInfo.envelope_times_add !== 0) {
      wx.showLoading({
        title: '打开红包',
      })
      let envelopeId = e.currentTarget.dataset.envelopeid;
      for (let i = 0; i < that.data.envelopeList.length; i++) {
        if (envelopeId == that.data.envelopeList[i].envelope_id) {
          wx.hideLoading();
          let data = that.data.envelopeList[i];
          data.nickname = decodeURI(data.nickname)
          that.setData({
            selectRp: data,
            show: true
          });
        }
      }
    } else {
      that.setData({
        noTimes: true
      })
    }
  },
  viewDetail:function(e){
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    wx.navigateTo({
      url: '/pages/envelopeDetail/index?envelopeId=' + e.currentTarget.dataset.envelopeid,
    })
  },
  viewImg:function(e){
    let index_pra = e.currentTarget.dataset.index;
    let index = e.currentTarget.dataset.id;
    let that = this;
    wx.previewImage({
      current: that.data.envelopeList[index_pra].pic[index],
      urls: that.data.envelopeList[index_pra].pic,
    })
  },
  getSendList:function(pager,pagesize){
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    wx.showLoading({
      title: '正在加载',
    })
    ajax.GET({
      ajaxPoint: 'zfaccount/getSendRedPackageLog',
      params: {
        aid: that.data.userInfo.aid,
        loginid: userInfo.loginid,
        pager: pager,
        pagesize: pagesize
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.code == 0) {
          let list = that.data.envelopeList;
          for (let i = 0; i < res.data.data.infolist.length; i++) {
            if (res.data.data.infolist[i].pic !== '') {
              res.data.data.infolist[i].pic = res.data.data.infolist[i].pic.split(',')
            }
            var reg = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
            var dateStr = res.data.data.infolist[i].create_time.substr(0, 10).match(reg);
            let month = dateStr[2];
            let day = dateStr[3]
            //console.log(RegExp.$3);
            res.data.data.infolist[i].create_time = { month: month, day: day };
            list.push(res.data.data.infolist[i])
          };
          //console.log(res.data.data.infolist)
          that.setData({
            envelopeList: list
          })
        }
      },
      fail:function(res){
        wx.hideLoading();
        wx.showToast({
          icon: 'none',
          title: '网络出错',
        })
      }
    })
  }
})