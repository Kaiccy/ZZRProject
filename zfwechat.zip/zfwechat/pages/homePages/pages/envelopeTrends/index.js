// pages/homePages/pages/envelopeTrends/index.js
const ajax = require('../../../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pager:1,
    pagesize:10,
    envelopList:[],
    total:0,
    selectList:[
      { name: '我发出的红包', id: 1 },
      { name: '我抢到的红包', id: 2 }
    ],
    selectId:1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    that.getEnvelopeList(that.data.selectId)
  },
  addBag(e) {
    // let that = this;
    // that.setData({
    //   fbHb: true
    // })
    wx.navigateTo({
      url: '/pages/addEnvelope/normalEnve/index',
    })
  },
  getEnvelopeList:function(id){
    wx.showLoading({
      title: '努力加载中...',
    })
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    let ajaxPoint = 'zfaccount/getSendRedPackageLog';
    if(id==2){
      ajaxPoint= 'zfaccount/getReceiveRedPackageLog'
    }
    ajax.GET({
      ajaxPoint: ajaxPoint,
      params: {
        aid: userInfo.aid,
        loginid: userInfo.loginid,
        pager:that.data.pager,
        pagesize:that.data.pagesize
      },
      success:function(res){
        wx.hideLoading();
        if(res.data.code==0){
          var envelopList = that.data.envelopList;
          if (!envelopList.infolist){
            envelopList = res.data.data
          }else{
            for (let i = 0; i < res.data.data.infolist.length;i++){
              envelopList.infolist.push(res.data.data.infolist[i])
            }
          }
          //console.log(envelopList)
          for (let j = 0; j < envelopList.infolist.length;j++){
            if (envelopList.infolist[j].pic !== ''){
              //console.log(j)
              envelopList.infolist[j].pic = envelopList.infolist[j].pic.split(',')
            }
          }
        
          that.setData({
            total: res.data.data.total,
            envelopList: envelopList
          })
        }
      }
    })
  },
  changeList:function(e){
    let that = this;
    let id = e.currentTarget.dataset.id;
    that.setData({
      selectId:id,
      envelopList:[],
      pager:1
    });
    that.getEnvelopeList(id)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    let that = this;
    if (that.data.total > that.data.pager * that.data.pagesize){
      that.setData({
        pager:that.data.pager+1
      })
      that.getEnvelopeList(that.data.selectId)
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  viewNewEnve:function(e){
    let that = this;
    let data = that.data.envelopList.infolist[0];
    if (data!=='undefined'){
      wx.navigateTo({
        url: '/pages/list/pages/envelopeToast/index?aid=' + data.aid + '&envelopeId=' + data.envelope_id,
      })
    }else{
      wx.showModal({
        title: '提示',
        content: '暂无发送红包记录,无明细',
      })
    }
  },
  inviteButton:function(e){
    let that = this;
    let payNum = e.currentTarget.dataset.paynum;
    let envelopeId = e.currentTarget.dataset.envelopeid;
    wx.navigateTo({
      url: '/pages/envelopeInvite/index?payNum=' + payNum + '&envelopeId=' + envelopeId,
    })
  }
})