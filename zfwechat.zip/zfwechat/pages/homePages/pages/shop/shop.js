// pages/home/shop/shop.js
var ajax = require('../../../../utils/request.js');
var config = require('../../../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    popupState: false,     // 显示隐藏购买弹窗，为true时显示
    popupSuccess: false,   // 购买成功弹窗
    shopList: [],
    pager: 1,
    canbeLoadMore: true,
    obj_id: '',              // 订单id
    price: '',               // 购买商品的价格
    integral: '',            // 购买商品获得的积分
    imgUrl: '',              // 购买的商品的图片
    headwear: '',            // 这个头饰是购买完成之后存入缓存
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.load();
  },

  load: function(){
    var wxInfo = wx.getStorageSync('wxInfo');
    var that = this;
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zforder/getGoodList',
      params: {
        aid: wxInfo.aid,
        loginid: wxInfo.aid,
        pager: '1',
        pagesize: '10'
      },
      success: function(res){
        // console.log(res.data)
        if(res.data.code == '0'){
          setTimeout(function () {
            wx.hideLoading();
          }, 500)
          // 片接图片地址
          var infolist = res.data.data.infolist
          // console.log(infolist)
          // for (var i = 0; i < infolist.length; i++) {
          //   // console.log(infolist[i].pic)
          //   infolist[i].pic = config.imgUrl + 'goods/' + infolist[i].pic
          // }
          // console.log(infolist)
          
          that.setData({
            shopList: infolist,
            pager: 1
          })

          // 如果列表长度小于10将不执行下拉加载的操作
          if (res.data.data.infolist.length < 10) {

            that.setData({
              canbeLoadMore: false
            })
          } else {

            that.setData({
              canbeLoadMore: true
            })
          }

        }else{
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
        
      }
    })
  },

  // 点击购买商品按钮
  buyClick:function(e){
    var obj_id = e.currentTarget.dataset.goodsid;
    var price = e.currentTarget.dataset.price;
    var integral = e.currentTarget.dataset.integral;
    var imgUrl = e.currentTarget.dataset.imgurl;
    var headwear = e.currentTarget.dataset.headwear;
    this.setData({
      popupState: true,
      obj_id: obj_id,
      price: price,
      integral: integral,
      imgUrl: imgUrl,
      headwear: headwear
    })
    
  },

  // 使用头饰
  headwear:function(e){
    var that = this;
    var goods_id = e.currentTarget.dataset.goodsid; // 头饰id（商品id）
    var headwearImg = e.currentTarget.dataset.imgurl; // 头饰图片
    var wxInfo = wx.getStorageSync('wxInfo');
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zforder/updateGoodBuy',
      params: {
        aid: wxInfo.aid,
        loginid: wxInfo.aid,
        goods_id: goods_id
      },
      success: function (res) {
        // console.log(res.data)
        if (res.data.code == '0') {
          setTimeout(function () {
            wx.hideLoading();
            wx.showToast({
              title: '使用成功！',
              success: function () {
                setTimeout(function () {
                  wxInfo.headwear = headwearImg;
                  wx.setStorage({
                    key: 'wxInfo',
                    data: wxInfo
                  })
                  that.load();// 重新渲染数据
                }, 1500)
              }
            })
          }, 500)
          
          
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })

  },

  // 关闭弹窗时间
  cancel01:function(){
    this.setData({
      popupState: false
    })
  },

  // 确认购买按钮
  confirm01:function(){
    var that = this;
    var wxInfo = wx.getStorageSync('wxInfo');
    var obj_id = this.data.obj_id;
    wx.showLoading({
      title: '处理中...',
    })
    // 生成订单
    ajax.GET({
      ajaxPoint: 'zforder/addGoodsOrder',
      params: {
        obj_id: obj_id,
        aid: wxInfo.aid,
        loginid: wxInfo.aid,
        order_type: '2'
      },
      success: function (res) {
        // console.log('----------订单--------')
        // console.log(res.data)
        if (res.data.code == '0') {

          // 支付
          ajax.GET({
            ajaxPoint: 'zforder/orderPayGoods',
            params: {
              order_id: res.data.data.order_id,
              pay_type: '2',
              loginid: wxInfo.aid
            },
            success: function (res) {
              // console.log('----------支付--------')
              // console.log(res.data)
              if (res.data.code == '0') {

                // 够买成功之后将头饰存入缓存中
                wxInfo.headwear = that.data.headwear;
                wx.setStorage({
                  key: 'wxInfo',
                  data: wxInfo
                })
                setTimeout(function(){
                  wx.hideLoading();
                  that.setData({
                    popupState: false,
                    popupSuccess: true
                  })
                }, 500)
                

              } else {
                wx.hideLoading();
                wx.showToast({
                  title: res.data.message,
                  icon: 'none'
                })
              }

            }
          })

        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
  },
  confirm02: function () {
    this.load()
    this.setData({
      popupSuccess: false
    })
  },
  setInfoList: function (data) {//存储获取的数据
    var newInfo = [];
    for (var i = 0; i < data.length; i++) {
      newInfo[i] = data[i]
    }
    // console.log('// 将获取的数据临时存储')
    // console.log(newInfo);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

    var that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zforder/getGoodList',
      params: {
        aid: wxInfo.aid,
        loginid: wxInfo.aid,
        pager: '1',
        pagesize: '10'
      },
      success: function (res) {
        // console.log('----------下拉刷新---------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          setTimeout(function(){
            wx.hideLoading();
          }, 500)
          var infolist = res.data.data.infolist;
          // 片接图片地址
          // for (var i = 0; i < infolist.length; i++) {
          //   infolist[i].pic = config.imgUrl + 'goods/' + infolist[i].pic
          // }
          that.setData({
            shopList: infolist,
            pager: 1
          })
          // that.setInfoList(infolist);//将获取的数据存放到此方法的数组中
          if (infolist.length < 10) {// 如果列表长度小于10将不执行下拉加载的操作
            that.setData({
              canbeLoadMore: false
            })
          } else {
            that.setData({
              canbeLoadMore: true
            })
          }


        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    if (this.data.canbeLoadMore) {
      var pager = this.data.pager;
      pager++;
      this.setData({
        pager: pager
      })
      const wxInfo = wx.getStorageSync('wxInfo');
      ajax.GET({
        ajaxPoint: 'zforder/getGoodList',
        params: {
          aid: wxInfo.aid,
          loginid: wxInfo.aid,
          pager: pager,
          pagesize: '10'
        },
        success: function (res) {
          // console.log('----------上拉加载---------')
          // console.log(res.data.data);
          if (res.data.code == '0') {

            // console.log(res.data.infolist);
            var infolist = res.data.data.infolist;

            // 片接图片地址
            // for (var i = 0; i < infolist.length; i++) {
            //   infolist[i].pic = config.imgUrl + 'goods/' + infolist[i].pic
            // }
            
            var newInfo = [];//存放刷新的数据
            for (var i = 0; i < infolist.length; i++) {
              newInfo[i] = infolist[i]
            }
            var dataList = that.data.shopList;
            for (var i = 0; i < newInfo.length; i++) {
              dataList.push(newInfo[i]);//把刷新的数据 push 到原来存放数据的数组中
            }
            // console.log(dataList);
            if (infolist.length == 0) {
              that.setData({
                shopList: dataList,
                canbeLoadMore: false
              })
              wx.showToast({
                title: '没有更多数据了',
              })
            } else {
              that.setData({
                shopList: dataList,
                canbeLoadMore: true
              })
              // console.log(that.data.infolist)
            }

          } else {
            wx.hideLoading();
            wx.showToast({
              title: res.data.message,
              icon: 'none'
            })
          }

        }
      })
    } else {
      wx.showToast({
        title: '没有更多数据了',
      })
    }
  }
})