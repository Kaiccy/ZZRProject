// pages/widthdrawWx/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    resize: { width: '375px', height: '375px', top: '-50%', left: '-10%', windowW: 0 },
    txNum:0
  },
  goInvite: function () {
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    wx.getSystemInfo({
      success: function (res) {
        console.log(res)
        let resize = {
          width: res.windowWidth * 2 + 'px',
          height: res.windowWidth * 2 + 'px',
          top: -res.windowWidth * 2 * 1.355 + 'px',
          left: -res.windowWidth * 2 * 0.5 + 'px',
          windowW: res.windowWidth + 'px'
        };
        that.setData({
          resize: resize,
          userInfo: userInfo
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    const wxInfo = wx.getStorageSync('wxInfo');
    return {
      title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
      path: '/pages/index/index?inviterphone=' + wxInfo.regphone,
      imageUrl: "../../static/images/shaBj.png",
      success: (res) => {
        console.log("转发成功", res);
      },
      fail: (res) => {
        console.log("转发失败", res);
      }
    }
  },
  getDetail:function(e){
    let that = this;
    console.log(e);
    that.setData({
      txNum: e.detail.value
    })
  },
  toTx:function(){
    let that = this;
    var num = that.data.txNum;
    console.log(num);
    if (num==''){
      wx.showModal({
        content: '提现金额不能为空',
      })
    } else if (String(num).length - (String(num).indexOf(".") + 1) > 2 && String(num).indexOf(".")>-1){
      wx.showModal({
        content: '最多支持两位小数',
      })
    } else if (that.data.userInfo.amount < num){
      wx.showModal({
        content: '提现金额不能超过余额',
      })
    }else{
      wx.redirectTo({
        url: '/pages/homePages/pages/withdraw/index?txNum='+num,
      })
    }
  }
})
