// pages/envelopeDetail/index.js
const ajax = require('../../../../utils/request.js');
const config = require('../../../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    resize: { width: '375px', height: '375px', top: '-50%', left: '-10%', windowW: 0},
    pager:1,
    pagesize:10,
    selected:[],
    reciveList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    let viewUserAid = options.aid;//查询当前红包
    let envelope_id = options.envelopeId;
    wx.getSystemInfo({
      success: function (res) {
        console.log(res)
        let resize = {
          width: res.windowWidth * 2 + 'px',
          height: res.windowWidth * 2 + 'px',
          top: -res.windowWidth * 2 * 1.024 + 'px',
          left: -res.windowWidth * 2 * 0.5 + 'px',
          windowW: res.windowWidth + 'px'
        };
        that.setData({
          resize: resize,
          userInfo: userInfo
        })
      }
    });
    ajax.GET({
      ajaxPoint:'zfenvelope/getEnvelopeReceiveList',
      params:{
        envelope_id: envelope_id,
        pager: that.data.pager,
        pagesize:that.data.pagesize,
        loginid:userInfo.loginid
      },
      success:function(res){
        if(res.data.code==0){
          var reciveList = [];
          var selected = [];
          console.log(viewUserAid);
          for (let i = 0; i < res.data.data.infolist.length;i++){
            if (res.data.data.infolist[i].aid==viewUserAid){
              selected = res.data.data.infolist[i]
            }else{
              reciveList.push(res.data.data.infolist[i])
            }
          }
          console.log(selected)
          console.log(reciveList)
          that.setData({
            selected: selected,
            reciveList: reciveList
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
})