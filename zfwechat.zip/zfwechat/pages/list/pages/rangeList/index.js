// pages/list/pages/rangeList/index.js
const app = getApp();
const ajax = require('../../../../utils/request.js');
const config = require('../../../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    rangeList:[],
    pager:1,
    pagesize:5,
    total:[],
    selectList:[
      {name:'商圈排行',id:0},
      {name:'好友排行',id:1}
    ],
    selectId: 0,
    userInfo:[],
    rowNum:-1,
    amount:0
  },
  goInvite: function () {
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo) {
      ajax.GET({
        ajaxPoint: 'zfenvelope/getEnvelopeSendRankList',
        params: {
          type: that.data.selectId + 1,
          pager: that.data.pager,
          pagesize: that.data.pagesize,
          loginid: userInfo.loginid
        },
        success: function (res) {
          if(res.data.code==0){
            let rangeList = res.data.data.infolist;
            that.setData({
              rangeList: rangeList,
              userInfo: userInfo,
              total: res.data.data.total,
              rowNum: res.data.data.rownum,
              amount: res.data.data.amount
            })
          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    let that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    // console.log(wxInfo.aid)
    if (res.from === 'button') {
      console.log("来自页面内转发按钮");
      console.log(res.target);
    }
    return {
      title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
      imageUrl: "../../static/images/shaBj.png",
      path: '/pages/index/index?inviterphone=' + wxInfo.regphone,
      // imageUrl: '../../../static/images/33@2x.png'
      success: function (res) {
        // 转发成功
        console.log("转发成功:");
        ajax.GET({
          ajaxPoint: 'zfaccount/shareIntegralInfo',
          params: {
            loginid: wxInfo.loginid,
            share_type: 1
          },
          success:function(res){
            console.log('转发成功')
          }
        })
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:");
      }
    }
  },


  /* 点击加载更多排名 */
  addMore:function(){
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if(userInfo){
      if (that.data.total > that.data.pager * that.data.pagesize) {
        let pager = that.data.pager + 1;
        that.getRangeList(that.data.selectId + 1, pager, that.data.pagesize)
      }else{
        wx.showToast({
          icon:'none',
          title: '没有更多数据了',
        })
      }
    }
  },
  getRangeList: function (type,pager,pagesize){
    let that = this;
    ajax.GET({
      ajaxPoint: 'zfenvelope/getEnvelopeSendRankList',
      params: {
        type: type,
        pager: pager,
        pagesize: pagesize,
        loginid: that.data.userInfo.loginid
      },
      success: function (res) {
        if (res.data.code == 0) {
          let rangeListOld = that.data.rangeList;
          let rangeList = res.data.data.infolist;
          for (let i = 0; i < rangeList.length; i++) {
            rangeListOld.push(rangeList[i])
          }
          that.setData({
            rangeList: rangeListOld,
            pager: pager,
            total:res.data.data.total,
            rowNum: res.data.data.rownum,
            amount: res.data.data.amount
          })
        }
      }
    })
  },
  goPersonal:function(e){
    let wxInfo = wx.getStorageSync('wxInfo');
    let aid = e.currentTarget.dataset.aid;
    if (aid == wxInfo.loginid) {
      wx.navigateTo({
        url: '/pages/homePages/pages/personalPage/index',
      })
    } else {
      wx.navigateTo({
        url: '/pages/homePages/pages/personPageOther/index?aid=' + aid,
      })
    }
  },
  changeSelect:function(e){
    let that = this;
    let selectId = e.currentTarget.dataset.id;
    let pager = 1;
    that.setData({
      selectId: selectId,
      pager: pager,
      rangeList:[],
      total:0,
      rowNum: -1,
      amount: 0
    })
    that.getRangeList(selectId+1,pager,that.data.pagesize)
  }
})