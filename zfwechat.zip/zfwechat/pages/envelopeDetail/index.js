// pages/envelopeDetail/index.js
const ajax = require('../../utils/request.js');
const config = require('../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    resize: { width: '375px', height: '375px', top: '-50%', left: '-10%',windowW:0},
    envelopeInfo:[],
    envelopeRequest:[],
    envelopeRecive:[],
    showMore:false,
    viewMore:false,
    comment:'',
    userInfo:[],
    notimes:false,
    pager:1,
    pagesize:10,
    total:0,
    timer:0,
    showTimes:false,
    zlShow: false, //助力值
    zlz: '',//助力值,
    dataFrom:0
  },
  goInvite: function () {
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    wx.getSystemInfo({
      success: function (res) {
        console.log(res)
        let resize = {
          width: res.windowWidth * 2 + 'px',
          height: res.windowWidth * 2 + 'px',
          top: -res.windowWidth * 2 * 1.055 + 'px',
          left: -res.windowWidth * 2 * 0.5 + 'px',
          windowW: res.windowWidth+'px'
        };
        that.setData({
          resize: resize,
          userInfo: userInfo
        })
      },
    })
    if (options.form) {
      that.setData({
        dataFrom: options.form
      })
    }
    let envelopeId = options.envelopeId;
    if (userInfo) {
      that.getEnvelopeInfo(options.envelopeId,userInfo.loginid,1);
      that.getEnvelopeRequst(options.envelopeId, userInfo.loginid, that.data.pager,that.data.pagesize);
      that.getEnvelopeRecive(options.envelopeId, userInfo.loginid,1,8);
      if (options.time) {
        let time = options.time/1000
        that.setData({
          timer: time,
          showTimes:true
        });
        var timeOut = setInterval(function(){
          let timeNow = that.data.timer;
          timeNow--;
          that.setData({
            timer: timeNow
          })
          if (timeNow==0){
            clearInterval(timeOut)
          }
        },1000)
      }
    }
    if (options.noTimes){
      that.setData({
        notimes:true
      })
    }
  },
  getEnvelopeInfo: function (envelope_id, loginid,type){
    let that = this;
    wx.showLoading({
      title: '正在加载',
    })
    ajax.GET({
      ajaxPoint: 'zfenvelope/getEnvelopeInfo',
      params: {
        envelope_id: envelope_id,
        loginid: loginid,
        type: type
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.code == 0) {
          let envelopeInfo = res.data.data;
          if (envelopeInfo.pic!=='') {
            envelopeInfo.pic = envelopeInfo.pic.split(',')
          }
          envelopeInfo.nickname = decodeURI(envelopeInfo.nickname);
          that.setData({
            envelopeInfo: envelopeInfo
          })
        }
      },
      fail:function(res){
        wx.showModal({
          showCancel:false,
          content: res.data.message,
        })
      }
    })
  },
  getEnvelopeRequst: function (envelope_id, loginid,pager,pagesize){
    let that = this;
    ajax.GET({
      ajaxPoint:'zfenvelope/getEnvelopeCommentList',
      params:{
        envelope_id: envelope_id,
        loginid: loginid,
        pager: pager, pagesize: pagesize
      },
      success:function(res){
        if(res.data.code==0){
          let newData = res.data.data;
          var envelopeRequest = that.data.envelopeRequest;
          if(envelopeRequest.infolist){
            for (let i = 0; i < newData.infolist.length; i++) {
              envelopeRequest.infolist.push(newData.infolist[i])
            }
            console.log(envelopeRequest)
          }else{
            envelopeRequest = newData
          }
          that.setData({
            envelopeRequest: envelopeRequest,
            total: res.data.data.total
          })
        }
      }
    })
  },
  getEnvelopeRecive: function (envelope_id,loginid,pager,pagesize){
    let that = this;
    ajax.GET({
      ajaxPoint:'zfenvelope/getEnvelopeReceiveList',
      params:{
        envelope_id: envelope_id,
        loginid: loginid,
        pager: pager,
        pagesize: pagesize
      },
      success:function(res){
        if(res.data.code==0){
          that.setData({
            envelopeRecive:res.data.data
          });
          if(res.data.data.total>7){
            that.setData({
              showMore: true
            });
          }else{
            that.setData({
              showMore: false
            });
          }
        }
      }
    })
  },
  viewMoreUser:function(){
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo) {
      if (that.data.viewMore) {
        that.getEnvelopeRecive(that.data.envelopeInfo.envelope_id,userInfo.loginid,1,8)
      }else{
        that.getEnvelopeRecive(that.data.envelopeInfo.envelope_id, userInfo.loginid)
      }
      that.setData({
        showMore: !that.data.showMore
      })
    }
  },
  viewDetail:function(e){
    let that = this;
    console.log(e);
    let userAid = e.currentTarget.dataset.useraid; //用户的唯一标识 aid。查看红包明细 与 跳转个人主页 标识
    if (wx.getStorageSync('wxInfo')){
      let userInfo = wx.getStorageSync('wxInfo');
      let user_type = userInfo.level_type.code;
      
      if (that.data.envelopeInfo.aid == userInfo.loginid) { //如果是当前用户自己的红包。查看红包明细
        let envelopeId = that.data.envelopeInfo.envelope_id;
        wx.navigateTo({
          url: '/pages/list/pages/envelopeRecive/index?aid=' + userAid + '&envelopeId=' + envelopeId,
        })
      } else {  //如果不是当前用户的红包，就去个人主页
        if(userAid==userInfo.loginid){ //如果点击自己的头像,去自己的主页
          wx.navigateTo({
            url: '/pages/homePages/pages/personalPage/index',
          })
        }else{ //否则去别人的主页
          wx.navigateTo({
            url: '/pages/homePages/pages/personPageOther/index?aid=' + userAid,
          })
        }
      }
    }
  },
  setComment:function(e){
    let that = this;
    that.setData({
      comment: e.detail.value
    })
  },
  sendComment:function(){
    let that = this;


    if(that.data.comment!==''){
      let str = that.data.comment;
      var regu = "^[ ]+$";
      var re = new RegExp(regu);
      //为空或纯空格为 true    有值为false
      if (re.test(str)){
        wx.showModal({
          title: '提示',
          content: '评论不能全为空格哟~',
          showCancel: false
        })
        that.setData({
          comment:''
        })
      }else{
        let userInfo = wx.getStorageSync('wxInfo');
        console.log(encodeURI(that.data.comment))
        if (userInfo) {
          ajax.GET({
            ajaxPoint: 'zfenvelope/addEnvelopeComment',
            params: {
              envelope_id: that.data.envelopeInfo.envelope_id,
              content: that.data.comment,
              loginid: userInfo.loginid
            },
            success: function (res) {
              if (res.data.code == 0) {
                wx.showToast({
                  title: '评论发送成功',
                });
                that.setData({
                  comment: '',
                  pager:1,
                  total:0,
                  envelopeRequest:[]
                });
                that.getEnvelopeRequst(that.data.envelopeInfo.envelope_id, userInfo.loginid, 1, 10);
              } else {
                wx.showToast({
                  icon:'none',
                  title: res.data.message,
                });
              }
            }
          })
        }
      }
    }else{
      wx.showModal({
        title: '提示',
        content: '评论不能为空哦~',
        showCancel:false
      })
    }
  },
  viewImg:function(e){
    let that = this;
    wx.previewImage({
      current: that.data.envelopeInfo.pic[e.currentTarget.dataset.index],
      urls: that.data.envelopeInfo.pic,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    let that = this;
    let pager = that.data.pager;
    let pagesize = that.data.pagesize;
    let total = that.data.total;
    let userInfo = wx.getStorageSync('wxInfo');
    if (total > pager*pagesize){
      that.getEnvelopeRequst(that.data.envelopeInfo.envelope_id, userInfo.loginid,pager+1,pagesize);
      that.setData({
        pager:pager+1
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    let that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    // console.log(wxInfo.aid)
    return {
      title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
      imageUrl: "/static/images/shaBj.png",
      path: '/pages/index/index?inviterphone=' + wxInfo.regphone + '&envelopeId=' + that.data.envelopeInfo.envelope_id,
      // imageUrl: '../../../static/images/33@2x.png'
      success: function (res) {
        // 转发成功
        console.log("转发成功:");
        ajax.GET({
          ajaxPoint: 'zfaccount/shareIntegralInfo',
          params: {
            loginid: wxInfo.loginid,
            share_type: 1
          }
        })
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:");
      }
    }
  },
  closePage:function(){
    let that = this;
    let timer = that.data.timer;
    if(timer==0){
      if(that.data.dataFrom!==0){
        wx.reLaunch({
          url: '/pages/tradingArea/index',
        })
      }else{
        wx.reLaunch({
          url: '/pages/index/index',
        })
      }
    }
  },
  bindTouchStart: function (e) {
    this.startTime = e.timeStamp;
  },
  bindTouchEnd: function (e) {
    this.endTime = e.timeStamp;
  },
  addNum: function (e) {
    let that = this;
    if (that.endTime - that.startTime < 350) {
      that.addPower(e.currentTarget.dataset.id, 1)
    }
  },
  addNumFree: function (e) {
    let that = this;
    that.setData({
      zlShow: true,
      selectZlId: e.currentTarget.dataset.id
    })
  },
  addPower: function (id, num) {
    let that = this;
    ajax.GET({
      ajaxPoint: 'zfenvelope/addEnvelopePower',
      params: {
        envelope_id: id,
        power: num,
        loginid: that.data.userInfo.loginid
      },
      success: function (res) {
        if (res.data.code == 0) {
          wx.showModal({
            content: '红包助力成功',
            showCancel: false,
          })
          let envelop = that.data.envelopeInfo;
          envelop.power += Number(num);
          that.setData({
            envelopeInfo: envelop
          })
        } else {
          wx.showModal({
            content: res.data.message,
            showCancel: false,
          })
        }
        that.setData({
          zlShow: false,
          zlz: '',
          selectZlId: 0
        })
        that.onShow();
      }
    })
  },
  ajaxModal: function () {
    let that = this;
    if (that.data.zlz > 0 && that.data.zlz !== '') {
      that.addPower(that.data.selectZlId, that.data.zlz)
    } else {
      wx.showModal({
        content: '助力值不能为0',
        showCancel: false
      })
    }
  },
  hideModal: function () {
    this.setData({
      zlShow: false,
      zlz: ''
    })
  },
  getZlz: function (e) {
    let code = e.detail.value;
    this.setData({
      zlz: e.detail.value
    })
  },
})