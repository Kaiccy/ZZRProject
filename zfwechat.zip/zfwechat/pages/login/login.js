// pages/login/login.js
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    timeTitle: '发送验证码',   //  点击获取验证码显示的内容
    yzCodeState: true,        // 根据验证码的状态显示读秒
    phone: '',               // 手机号码
    phoneState: false,       // 验证手机号是否符合规范的状态
    yzm: '',                  // 验证码
    yzmClick: true,            // 是否可以点击发送验证码
    // btnState: false           // 判断手机号和验证码是否填写的状态
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.login();
  },
  // 获取手机号
  phoneClick: function (e) {
    // console.log(e);

    this.setData({
      phone: e.detail.value
    })
    if (e.detail.value == '') {
      this.setData({
        phoneState: false
      })
    } else {
      let phone = /^1[34578]\d{9}$/;
      if (phone.test(e.detail.value)) {
        this.setData({
          phoneState: false
        })
      } else {
        this.setData({
          phoneState: true
        })
      }
    }

    if (this.phone != '' && this.yzm != '') { // 如果手机号和验证码都不为空则设为true
      if (this.data.phoneState == false) {
        this.setData({
          btnState: true
        })
      } else {
        this.setData({
          btnState: false
        })
      }
    } else {
      // this.btnState = false
      this.setData({
        btnState: false
      })
    }
  },

  // ajax获取验证码
  yzmClick: function () {
    let that = this;
    if (this.data.yzmClick == true){
      if (this.data.phone == '') {
        wx.showToast({
          title: '手机号码不能为空！',
          icon: 'none'
        })
      } else if (this.data.phoneState == true) {
        wx.showToast({
          title: '手机号码格式不正确！',
          icon: 'none'
        })
      } else {
        // 发送验证码
        ajax.GET({
          ajaxPoint: 'zfaccount/getCode',
          params: { phone: that.data.phone },
          success: function (res) {
            // console.log(res.data)
            if (res.data.code == '0') {
              wx.showToast({
                title: '发送成功！'
              })
              // 倒计时
              if (that.data.yzCodeState == true) {
                let time = 60;
                let timer = setInterval(function () {
                  time--;
                  if (time < 0) {
                    that.setData({
                      timeTitle: '获取验证码',
                      yzCodeState: true,
                      yzmClick: true
                    })
                    clearInterval(timer);
                  } else {
                    that.setData({
                      timeTitle: time + '秒后重新发送',
                      yzCodeState: false,
                      yzmClick: false
                    })
                  }
                }, 1000);
              }
            } else {
              wx.showToast({
                title: res.data.message,
                icon: 'none'
              })
            }
          }
        });


      }
    }else{
      wx.showToast({
        title: '请勿重复点击',
        icon: 'none'
      })
    }
    


  },

  // 获取填写的验证码
  yzmCode: function (e) {
    // this.data.yzm = e.detail.value;
    this.setData({
      yzm: e.detail.value
    })

  },


  loginBtn:function(){
    // console.log(this.data.phone, this.data.yzm)
    let that = this;
    if (this.data.phone != '' && this.data.yzm != ''){
      if (this.data.phoneState){
        wx.showToast({
          title: '手机号码格式不正确',
          icon: 'none'
        })
      }else{
        
        wx.showLoading({
          title: '加载中...',
        })
        const wxInfo = wx.getStorageSync('wxInfo')
        var inviterphone = ''
        if (wx.getStorageSync('inviterphone')){
          inviterphone = wx.getStorageSync('inviterphone')
        }
        // console.log(inviterphone)
        
        // 登录
        ajax.GET({
          ajaxPoint: 'zfaccount/loginWxByPhone',
          params: {
            regphone: that.data.phone,
            code: that.data.yzm,
            inviterphone: inviterphone,
            openid: wxInfo.openid_xcx,
            unionid: wxInfo.unionid
          },
          success: function (res) {
            console.log(res.data);
            if (res.data.code == '0') {

              wx.showToast({
                title: '登录成功！',
                icon: 'success'
              })

              // 如果经过邀请人进来注册的，完成注册之后删除邀请人手机号，因为个人信息中已经带有邀请人信息
              if (wx.getStorageSync('inviterphone')){
                wx.removeStorageSync('inviterphone')
              }

              // 保存loginid
              wx.setStorage({
                key: 'loginid',
                data: res.data.data.loginid
              })

              // 保存token
              wx.setStorage({
                key: 'token',
                data: res.data.data.token
              })

              // 将获取到的个人信息存储到缓存中
              wx.setStorage({
                key: 'wxInfo',
                data: res.data.data,
                success: function () {
                  wx.hideLoading();
                  wx.reLaunch({
                    url: '../index/index',
                  })
                },
                fail: function (res) {
                  wx.hideLoading();
                }
              })
            } else {
              wx.hideLoading();
              wx.showToast({
                title: res.data.message,
                icon: 'none'
              })
            }

          }
        })
      }
    }else{
      wx.showToast({
        title: '必填项未填写！',
        icon: 'none'
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})