// pages/find/find.js
const ajax = require('../../utils/request.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    getUserModal: false //授权窗口
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  myTreeClick:function(){
    wx.navigateTo({
      url: '../treePages/pages/myTree/myTree',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this;

    // that.getLocation();
    if (wx.getStorageSync('wxInfo')) {
      let userInfo = wx.getStorageSync('wxInfo');
      if (userInfo.aid == '') {　 // 已授权未登录
        wx.hideLoading();
        wx.redirectTo({
          url: '../login/login'
        })
      } else {
        
      }
    } else {
      that.setData({
        getUserModal: true
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /* 获取用户授权 */
  getUserInfo: function (e) {
    // console.log(e)
    let that = this;
    var userInfo = e.detail.userInfo; // 点击允许按钮获取到的个人信息+
    if (userInfo) {
      //用户按了允许授权按钮
      // console.log('用户按了允许授权按钮');
      var encryptedData = e.detail.encryptedData;
      var iv = e.detail.iv;
      // console.log('encryptedData:' + encryptedData)
      // console.log('iv:' + iv)
      wx.showLoading({
        title: '加载中...',
        mask: true
      });
      wx.login({ // 登录获取code
        success: res => {
          let code = res.code;
          console.log('code:' + code);
          let params = {
            code: code,
            encryptedData: encodeURIComponent(encryptedData),
            iv: encodeURIComponent(iv),
            nickname: userInfo.nickName,
            headimgurl: userInfo.avatarUrl
          };
          // 用code向后台换取微信信息
          ajax.POST({
            ajaxPoint: 'https://zf.cube-tech.cn/zfaccount/getWxOpenId',
            // ajaxPoint: 'http://192.168.0.181:4002/getWxOpenId',
            params: params,
            success: function (res) {
              console.log(res.data);
              wx.hideLoading();
              that.setData({
                getUserModal: false
              })
              if (res.data.code == '0') {
                // 将获取到的个人信息存储到缓存中
                // 保存loginid
                wx.setStorage({
                  key: 'loginid',
                  data: res.data.data.loginid
                })
                // 保存token
                wx.setStorage({
                  key: 'token',
                  data: res.data.data.token
                })
                // 保存微信信息
                wx.setStorage({
                  key: 'wxInfo',
                  data: res.data.data,
                  success: function () {
                    wx.hideLoading();
                  },
                  fail: function (res) {
                    wx.hideLoading();
                  }
                })
                if (res.data.data.aid == '') {
                  wx.redirectTo({
                    url: '/pages/login/login'
                  })
                } else {
                  wx.reLaunch({
                    url: '/pages/index/index',
                  })
                }
              } else {
                wx.hideLoading();
                wx.showToast({
                  title: res.data.message,
                  icon: 'none'
                })
              }

            }
          })
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '登录出错,请检查网络',
            icon: 'none',
            mask: true
          })
        }
      })
    } else {
      //用户按了拒绝按钮
      // console.log('用户按了拒绝按钮');
      wx.showModal({
        title: '提示',
        content: '小程序需要您的微信授权才能使用哦！'
      })
    }
  }
})