// pages/tradingArea/index.js
const config = require('../../config.js');
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLCJhEF9qDfk0SBUuy6zszRAjicAibGribMJDliaKarvPKO07oQUcZgOicm6RF0ZNkFsWYPeUdwoFIaGWg/132',
    animation: '',
    animation1: '',
    rpList: [],
    show: false,
    fbHb: false, //发送红包
    zlShow: false, //助力值
    noTimes: false,
    userInfo: [],
    pager: 1,
    total: 0,
    imgUrl: '',
    selectRp: [], //当前选择红包信息
    selectZlId:0,//当前添加助力值编号
    zlz:'',//助力值
    getUserModal: false //授权窗口
  },
  goInvite: function () {
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let userInfo = wx.getStorageSync('wxInfo');
    let imgUrl = config.imgUrl;
    this.setData({
      userInfo: userInfo,
      imgUrl: imgUrl
    })
  },
  hbGb(e) {
    wx.navigateTo({
      url: '/pages/addEnvelope/normalEnve/index',
    })
  },
  hbSp(e) {
    wx.navigateTo({
      url: '/pages/addEnvelope/tbEnve/index',
    })
  },
  hbYy(e) {
    wx.navigateTo({
      url: '/pages/addEnvelope/appsEnve/index',
    })
  },
  viewDetail:function(e){
    let that = this;
    let enveId = e.currentTarget.dataset.enveid;
    let state = e.currentTarget.dataset.lqstate;
    if(state==0){
      wx.showLoading({
        title: '正在加载',
      });
      let userInfo = wx.getStorageSync('wxInfo');
      if (userInfo.envelope_times + userInfo.envelope_times_add == 0) {
        wx.hideLoading()
        that.setData({
          show: false,
          selectRp: [],
          noTimes: true
        })
      } else {
        for (let i = 0; i < that.data.rpList.length; i++) {
          if (that.data.rpList[i].envelope_id == enveId) {
            let data = that.data.rpList[i];
            if (data.is_grab == '0') {
              ajax.GET({
                ajaxPoint: 'zfenvelope/grabEnvelope',
                params: {
                  loginid: userInfo.loginid,
                  envelope_id: enveId
                },
                success: function (res) {
                  wx.hideLoading();
                  if (res.data.code == 0) {
                    userInfo.envelope_times = res.data.data.envelope_times;
                    userInfo.envelope_times_add = res.data.data.envelope_times_add;
                    wx.redirectTo({
                      url: '/pages/envelopeDetail/index?time=5000&form=tarea&envelopeId=' + enveId,
                    })
                    that.login();
                  } else if (res.data.code == 9999) {
                    wx.showModal({
                      title: '提示',
                      content: res.data.message,
                    });
                    that.setData({
                      show: false,
                      selectRp: []
                    })
                  } else {
                    wx.redirectTo({
                      url: '/pages/envelopeDetail/index?time=5000&form=tarea&envelopeId=' + enveId,
                    })
                  }
                }
              })
            } else {
              wx.redirectTo({
                url: '/pages/envelopeDetail/index?time=5000&form=tarea&envelopeId=' + enveId,
              })
            }
          }
        }
        //查看详情 如果有剩余次数,抢完红包在进入详情页
      }
    }else{
      let aid = e.currentTarget.dataset.aid;
      let userInfo = wx.getStorageSync('wxInfo')
      if(userInfo.loginid == aid){
        wx.navigateTo({
          url: '/pages/homePages/pages/personalPage/index',
        })
      }else{
        wx.navigateTo({
          url: '/pages/homePages/pages/personPageOther/index',
        })
      }
    }
  },
  openRB(e) {
    wx.showLoading({
      title: '打开红包',
    })
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo) {
      if (userInfo.envelope_times + userInfo.envelope_times_add!==0){
        ajax.GET({
          ajaxPoint: 'zfenvelope/grabEnvelope',
          params: {
            loginid: userInfo.loginid,
            envelope_id: that.data.selectRp.envelope_id
          },
          success: function (res) {
            wx.hideLoading();
            if (res.data.code == 0) {
              userInfo.envelope_times = res.data.data.envelope_times;
              userInfo.envelope_times_add = res.data.data.envelope_times_add;
              wx.redirectTo({
                url: '/pages/envelopeDetail/index?time=5000&form=tarea&envelopeId=' + that.data.selectRp.envelope_id,
              })
              that.login();
            } else if(res.data.code==9999){
              wx.showModal({
                title: '提示',
                content: res.data.message,
              });
              that.setData({
                show: false,
                selectRp: []
              })
            }else{
              wx.redirectTo({
                url: '/pages/envelopeDetail/index?time=5000&form=tarea&envelopeId=' + that.data.selectRp.envelope_id,
              })
            }
          }
        })
      }else{
        wx.hideLoading()
        that.setData({
          show: false,
          selectRp: [],
          noTimes:true
        })
        //红包次数不足,邀请弹窗出现
      }
    }
  },
  addBag(e) {
    let that = this;
    // that.setData({
    //   fbHb: true
    // })
    wx.navigateTo({
      url: '/pages/addEnvelope/normalEnve/index',
    })
  },
  closeAddHb(e) {
    let that = this;
    that.setData({
      fbHb: false
    })
  },
  closeRedPoint(e) {
    console.log(e);
    let that = this;
    that.setData({
      animation: '',
      animation1: '',
      show: false
    })
  },
  makertap(e) {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo.envelope_times + userInfo.envelope_times_add!==0){
      wx.showLoading({
        title: '打开红包',
      })
      let envelopeId = e.currentTarget.dataset.id;
      for (let i = 0; i < that.data.rpList.length; i++) {
        if (envelopeId == that.data.rpList[i].envelope_id) {
          wx.hideLoading();
          let data = that.data.rpList[i];
          data.nickname = decodeURI(data.nickname)
          that.setData({
            selectRp: data,
            show: true
          });
        }
      }
    } else {
      that.setData({
        noTimes:true
      })
    }
  },
  bindTouchStart: function (e) {
    this.startTime = e.timeStamp;
  },
  bindTouchEnd: function (e) {
    this.endTime = e.timeStamp;
  },
  addNum: function(e) {
    let that = this;
    if (that.endTime - that.startTime < 350) {
      that.addPower(e.currentTarget.dataset.id, 1)
    }
  },
  getZlz:function(e){
    let code = e.detail.value;
    this.setData({
      zlz: e.detail.value
    })
  },
  addNumFree: function(e) {
    let that = this;
    that.setData({
      zlShow: true,
      selectZlId: e.currentTarget.dataset.id
    })
  },
  addPower: function(id, num) {
    let that = this;
    ajax.GET({
      ajaxPoint: 'zfenvelope/addEnvelopePower',
      params: {
        envelope_id: id,
        power: num,
        loginid: that.data.userInfo.loginid
      },
      success: function(res) {
        if (res.data.code == 0) {
          wx.showModal({
            content: '红包助力成功',
            showCancel: false,
          })
        } else {
          wx.showModal({
            content: res.data.message,
            showCancel: false,
          })
        }
        that.setData({
          zlShow:false,
          zlz:'',
          selectZlId:0
        })
        that.onShow();
      }
    })
  },
  ajaxModal:function(){
    let that = this;
    if (that.data.zlz > 0 && that.data.zlz!=='') {
      that.addPower(that.data.selectZlId, that.data.zlz)
    } else {
      wx.showModal({
        content: '助力值不能为0',
        showCancel: false
      })
    }
  },
  hideModal:function(){
    this.setData({
      zlShow:false,
      zlz:''
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;

    // that.getLocation();
    if (wx.getStorageSync('wxInfo')) {
      let userInfo = wx.getStorageSync('wxInfo');
      if (userInfo.aid == '') {　 // 已授权未登录
        wx.hideLoading();
        wx.redirectTo({
          url: '../login/login'
        })
      } else {
        that.setData({
          show: false,
          fbHb: false, //发送红包
          zlShow: false, //助力值
          pager: 1
        });
        that.login();
        that.getEnvelope()
      }
    } else {
      that.setData({
        getUserModal: true
      })
    }
  },
  /*获取商圈红包 */
  getEnvelope: function() {
    let that = this;
    wx.showLoading({
      title: '正在加载',
    })
    wx.getLocation({
      success: function(res) {
        wx.hideLoading();
        ajax.GET({
          ajaxPoint: 'zfenvelope/getEnvelopeAreaListForWX',
          params: {
            longitude: res.longitude,
            latitude: res.latitude,
            loginid: that.data.userInfo.loginid,
            pagesize: 10,
            pager: that.data.pager
          },
          success: function(resdata) {
            if (resdata.data.code == 0) {
              let rpList = resdata.data.data.infolist;
              for (let i = 0; i < rpList.length; i++) {
                if(rpList[i].pic!==''){
                  rpList[i].pic = rpList[i].pic.split(',');
                }
                rpList[i].nickname = decodeURI(rpList[i].nickname)
              }
              //console.log(rpList);
              that.setData({
                rpList: rpList,
                total: resdata.data.data.total
              })
            } else {
              wx.showModal({
                title: '提示',
                content: '红包池获取失败,点击确定重新加载',
                success(res) {
                  if (res.confirm) {
                    that.getEnvelope()
                  }
                }
              })
            }
          }
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    let that =this;
    that.onShow();
    wx.stopPullDownRefresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    let that = this;
    let total = that.data.total;
    let pager = that.data.pager;
    if (pager * 10 < total) {
      pager += 1;
      wx.showLoading({
        title: '正在加载',
      })
      wx.getLocation({
        success: function(res) {
          wx.hideLoading();
          ajax.GET({
            ajaxPoint: 'zfenvelope/getEnvelopeAreaListForWX',
            params: {
              longitude: res.longitude,
              latitude: res.latitude,
              loginid: that.data.userInfo.loginid,
              pagesize: 10,
              pager: pager
            },
            success: function(resdata) {
              if (resdata.data.code == 0) {
                let newList = that.data.rpList;
                let rpList = resdata.data.data.infolist;
                for (let i = 0; i < rpList.length; i++) {
                  if (rpList[i].pic!==''){
                    rpList[i].pic = rpList[i].pic.split(',')
                  }
                  rpList[i].nickname = decodeURIComponent(rpList[i].nickname);
                  newList.push(rpList[i])
                };
                that.setData({
                  rpList: newList,
                  total: resdata.data.data.total,
                  pager: pager
                })
              } else {
                wx.showModal({
                  title: '提示',
                  content: '红包池获取失败,点击确定重新加载',
                  success(res) {
                    if (res.confirm) {
                      that.getEnvelope()
                    }
                  }
                })
              }
            }
          })
        }
      })
    }
  },
  viewImg:function(e){
    let that = this;
    let data = that.data.rpList[e.currentTarget.dataset.id].pic;
    console.log(data[e.currentTarget.dataset.picid]);
    wx.previewImage({
      current: data[e.currentTarget.dataset.picid],
      urls: data,
    })
  },
  viewTree: function () {
    wx.navigateTo({
      url: '../treePages/pages/myTree/myTree',
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    let that = this;
    that.setData({
      noTimes: false
    });
    const wxInfo = wx.getStorageSync('wxInfo');
    // console.log(wxInfo.aid)
    return {
      title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
      imageUrl: "/static/images/shaBj.png",
      path: '/pages/index/index?inviterphone=' + wxInfo.regphone,
      success: function (res) {
        // 转发成功
        console.log("转发成功:");
        ajax.GET({
          ajaxPoint: 'zfaccount/shareIntegralInfo',
          params: {
            loginid: wxInfo.loginid,
            share_type: 1
          }
        })
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:");
      }
    }
  },

  closeinviteContent: function () {
    let that = this;
    that.setData({
      noTimes: false
    })
  },
  viewRange: function () {
    wx.navigateTo({
      url: '../list/pages/zlzList/index',
    })
  },
  login: function () {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    let loginid = wx.getStorageSync('loginid');
    let token = wx.getStorageSync('token');

    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    ajax.GET({
      ajaxPoint: 'zfaccount/getAccountInfo',
      params: {
        aid: userInfo.aid,
        loginid: userInfo.loginid
      },
      success: function (res) {
        console.log(res.data.data);
        if (res.data.code == '0') {
          // 将获取到的个人信息存储到缓存中
          let data = res.data.data;
          data.token = token;
          data.loginid = loginid;
          //console.log(data);
          wx.setStorage({
            key: 'wxInfo',
            data: data,
            success: function () {
              wx.hideLoading();
              that.setData({
                userInfo: data
              })
            },
            fail: function (res) {
              wx.hideLoading();
              wx.showToast({
                title: '缓存出错！',
                icon: 'none'
              })
            }
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      },
      fail: function (res) {
        wx.hideLoading();
        wx.showToast({
          title: '网络错误！',
          icon: 'none'
        })
      }
    })
  },
  /* 获取用户授权 */
  getUserInfo: function (e) {
    // console.log(e)
    let that = this;
    var userInfo = e.detail.userInfo; // 点击允许按钮获取到的个人信息+
    if (userInfo) {
      //用户按了允许授权按钮
      // console.log('用户按了允许授权按钮');
      var encryptedData = e.detail.encryptedData;
      var iv = e.detail.iv;
      // console.log('encryptedData:' + encryptedData)
      // console.log('iv:' + iv)
      wx.showLoading({
        title: '加载中...',
        mask: true
      });
      wx.login({ // 登录获取code
        success: res => {
          let code = res.code;
          console.log('code:' + code);
          let params = {
            code: code,
            encryptedData: encodeURIComponent(encryptedData),
            iv: encodeURIComponent(iv),
            nickname: userInfo.nickName,
            headimgurl: userInfo.avatarUrl
          };
          // 用code向后台换取微信信息
          ajax.POST({
            ajaxPoint: 'https://zf.cube-tech.cn/zfaccount/getWxOpenId',
            // ajaxPoint: 'http://192.168.0.181:4002/getWxOpenId',
            params: params,
            success: function (res) {
              console.log(res.data);
              wx.hideLoading();
              that.setData({
                getUserModal: false
              })
              if (res.data.code == '0') {
                // 将获取到的个人信息存储到缓存中
                // 保存loginid
                wx.setStorage({
                  key: 'loginid',
                  data: res.data.data.loginid
                })
                // 保存token
                wx.setStorage({
                  key: 'token',
                  data: res.data.data.token
                })
                // 保存微信信息
                wx.setStorage({
                  key: 'wxInfo',
                  data: res.data.data,
                  success: function () {
                    wx.hideLoading();
                  },
                  fail: function (res) {
                    wx.hideLoading();
                  }
                })
                if (res.data.data.aid == '') {
                  wx.redirectTo({
                    url: '/pages/login/login'
                  })
                } else {
                  wx.reLaunch({
                    url: '/pages/index/index',
                  })
                }
              } else {
                wx.hideLoading();
                wx.showToast({
                  title: res.data.message,
                  icon: 'none'
                })
              }

            }
          })
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '登录出错,请检查网络',
            icon: 'none',
            mask: true
          })
        }
      })
    } else {
      //用户按了拒绝按钮
      // console.log('用户按了拒绝按钮');
      wx.showModal({
        title: '提示',
        content: '小程序需要您的微信授权才能使用哦！'
      })
    }
  }
})