// pages/myTree/rule/rule.js
var ajax = require('../../../../utils/request.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bgPopupState: true,  // 弹出积分兑换弹窗， 为true时关闭，为false打开
    jsbzState: true,     // 弹出积分不足弹窗， 为true时关闭，为false打开
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  inviteClick:function(){
    wx.navigateTo({
      url: '../invite/invite',
    })
  },
  fhbClick:function(){
    wx.reLaunch({
      url: '../../../index/index?fhbInvite=1',
    })
  },

  // 打开弹窗积分弹窗
  integral:function(){
    this.setData({
      bgPopupState: false
    })
  },
  // 关闭积分弹窗
  jfCancel:function(){
    this.setData({
      bgPopupState: true
    })
  },
  // 确认积分兑换
  jfConfirm:function(){

    // this.setData({
    //   bgPopupState: true,
    //   jsbzState: false
    // })

    var that = this;
    var wxInfo = wx.getStorageSync('wxInfo')
    ajax.GET({
      ajaxPoint: 'zforder/exchangeTree',
      params: {
        loginid: wxInfo.aid,
        aid: wxInfo.aid
      },
      success: function (res) {
        // console.log(res.data);
        if (res.data.code == '0') {
          that.setData({
            bgPopupState: true,
            jsbzState: false
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none',
            duration: 2000
          })
        }

      }
    })




  },

  // 关闭积分不足弹窗
  jfbzCancel: function () {
    
    const wxInfo = wx.getStorageSync('wxInfo');
    var that = this;
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zfaccount/editWindowStatus',
      params: {
        loginid: wxInfo.aid
      },
      success: function (res) {
        // console.log('-------------关闭种树提示---------------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          wx.hideLoading();
          that.setData({
            jsbzState: true
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })
  },

  openTree:function(){
    
    const wxInfo = wx.getStorageSync('wxInfo');
    var that = this;
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zfaccount/editWindowStatus',
      params: {
        loginid: wxInfo.aid
      },
      success: function (res) {
        // console.log('-------------关闭种树提示---------------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          wx.hideLoading();
          wx.navigateBack({
            delta: 1
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })
    
  },
  windowStatus:function(){
    const wxInfo = wx.getStorageSync('wxInfo');
    var that = this;
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zfaccount/editWindowStatus',
      params: {
        loginid: wxInfo.aid
      },
      success: function (res) {
        // console.log('-------------关闭种树提示---------------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          wx.hideLoading();
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })
  },
  openVip: function(){
    wx.navigateTo({
      url: '../../../homePages/pages/openVip/openVip?vipid=1'
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})