// pages/myTree/treeRanking/treeRanking.js
var ajax = require('../../../../utils/request.js');
var config = require('../../../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    treeRankList: [],
    pager: 1,
    canbeLoadMore: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.load();
  },


  load:function(){
    var that = this;

    const wxInfo = wx.getStorageSync('wxInfo');
    setTimeout(function () {
      wx.hideLoading();
    }, 500)
    // 获取种树排行榜
    ajax.GET({
      ajaxPoint: 'zftree/getTreeRankList',
      params: {
        loginid: wxInfo.aid,
        pager: '1',
        pagesize: '10',
        sortid: 'ctime',
        sorttype: 'desc'
      },
      success: function (res) {
        // console.log('----------种树排行榜---------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          setTimeout(function(){
            wx.hideLoading();
          }, 500)

          // 将可偷果实好友列表存储到data中
          var infolist = res.data.data.infolist;

          

          // 解析用户名称（主要是解析微信名称，如果是手机号返回的还是手机号）
          for (var i = 0; i < infolist.length; i++) {
            infolist[i].nickname = decodeURIComponent(infolist[i].nickname);
          }

          // that.setInfoList(infolist); // 将获取的数据临时存储

          that.setData({
            treeRankList: infolist,

          })
          // 如果列表长度小于10将不执行下拉加载的操作
          if (infolist.length < 10) {

            that.setData({
              canbeLoadMore: false
            })
          } else {

            that.setData({
              canbeLoadMore: true
            })
          }



        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
  },



  setInfoList: function (data) {//存储获取的数据
    var newInfo = [];
    for (var i = 0; i < data.length; i++) {
      newInfo[i] = data[i]
    }
    // console.log('// 将获取的数据临时存储')
    // console.log(newInfo);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

    var that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zftree/getTreeRankList',
      params: {
        loginid: wxInfo.aid,
        pager: '1',
        pagesize: '10',
        sortid: 'ctime',
        sorttype: 'desc'
      },
      success: function (res) {
        // console.log('----------种树排行榜---------')
        // console.log(res.data.data);
        if (res.data.code == '0') {

          setTimeout(function(){
            wx.hideLoading();
          }, 500)

          var infolist = res.data.data.infolist;
          // that.setInfoList(infolist);//将获取的数据存放到此方法的数组中
          if (res.data.data.infolist.length < 10) {// 如果列表长度小于10将不执行下拉加载的操作
            that.setData({
              canbeLoadMore: false,
              treeRankList: infolist,
              pager: 1
            })
          } else {
            that.setData({
              canbeLoadMore: true,
              treeRankList: infolist,
              pager: 1
            })
          }


        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    if (this.data.canbeLoadMore) {
      var pager = this.data.pager;
      pager++;
      this.setData({
        pager: pager
      })
      const wxInfo = wx.getStorageSync('wxInfo');
      wx.showLoading({
        title: '处理中...',
      })
      ajax.GET({
        ajaxPoint: 'zftree/getTreeRankList',
        params: {
          loginid: wxInfo.aid,
          pager: pager,
          pagesize: '10',
          sortid: 'ctime',
          sorttype: 'desc'
        },
        success: function (res) {
          // console.log('----------种树排行榜---------')
          // console.log(res.data.data);
          if (res.data.code == '0') {
            setTimeout(function () {
              wx.hideLoading();
            }, 500)

            // console.log(res.data.infolist);
            var infolist = res.data.data.infolist;
            var newInfo = [];//存放刷新的数据
            for (var i = 0; i < infolist.length; i++) {
              newInfo[i] = infolist[i]
            }
            var dataList = that.data.treeRankList;
            for (var i = 0; i < newInfo.length; i++) {
              dataList.push(newInfo[i]);//把刷新的数据 push 到原来存放数据的数组中
            }
            // console.log(dataList);
            if (infolist.length == 0) {
              that.setData({
                treeRankList: dataList,
                canbeLoadMore: false
              })
              wx.showToast({
                title: '没有更多数据了',
              })
            } else {
              that.setData({
                treeRankList: dataList,
                canbeLoadMore: true
              })
              // console.log(that.data.infolist)
            }

          } else {
            wx.hideLoading();
            wx.showToast({
              title: res.data.message,
              icon: 'none'
            })
          }

        }
      })
    } else {
      wx.showToast({
        title: '没有更多数据了',
      })
    }
  }
})