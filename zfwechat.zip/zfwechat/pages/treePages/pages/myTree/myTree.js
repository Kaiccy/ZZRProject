// pages/myTree/myTree.js
var ajax = require('../../../../utils/request.js');
var config = require('../../../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wxInfo: [],               // 个人信息
    treeInfo: [],             // 树信息
    inviteNum: '0%',          // 邀请好友能量条的长度
    fruitFriendsList: [],     // 可偷果实好友列表
    fruitStolenList: [],      // 果实被偷记录
    animationWater: '',       // 浇水动画
    imgSrc: true,             // 浇水的图片显示判断
    imgSrc2: true,            // 肥料的图片显示判断
    animationFertilizer: '',  // 肥料动画
    zqTime: '00:00',          // 显示倒计时
    zqTimeState: true,        // 摘取果实的手势背景图
    timer: null,              // 倒计时的方法
    stolenListPager: 1,       // 获取最新动态的pager分页位置
    canbeLoadMore: true,      // 判断是否加载数据
    jsbzState: true,          // 开启种树弹窗提示， 为true时关闭，为false打开


    marqueePace: 1,//滚动速度
    marqueeDistance2:'',//初始滚动距离
    orientation: 'left',//滚动方向
    interval: 20, // 时间间隔
    boxRight: '',
    scrollList: [],
    pmdInterval: '',   // 跑马灯的方法
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  // 跑马灯
  pmd: function () {

    var vm = this;
    wx.createSelectorQuery().select('.title-con').boundingClientRect(function (rect) {
      // console.log(rect)

      var length = rect.width;//文字长度


      wx.createSelectorQuery().select('.t13-con').boundingClientRect(function (rect) {
        // console.log(rect)
        var boxRight = rect.right;// 盒子距离屏幕右侧宽度
        vm.setData({
          length: length,
          boxRight: boxRight,
          marqueeDistance2: -boxRight,  // 将移动的初始位置设为盒子距离屏幕右侧宽度
        });

        vm.run3();
      }).exec()





    }).exec();
  },
  // 跑马灯
  run3: function () {
    var vm = this;
    var interval = setInterval(function () {
      //marqueeDistance2 滚动的距离，因为是想要左滚动，所以是负值从0开始，如果滚动的距离小于总宽度，就递减（-1，-2...-100..）
      if (-vm.data.marqueeDistance2 < vm.data.length) {
        vm.setData({
          marqueeDistance2: vm.data.marqueeDistance2 - vm.data.marqueePace
        });
      } else {
        // 当所有数据都滑过的时候，重新循环件初始位置设为盒子距离右侧的宽度
        vm.setData({
          marqueeDistance2: vm.data.boxRight
        });
        clearInterval(interval);
        vm.run3();
      }
    }, vm.data.interval);
    vm.setData({
      pmdInterval: interval
    })
  },


  // 倒计时
  countDown: function (time) {
    var that = this;
    // var date = new Date(time);// 获取的时间
    // var myDate = new Date();//获取系统当前时间
    // console.log(date.getTime() - myDate.getTime())
    // 用获取的 时间戳减去当前时间戳得到毫秒数 除以1000得到秒数
    var millisecond = parseFloat(time/ 1000)


    var timer = setInterval(() => {  // 倒计时方法
      // 每次秒数减一
      millisecond--;
      if (millisecond < 0) {

        that.setData({
          zqTimeState: false
        })
        // that.getTreeInfo();
        clearInterval(timer); // 计时结束， 清除定时器
        // console.log('计时结束');
      } else {
        that.formatSeconds(millisecond); //调用拼接倒计时方法
      }
    }, 1000);
    that.setData({
      timer: timer
    })

  },

  // 拼接倒计时方法
  formatSeconds: function (value){
    var that = this;
    // 将秒数转化为00:00的形式
    let second = value;

    let minute = 0;// 分钟
    // let theTime2 = 0;// 小时
    if (second > 60) {

      // 取到整数分
      minute = parseInt(second / 60);
      // 除整取余取到秒数
      second = parseInt(second % 60);

      // 这里是设置时，暂时用不到
      // if (minute > 60) {
      //   // theTime2 = parseInt(minute / 60);
      //   minute = parseInt(minute % 60);
      // }
    }
    let result = parseInt(second);
    if (result < 10) {
      result = '0' + result
    }
    if (minute > 0) {
      if (minute < 10) {
        result = '0' + parseInt(minute) + ":" + result;
      } else {
        result = parseInt(minute) + ":" + result;
      }
    } else {
      result = "00:" + result;
    }
    // 这里是设置时，暂时用不到
    // if (theTime2 > 0) {
    //   result = "" + parseInt(theTime2) + "小时" + result;
    // }
    // console.log(result)
    that.setData({
      zqTime: result
    })
    // return result;
  },

  // 获取树信息
  getTreeInfo:function(){
    var that = this;

    const wxInfo = wx.getStorageSync('wxInfo');
    wx.showLoading({
      title: '处理中...',
    })
    // 获取树信息
    ajax.GET({
      ajaxPoint: 'zftree/getTreeInfo',
      params: {
        aid: wxInfo.aid,
        loginid: wxInfo.aid
      },
      success: function (res) {
        // console.log('----------树信息---------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          setTimeout(function(){
            wx.hideLoading();
          },500)
          // 将获取到的树信息存储到缓存中

          // 定义邀请好友能量条的长度
          var invite_num = res.data.data.invite_num / 20
          if (invite_num <= 1) {
            invite_num = invite_num * 100 + '%'
          } else {
            invite_num = 100 + '%'
          }

          // 判断是否用微信头像
          // var str = res.data.data.avatar
          // if (str.indexOf("https") == -1) {
          //   //等于-1时说明没有https
          //   res.data.data.avatar = config.imgUrl + 'avatar/' + res.data.data.avatar
          // }

          if (res.data.data.window_status.code == '2') {
            that.setData({
              jsbzState: false
            })
          }

          that.setData({
            treeInfo: res.data.data,
            inviteNum: invite_num
          })

          //当果实可以摘取时 开始倒计时
          if (res.data.data.fruit_status.code == '1'){
            that.countDown(res.data.data.remaining_milliseconds);
          }

        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
  },
  // 可偷果实好友列表
  getFruitFriendsList:function(){
    // 可偷果实好友列表

    const that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    ajax.GET({
      ajaxPoint: 'zftree/getFruitFriendsList',
      params: {
        loginid: wxInfo.aid,
        pager: '1',
        pagesize: '8'
      },
      success: function (res) {
        // console.log('----------可偷果实好友列表---------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          // 将可偷果实好友列表存储到data中
          var infolist = res.data.data.infolist;

          // 解析用户名称（主要是解析微信名称，如果是手机号返回的还是手机号）
          for (var i = 0; i < infolist.length; i++){
            infolist[i].nickname = decodeURIComponent(infolist[i].nickname);

            // 判断是否用微信头像
            // var str = infolist[i].avatar
            // if (str.indexOf("https") == -1){
            //   //等于-1时说明没有https
            //   infolist[i].avatar = config.imgUrl + 'avatar/' + infolist[i].avatar
            // }
            
          }
          that.setData({
            fruitFriendsList: infolist
          })

        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
  },
  // 果实被偷记录
  getFruitStolenList: function () {

    const that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    
    ajax.GET({
      ajaxPoint: 'zftree/getFruitStolenList',
      params: {
        loginid: wxInfo.aid,
        pager: '1',
        pagesize: '10'
      },
      success: function (res) {
        // console.log('----------果实被偷记录---------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          // 将可偷果实好友列表存储到data中
          var infolist = res.data.data.infolist;

          // 解析用户名称（主要是解析微信名称，如果是手机号返回的还是手机号）
          for (var i = 0; i < infolist.length; i++) {
            infolist[i].nickname = decodeURIComponent(infolist[i].nickname);
            infolist[i].time = infolist[i].time.substr(0, 10)
            // 判断是否用微信头像 (暂时不用了)
            // var str = infolist[i].avatar
            // if (str.indexOf("https") == -1) {
            //   //等于-1时说明没有https
            //   infolist[i].avatar = config.imgUrl + 'avatar/' + infolist[i].avatar
            // }
          }
          that.setData({
            fruitStolenList: infolist,
            stolenListPager: 1
          })

          // 判断数据是否需要分页
          if (infolist.length < 10) {

            that.setData({
              canbeLoadMore: false
            })
          } else {

            that.setData({
              canbeLoadMore: true
            })
          }

        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
  },
  // 点击加载更多
  moreStolenList: function () {
    let that = this;

    if (this.data.canbeLoadMore) {
      const wxInfo = wx.getStorageSync('wxInfo');
      let pager = this.data.stolenListPager;
      pager++;

      this.setData({
        stolenListPager: pager
      })

      wx.showLoading({
        title: '加载中...'
      });

      ajax.GET({
        ajaxPoint: 'zftree/getFruitStolenList',
        params: {
          loginid: wxInfo.aid,
          pager: pager,
          pagesize: '10'
        },
        success: function (res) {
          // console.log(res.data.infolist);
          if (res.data.code == 0) {


            setTimeout(function () {
              wx.hideLoading();
            }, 500);

            let list = res.data.data.infolist;

            // 解析用户名称（主要是解析微信名称，如果是手机号返回的还是手机号）
            for (var i = 0; i < list.length; i++) {
              list[i].nickname = decodeURIComponent(list[i].nickname);

            }

            

            let newInfo = [];//存放刷新的数据
            for (let i = 0; i < list.length; i++) {
              newInfo[i] = list[i]
            }
            let dataList = that.data.fruitStolenList;
            for (let i = 0; i < newInfo.length; i++) {
              dataList.push(newInfo[i]);//把刷新的数据 push 到原来存放数据的数组中
            }

            // console.log(dataList);

            that.setData({
              fruitStolenList: dataList
            })

            // 如果数据为空，则提示没有更多数据，并且
            if (list.length === 0) {
              that.setData({
                canbeLoadMore: false
              })
              wx.showToast({
                title: '没有更多数据了',
                icon: 'none',
                duration: 500
              })
            } else {
              that.setData({
                canbeLoadMore: true
              })
            }
          } else {
            wx.hideLoading();
            wx.showToast({
              title: res.data.meg,
              icon: 'none'
            })
          }

        },
        fail: function (res) {
          // console.log(res)
          wx.hideLoading();
          wx.showToast({
            title: '获取数据失败',
            icon: 'none',
            duration: 500
          })
        }
      })
    } else {
      wx.showToast({
        title: '没有更多数据了',
        icon: 'none',
        duration: 500
      })
    }
  },
  // 跑马灯数据
  getScrollList: function () {
    let that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    ajax.GET({
      ajaxPoint: 'zftree/getScrollList',
      params: {
        loginid: wxInfo.loginid
      },
      success: function (res) {
        // console.log(res.data.data.infolist);
        if (res.data.code == '0') {
          let scrollList =[];
          for(var i=0;i<20;i++){
            scrollList.push(res.data.data.infolist[i])
          }
          that.setData({
            scrollList: scrollList
          },function(){
            that.pmd(); // 跑马灯
          })

        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }

      },
      fail: function (res) {
        // console.log(res)
        wx.hideLoading();
        wx.showToast({
          title: '获取数据失败',
          icon: 'none',
          duration: 500
        })
      }
    })
  },

  // 点击浇水
  watering:function(){
    var that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    ajax.GET({
      ajaxPoint: 'zftree/addWatering',
      params: {
        loginid: wxInfo.aid,
        tree_id: that.data.treeInfo.tree_id,
        watering_type: '1'
      },
      success: function (res) {
        // console.log('-------------浇水---------------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          // 当请求成功时执行动画
          new animate();
          // 当请求成功时执行重新渲染树数据
          // that.getTreeInfo();
          let treeInfo = that.data.treeInfo;
          let data = res.data.data;
          treeInfo.bear_time = data.bear_time;                   //结出果实时间
          treeInfo.create_time = data.create_time;               //树激活时间  
          treeInfo.fruit_create_time = data.fruit_create_time;   //果实生成时间
          treeInfo.fruit_level = data.fruit_level;               //果实等级
          treeInfo.fruit_status = data.fruit_status;             //状态 1可收取 2不可收取 3已收取
          treeInfo.max_power = data.max_power;                   //结果所需能量
          treeInfo.pick_start_time = data.pick_start_time;       //自己可收取开始时间
          treeInfo.power = data.power;                           //当前能量值
          treeInfo.tree_level = data.tree_level;                 //树等级
          treeInfo.tree_status = data.tree_status;               //状态 1未激活 2已激活

          treeInfo.remaining_milliseconds = data.remaining_milliseconds; //距离自己可收取开始时间 单位：毫秒
          treeInfo.tree_id = data.tree_id;                    // 树id
          treeInfo.aid = data.aid;                    // 树所有者用户编号
          treeInfo.watering_price = data.watering_price;  // 浇水所需积分 单位：积分/次
          treeInfo.fertilize_price = data.fertilize_price;//施肥所需积分 单位：积分/次
          treeInfo.integral = data.integral;//剩余积分

          //当果实可以摘取时 开始倒计时
          if (res.data.data.fruit_status.code == '1') {
            that.countDown(res.data.data.remaining_milliseconds);
          }

          that.setData({
            treeInfo: treeInfo
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })

    // 创建动画
    function animate(){
      var animation = wx.createAnimation({
        duration: 1000,
        timingFunction: 'ease',
        delay: 0
      })
      animation.translate(10, -130).step();//
      that.setData({
        animationWater: animation.export()
      })

      // 在800s之后换浇水图片，并放大图片
      setTimeout(function () {
        animation.scale(1.5).step();
        that.setData({
          imgSrc: false,
          animationWater: animation.export()
        })
      }, 800)

      // 在1500s时恢复位置动画
      setTimeout(function () {
        animation.translate(0, 0).scale(1).step();
        that.setData({
          imgSrc: true,
          animationWater: animation.export()
        })
      }, 2500)
    }
    

  },

  // 点击肥料
  fertilizer:function(){
    var that = this;
    const wxInfo = wx.getStorageSync('wxInfo');
    ajax.GET({
      ajaxPoint: 'zftree/addWatering',
      params: {
        loginid: wxInfo.aid,
        tree_id: that.data.treeInfo.tree_id,
        watering_type: '2'
      },
      success: function (res) {
        // console.log('-------------施肥---------------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          // 当请求成功时执行动画
          new animate();
          // 当请求成功时执行重新渲染树数据
          // that.getTreeInfo();
          let treeInfo = that.data.treeInfo;
          let data = res.data.data;
          treeInfo.bear_time = data.bear_time;                   //结出果实时间
          treeInfo.create_time = data.create_time;               //树激活时间  
          treeInfo.fruit_create_time = data.fruit_create_time;   //果实生成时间
          treeInfo.fruit_level = data.fruit_level;               //果实等级
          treeInfo.fruit_status = data.fruit_status;             //状态 1可收取 2不可收取 3已收取
          treeInfo.max_power = data.max_power;                   //结果所需能量
          treeInfo.pick_start_time = data.pick_start_time;       //自己可收取开始时间
          treeInfo.power = data.power;                           //当前能量值
          treeInfo.tree_level = data.tree_level;                 //树等级
          treeInfo.tree_status = data.tree_status;               //状态 1未激活 2已激活

          treeInfo.remaining_milliseconds = data.remaining_milliseconds; //距离自己可收取开始时间 单位：毫秒
          treeInfo.tree_id = data.tree_id;                    // 树id
          treeInfo.aid = data.aid;                    // 树所有者用户编号
          treeInfo.watering_price = data.watering_price;  // 浇水所需积分 单位：积分/次
          treeInfo.fertilize_price = data.fertilize_price;//施肥所需积分 单位：积分/次
          treeInfo.integral = data.integral;//剩余积分

          //当果实可以摘取时 开始倒计时
          if (res.data.data.fruit_status.code == '1') {
            that.countDown(res.data.data.remaining_milliseconds);
          }

          that.setData({
            treeInfo: treeInfo
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      }
    })
    function animate(){
      var animation = wx.createAnimation({
        duration: 1000,
        timingFunction: 'ease',
        delay: 0,
      })
      animation.translate(-85, -150).scale(1.3).step();//
      that.setData({
        animationFertilizer: animation.export()
      })

      // 在800s之后换施肥图片，并放大图片
      setTimeout(function () {
        animation.scale(2).step();
        that.setData({
          imgSrc2: false,
          animationFertilizer: animation.export()
        })
      }, 800)

      setTimeout(function () {
        animation.translate(0, 0).scale(1).step();
        that.setData({
          imgSrc2: true,
          animationFertilizer: animation.export()
        })
      }, 2000)
    }
    
  },


  // 排行榜
  treeRanking:function(){
    wx.navigateTo({
      url: '../treeRanking/treeRanking',
    })
  },

  // 规则
  rule:function(){
    wx.navigateTo({
      url: '../ruleH5/ruleH5',
    })
  },

  // 别人的树
  otherTree:function(e){
    // console.log(e.currentTarget.dataset.id)

    wx.navigateTo({
      url: '../others/others?id=' + e.currentTarget.dataset.aid,
    })
  },

  // 邀请
  invite:function(){
    wx.navigateTo({
      url: '../invite/invite',
    })
  },

  // 摘果实
  pickingFruit:function(e){
    // console.log(e.currentTarget.dataset.fruitid)
    var that = this;
    var fruit_id = e.currentTarget.dataset.fruitid;
    const wxInfo = wx.getStorageSync('wxInfo');
    // wx.showLoading({
    //   title: '处理中...',
    // })
    ajax.GET({
      ajaxPoint: 'zftree/pickFruit',
      params: {
        loginid: wxInfo.aid,
        fruit_id: fruit_id
      },
      success: function (res) {
        // console.log('-------------摘果实---------------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          // wx.hideLoading();
          // that.getTreeInfo(); // 重新加载

          // 摘取果实之后重新渲染页面
          let treeInfo = that.data.treeInfo;
          let data = res.data.data;
          

          treeInfo.fruit_times = data.fruit_times;       // 当天剩余偷果实次数
          treeInfo.max_power = data.max_power;           // 树结果所需能量
          treeInfo.remaining_milliseconds = data.remaining_milliseconds; // 距离自己可收取开始时间 单位：毫秒
          treeInfo.pick_start_time = data.pick_start_time; // 树所有者可收取开始时间     
          treeInfo.create_time = data.create_time;        //树激活时间
          treeInfo.tree_id = data.tree_id;                //树id
          treeInfo.fruit_create_time = data.fruit_create_time;  //果实生成时间
          treeInfo.bear_time = data.bear_time;            // 结果时间
          treeInfo.tree_level = data.tree_level;          // 树等级
          treeInfo.tree_status = data.tree_status;        // 树状态
          treeInfo.fruit_status = data.fruit_status;      // 果实状态
          treeInfo.power = data.power;                    // 树当前能量
          treeInfo.aid = data.aid;                        // 树所有者用户编号
          treeInfo.fruit_level = data.fruit_level;        // 果实等级
          treeInfo.watering_price = data.watering_price;  // 浇水所需积分 单位：积分/次
          treeInfo.fertilize_price = data.fertilize_price;//施肥所需积分 单位：积分/次

          // 将新数据更新进缓存中
          that.setData({
            treeInfo: treeInfo
          })



          wx.showToast({
            title: '摘取了' + data.amount + '元',
            icon: 'none',
            duration: 2000
          })
        } else {
          // wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })
  },

  // 商店
  shopClick: function(){
    wx.navigateTo({
      url: '../../../homePages/pages/shop/shop',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  // 关闭开启种树提示的弹窗
  openTree: function () {
    
    var treeInfo = this.data.treeInfo;
    var that = this;
    wx.showLoading({
      title: '处理中...',
    })
    ajax.GET({
      ajaxPoint: 'zfaccount/editWindowStatus',
      params: {
        loginid: treeInfo.aid
      },
      success: function (res) {
        // console.log('-------------关闭种树提示---------------')
        // console.log(res.data.data);
        if (res.data.code == '0') {
          wx.hideLoading();
          that.setData({
            jsbzState: true
          })
          that.getTreeInfo();// 获取树信息
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const wxInfo = wx.getStorageSync('wxInfo');
    this.setData({
      wxInfo: wxInfo
    })
    // if (wxInfo.window_status.code == '2'){
    //   this.setData({
    //     jsbzState: false
    //   })
    // }

    this.getTreeInfo();// 获取树信息
    this.getFruitFriendsList();// 获取可偷好友列表
    this.getFruitStolenList();// 果实被偷记录
    this.getScrollList(); // 跑马灯数据
    
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    // 当跳转页面时清除倒计时
    clearInterval(this.data.timer);
    clearInterval(this.data.pmdInterval);
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    // 当关闭页面时清除倒计时
    clearInterval(this.data.timer);
    clearInterval(this.data.pmdInterval);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  onShareAppMessage: function(ops){
    const wxInfo = wx.getStorageSync('wxInfo');
    if(ops.from === 'button'){
      // 来自页面内转发按钮
      // console.log(ops.target)
      return {
        title: '您的好友邀请您前来浇水！',
        path: '/pages/index/index?inviterphone=' + wxInfo.regphone + '&id=' + wxInfo.aid,
        success: function (res) {
          // 转发成功
        },
        fail: function (res) {
          // 转发失败
        }
      }
    }else{
      return {
        title: '您的好友邀请您前来浇水！',
        path: '/pages/index/index?inviterphone=' + wxInfo.regphone + '&id=' + wxInfo.aid,
        success: function (res) {
          // 转发成功
        },
        fail: function (res) {
          // 转发失败
        }
      }
    }
  }
})