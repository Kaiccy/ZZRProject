// pages/myTree/invite/invite.js
var ajax = require('../../../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  viewImage : function(e) {
    console.log(e)
    var that = this;
    var src= e.target.dataset.src;
    // wx.previewImage({
    //   url: [src],
    // });
    var isFirst = wx.getStorageSync('isFirst') || 0;
    wx.getSetting({
      success(res) {
        console.log(res)

        if (!res.authSetting['scope.writePhotosAlbum']) {
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success() {
              // 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
              // wx.startRecord()
              console.log('success')

              wx.saveImageToPhotosAlbum({
                filePath: src,
                success(res) {
                  // console.log(res)
                  wx.showToast({
                    title: '保存成功！',
                  })
                },
                fail(res){
                  console.log(res)
                }
              })
            },
            fail(){
              if(isFirst === 0){
                wx.setStorageSync('isFirst', 1);
              }else{
                console.log(123)
                wx.getSetting({
                  success: (res) => {
                    if (!res.authSetting['scope.writePhotosAlbum'])
                      that.openConfirm()
                  }
                })
              }
            }
          })
        }

        
      },
      fail(res){
        console.log(res)
      }
    })
    
  },
  openConfirm: function () {
    wx.showModal({
      content: '检测到您没打开保存图片的功能，是否去设置打开？',
      confirmText: "确认",
      cancelText: "取消",
      success: function (res) {
        console.log(res);
        //点击“确认”时打开设置页面
        if (res.confirm) {
          // console.log('用户点击确认')
          wx.openSetting({
            success: (res) => { }
          })
        } else {
          console.log('用户点击取消')
        }
      }
    });
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    const wxInfo = wx.getStorageSync('wxInfo');
    // console.log(wxInfo.aid)
    return {
      title: '众粉小程序',
      path: 'pages/index/index?inviterphone=' + wxInfo.regphone,
      // imageUrl: '../../../static/images/33@2x.png'
      success: function (res) {
        // 转发成功
        console.log("转发成功:");
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:");
      }
    }
  }
})