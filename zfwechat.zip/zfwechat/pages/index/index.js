//index.js
//获取应用实例
const app = getApp()
const ajax = require('../../utils/request.js')

Page({
  data: {
    longitude: '120.15515',
    latitude: '30.27415',
    base_scale: 10,
    userInfo: [], //用户信息
    markers: [], //地图标记
    animation: '',
    animation1: '',
    circle: [],
    show: false, //打开红包弹窗
    fbHb: false, //发送红包弹窗
    noTimes: false, //发送红包弹窗
    resize: {
      width: '375px',
      height: '375px',
      top: '-50%',
      left: '-10%'
    },
    redPoint: [], //红包列表
    selectRp: [], //当前选择红包信息
    rangeList: [] ,//排行榜
    getUserModal:false ,//授权窗口
    timer:'timeReload',
    countDownNum:300
  },
  regionchange(e) {
    //console.log(e)
  },
  setScale:function(){
    let that = this;
    wx.getSystemInfo({
      success(res) {
        console.log(res)
        if (res.system.indexOf('iOS')>-1){
          that.setData({
            base_scale: 11.8,
          })
        }else{
          that.setData({
            base_scale: 10.5,
          })
        }
      }
    })
  },
  hbGb(e) {
    wx.navigateTo({
      url: '/pages/addEnvelope/normalEnve/index',
    })
  },
  hbSp(e) {
    wx.navigateTo({
      url: '/pages/addEnvelope/tbEnve/index',
    })
  },
  hbYy(e) {
    wx.navigateTo({
      url: '/pages/addEnvelope/appsEnve/index',
    })
  },
  openRB(e) {
    wx.showLoading({
      title: '打开红包',
    })
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo) {
      if (userInfo.envelope_times + userInfo.envelope_times_add !== 0) {
        ajax.GET({
          ajaxPoint: 'zfenvelope/grabEnvelope',
          params: {
            loginid: userInfo.loginid,
            envelope_id: that.data.selectRp.envelope_id
          },
          success: function(res) {
            wx.hideLoading();
            if (res.data.code == 0) {
              userInfo.envelope_times = res.data.data.envelope_times;
              userInfo.envelope_times_add = res.data.data.envelope_times_add;
              wx.redirectTo({
                url: '/pages/envelopeDetail/index?time=5000&envelopeId=' + that.data.selectRp.envelope_id,
              })
            } else if (res.data.code == 9999) {
              wx.showModal({
                title: '提示',
                content: res.data.message,
              });
              that.setData({
                show: false,
                selectRp: []
              })
            } else {
              wx.redirectTo({
                url: '/pages/envelopeDetail/index?time=5000&envelopeId=' + that.data.selectRp.envelope_id,
              })
            }
          }
        })
      } else {
        wx.hideLoading();
        that.setData({
          show: false,
          selectRp: [],
          noTimes:true
        })
        //红包次数不足,邀请弹窗出现
      }
    }
  },
  addBag(e) {
    // let that = this;
    // that.setData({
    //   fbHb: true
    // })
    wx.navigateTo({
      url: '/pages/addEnvelope/normalEnve/index',
    })
  },
  closeAddHb(e) {
    let that = this;
    that.setData({
      fbHb: false
    })
  },
  regionchange(e) {

  },
  makertap(e) {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo) {
      if (userInfo.envelope_times + userInfo.envelope_times_add !== 0) {
        wx.showLoading({
          title: '打开红包',
        })
        let envelopeId = e.markerId;
        for (let i = 0; i < that.data.redPoint.length; i++) {
          if (envelopeId == that.data.redPoint[i].envelope_id) {
            wx.hideLoading();
            let data = that.data.redPoint[i];
            // data.nickname = decodeURI(data.nickname)
            if (data.is_grab==0){
              that.setData({
                selectRp: data,
                show: true
              });
            }else{
              wx.navigateTo({
                url: '/pages/envelopeDetail/index?envelopeId=' + envelopeId,
              })
            }
          }
        }
      }else{
        that.setData({
          noTimes:true
        })
      }
    }  
    
   
  },
  reLoad: function() {
    this.onShow()
  },
  controltap(e) {
    //console.log(e.controlId)
  },
  closeRedPoint(e) {
    //console.log(e);
    let that = this;
    that.setData({
      animation: '',
      animation1: '',
      show: false
    })
  },
  reloadObject: function() {
    let that = this;
  },
  onShow() {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    // that.getLocation();
    if (wx.getStorageSync('wxInfo') && userInfo.openid_xcx!=='') {
      let userInfo = wx.getStorageSync('wxInfo');
      if (userInfo.aid == '') {　 // 已授权未登录
        wx.hideLoading();
        wx.redirectTo({
          url: '../login/login'　
        })
      }else{
        that.getLocation();
        that.setData({
          show: false, //打开红包
          fbHb: false, //发送红包
          noTimes: false,
          timer: 'timeReload',
          countDownNum: 300
        });
        that.login();
        that.getRangeList();
      }
    }else{
      that.setData({
        getUserModal:true
      })
    }
    var countDownNum = that.data.countDownNum;
    that.setData({
      timer: setInterval(function () {
        countDownNum--;
        that.setData({
          countDownNum: countDownNum
        });
        if (countDownNum == 0) {
          that.onShow()
        }
      }, 1000)
    })
  },
  onHide:function(){
    let that = this;
    clearInterval(that.data.timer);
  },
  onLoad: function(options) {
    let that = this;
    // 如果是经过邀请进来的，在这里存储邀请人手机号然后去注册(执行的是邀请种树的操作)
    // 或者是判断是不是被邀请来浇水的，因为邀请注册和邀请浇水都有inviterphone参数
    if (options.inviterphone) {
      if (wx.getStorageSync('wxInfo')) {
        // 这个id是被邀请来浇水的人的aid
        if (options.id) {
          wx.navigateTo({
            url: '../treePages/pages/others/others?id=' + options.id,
          })
        }
        if (options.envelopeId){
          //如果有红包ID标识，直接抢红包
          console.log('直接抢红包')
          that.openRBAndGet(options.envelopeId)
        }
        if (wx.getStorageSync('envelopeId')){
          let envelopeId = wx.getStorageSync('envelopeId');
          console.log('登陆后直接抢红包')
          that.openRBAndGet(envelopeId)
        }
        // 分享取参在这里进行操作
      }else{

        // 如果没登录则存储邀请人手机号
        wx.setStorage({
          key: 'inviterphone',
          data: options.inviterphone
        })
        if(options.envelopeId){
          wx.setStorage({
            key: 'envelopeId',
            data: options.envelopeId
          })
        }
      }
    };
  },
  getLocation: function() {
    let that = this;
    wx.showLoading({
      title: '正在加载',
    })
    wx.getLocation({
      type: 'wgs84',
      success(res) {
        //console.log(res);
        let latitude = res.latitude
        let longitude = res.longitude
        let speed = res.speed
        let accuracy = res.accuracy;
        that.setData({
          latitude: latitude,
          longitude: longitude,
          circles: [{
            latitude: latitude,
            longitude: longitude,
            color: '#7cb5ec44',
            fillColor: '#7cb5ec44',
            radius: 15000,
            strokeWidth: 1
          }]
        });
        wx.hideLoading();
        that.getEnvelop()
      }
    })
  },
  getRangeList: function() {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo')
    ajax.GET({
      ajaxPoint: 'zfenvelope/getEnvelopeSendRankList',
      params: {
        type: 1,
        loginid: userInfo.loginid,
        pagesize: 3
      },
      success: function(res) {
        if (res.data.code == 0) {
          for (let i = 0; i < res.data.data.infolist.length; i++) {
            res.data.data.infolist[i].nickname = decodeURI(res.data.data.infolist[i].nickname)
          }
          that.setData({
            rangeList: res.data.data.infolist
          })
        }
      }
    })
  },
  getEnvelop: function() {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo')
    if(userInfo&&userInfo.aid){
      let params = {
        longitude: that.data.longitude,
        latitude: that.data.latitude,
        loginid: userInfo.loginid,
        token: userInfo.token
      };
      ajax.GET({
        ajaxPoint: 'zfenvelope/getEnvelopeListForWX',
        params: params,
        success: function (res) {
          //console.log(res)
          if (res.data.code == 0) {
            let markers = [];
            let list = res.data.data.infolist;
            for (let i = 0; i < list.length; i++) {
              if (list[i].send_time_level_type == '2' && (list[i].is_grab == '1' || list[i].balance==0)){
                markers[i] = {
                  id: list[i].envelope_id,
                  latitude: list[i].latitude,
                  longitude: list[i].longitude,
                  //title: list[i].title,
                  iconPath: list[i].avatar,
                  width: '54rpx',
                  height: '54rpx',
                }
              } else {
                markers[i] = {
                  id: list[i].envelope_id,
                  latitude: list[i].latitude,
                  longitude: list[i].longitude,
                  //title: list[i].title,
                  iconPath: '/static/images/redpoint.png',
                  width: '54rpx',
                  height: '64rpx',
                }
              }
              //console.log(markers)
            }
            that.setData({
              markers: markers,
              redPoint: res.data.data.infolist
            })
          } else {
            wx.showModal({
              title: '提示',
              content: '获取红包池失败,点击确定重新加载',
              success: function (red) {
                if (res.confirm) {
                  that.getEnvelop();
                }
              }
            })
          }
        }
      })
    }
  },
  // 进入页面判断是否已经授权
  login: function() {
    let that = this;
    let userInfo = wx.getStorageSync('wxInfo');
    let loginid = wx.getStorageSync('loginid');
    let token = wx.getStorageSync('token');

    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    ajax.GET({
      ajaxPoint: 'zfaccount/getAccountInfo',
      params: {
        aid: userInfo.aid,
        loginid: userInfo.loginid
      },
      success: function (res) {
        //console.log(res.data.data);
        if (res.data.code == '0') {
          // 将获取到的个人信息存储到缓存中
          let data = res.data.data;
          data.token = token;
          data.loginid = loginid;
          //console.log(data);
          wx.setStorage({
            key: 'wxInfo',
            data: data,
            success: function () {
              wx.hideLoading();
              that.setData({
                userInfo: data
              })
            },
            fail: function (res) {
              wx.hideLoading();
              wx.showToast({
                title: '缓存出错！',
                icon: 'none'
              })
            }
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }

      },
      fail: function (res) {
        wx.hideLoading();
        wx.showToast({
          title: '网络错误！',
          icon: 'none'
        })
      }
    })
    
  },
  viewTree: function() {
    wx.navigateTo({
      url: '../treePages/pages/myTree/myTree',
    })
  },
  viewRange: function() {
    wx.navigateTo({
      url: '/pages/list/pages/rangeList/index',
    })
  },
  goInvite:function(e){
    let that = this;
    that.setData({
      noTimes: false
    });
    wx.navigateTo({
      url: '/pages/share/index',
    })
  },
  closeinviteContent:function(){
    let that = this;
    that.setData({
      noTimes:false
    })
  },
  openRBAndGet:function(envelopeId){
    let that = this;
    wx.showLoading({
      title: '打开红包',
    })
    let userInfo = wx.getStorageSync('wxInfo');
    if (userInfo) {
      if (userInfo.envelope_times + userInfo.envelope_times_add !== 0) {
        ajax.GET({
          ajaxPoint: 'zfenvelope/grabEnvelope',
          params: {
            loginid: userInfo.loginid,
            envelope_id: envelopeId
          },
          success: function (res) {
            wx.hideLoading();
            if (res.data.code == 0) {
              userInfo.envelope_times = res.data.data.envelope_times;
              userInfo.envelope_times_add = res.data.data.envelope_times_add;
              wx.redirectTo({
                url: '/pages/envelopeDetail/index?time=5000&envelopeId=' + envelopeId,
              })
              wx.removeStorageSync('envelopeId');
            } else if (res.data.code == 9999) {
              wx.showModal({
                title: '提示',
                content: res.data.message,
              });
              that.setData({
                show: false,
                selectRp: []
              })
            } else {
              wx.removeStorageSync('envelopeId');
              wx.redirectTo({
                url: '/pages/envelopeDetail/index?time=5000&envelopeId=' + envelopeId,
              })
            }
          }
        })
      } else {
        wx.hideLoading();
        that.setData({
          show: false,
          selectRp: [],
          noTimes: true
        })
        //红包次数不足,邀请弹窗出现
      }
    }
  },

  // 跳转到使用规则页面
  ruleH5:function(){
    wx.navigateTo({
      url: '../indexRuleH5/indexRuleH5'
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    let that = this;
    that.setData({
      noTimes: false
    });
    const wxInfo = wx.getStorageSync('wxInfo');
    // console.log(wxInfo.aid)
    if (res.from =='button'){
      return {
        title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
        imageUrl: "/static/images/shaBj.png",
        path: '/pages/index/index?inviterphone=' + wxInfo.regphone,
        // imageUrl: '../../../static/images/33@2x.png'
        success: function (res) {
          // 转发成功
          console.log("转发成功:");
        },
        fail: function (res) {
          // 转发失败
          console.log("转发失败:");
        }
      }
    }else{
      return {
        title: '点开就能领红包，体验试玩就能赚钱全新营销模式，商客互动助力引流',
        imageUrl: "/static/images/shaBj.png",
        path: '/pages/index/index?inviterphone=' + wxInfo.regphone,
        // imageUrl: '../../../static/images/33@2x.png'
        success: function (res) {
          // 转发成功
          console.log("转发成功:");
        },
        fail: function (res) {
          // 转发失败
          console.log("转发失败:");
        }
      }
    }
  },
  goTx:function(){
    wx.navigateTo({
      url:'/pages/widthdrawWx/index'
    })
  },
  viewPersonalPage:function(e){
    wx.navigateTo({
      url: '/pages/list/pages/rangeList/index',
    })
  },


  /* 获取用户授权 */
  getUserInfo: function (e) {
    // console.log(e)
    let that = this;
    var userInfo = e.detail.userInfo; // 点击允许按钮获取到的个人信息+
    if (userInfo) {
      //用户按了允许授权按钮
      // console.log('用户按了允许授权按钮');
      var encryptedData = e.detail.encryptedData;
      var iv = e.detail.iv;
      // console.log('encryptedData:' + encryptedData)
      // console.log('iv:' + iv)
      wx.showLoading({
        title: '加载中...',
        mask: true
      });
      wx.login({ // 登录获取code
        success: res => {
          let code = res.code;
          //console.log('code:' + code);
          let params = {
            code: code,
            encryptedData: encodeURIComponent(encryptedData),
            iv: encodeURIComponent(iv),
            nickname: userInfo.nickName,
            headimgurl: userInfo.avatarUrl
          };
          // 用code向后台换取微信信息
          ajax.POST({
            ajaxPoint: 'https://zf.cube-tech.cn/zfaccount/getWxOpenId',
            // ajaxPoint: 'http://192.168.0.181:4002/getWxOpenId',
            params: params,
            success: function (res) {
              //console.log(res.data);
              wx.hideLoading();
              that.setData({
                getUserModal:false
              })
              if (res.data.code == '0') {
                // 将获取到的个人信息存储到缓存中
                // 保存loginid
                wx.setStorage({
                  key: 'loginid',
                  data: res.data.data.loginid
                })
                // 保存token
                wx.setStorage({
                  key: 'token',
                  data: res.data.data.token
                })
                // 保存微信信息
                wx.setStorage({
                  key: 'wxInfo',
                  data: res.data.data,
                  success: function () {
                    wx.hideLoading();
                  },
                  fail: function (res) {
                    wx.hideLoading();
                  }
                })
                if (res.data.data.aid == '') {
                  wx.redirectTo({
                    url: '/pages/login/login'
                  })
                } else {
                  wx.reLaunch({
                    url: '/pages/index/index',
                  })
                }
              } else {
                wx.hideLoading();
                wx.showToast({
                  title: res.data.message,
                  icon: 'none'
                })
              }

            }
          })
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '登录出错,请检查网络',
            icon: 'none',
            mask: true
          })
        }
      })
    } else {
      //用户按了拒绝按钮
      // console.log('用户按了拒绝按钮');
      wx.showModal({
        title: '提示',
        content: '小程序需要您的微信授权才能使用哦！'
      })
    }
  },
  goMine:function(e){
    wx.switchTab({
      url: '/pages/home/home',
    })
  }
})