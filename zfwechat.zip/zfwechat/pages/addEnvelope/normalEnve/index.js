// pages/addEnvelope/normalEnve/index.js
var QQMapWX = require('../../../libs/qqmap-wx-jssdk.js');
const ajax = require('../../../utils/request.js');
const config = require('../../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    addPicList:[],//上传的图片列表
    chooseInfo: [{ name: '全市', id: 0 }, { name: '全区', id: 1 }, { name: '一公里内', id: 2 }],
    Index: 0,
    currentId: 0,// 已选红包可视范围ID
    adcode:0,// 红包位置地区编号
    adName:'点击选择',
    payNum: '',// 红包金额
    rpNum: '',// 红包个数
    word: '',// 红包文字内容
    payModal:false,
    paySuccess:false,//红包发送成功弹窗
    userInfo:'',
    latitude:0,
    longitude: 0,
    envelopeid:0,
    jsbzState:true,
    orderId:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let userInfo = wx.getStorageSync('wxInfo');
    this.setData({
      userInfo: userInfo
    })
  },
  /* */
  editWord:function(e){
    let that = this;
    that.setData({
      word: e.detail.value
    })
  },
    /*修改红包金额 */
  price:function(e){
    let that = this;
    let detail = e.detail.value.match(/^\d*(\.?\d{0,2})/g)[0];
    that.setData({
      payNum: detail
    })
  },
  checkPrice:function(e){
    let that = this;
    let detail = e.detail.value.match(/^\d*(\.?\d{0,2})/g)[0];
    if (detail < 20) {
      wx.showToast({
        icon: 'none',
        title: '红包金额至少20元',
      })
    } else {
      that.setData({
        payNum: ~~detail
      })
    }
  },
  /*修改红包个数 */
  rpNum:function(e){
    let that = this;
    that.setData({
      rpNum:e.detail.value
    })
  },
  checkrpNum:function(e){
    let that = this;
    let detail = e.detail.value;
    if(detail>=3){
      that.setData({
        rpNum: ~~e.detail.value
      })
    }else{
      wx.showToast({
        icon: 'none',
        title: '红包个数至少3个',
      })
    }
  },
  /*支付 */
  goPay:function(){
    let that = this;
    //console.log(that.data);
    if (that.data.word !== '' && that.data.rpNum >=3 && that.data.payNum>=20 && that.data.adcode!==0){
      let that = this;
      //console.log(e.detail);
      let pics = '';
      for (let i = 0; i < that.data.addPicList.length; i++) {
        if (i == 0) {
          pics = that.data.addPicList[i].name
        } else {
          pics += ',' + that.data.addPicList[i].name
        }
      }

      let params = {
        loginid: that.data.userInfo.aid,
        amount: that.data.payNum,
        number: that.data.rpNum,
        latitude: that.data.latitude,
        longitude: that.data.longitude,
        district: that.data.adcode,
        envelope_type: 1,
        title: that.data.word,
        pic: pics,
      };
      ajax.GET({
        ajaxPoint: 'zfenvelope/addEnvelope',
        params: params,
        success: function (res) {
          ///console.log(res)
          if (res.data.code == 0) {
            let orderId = res.data.data.order_id;
            // 红包发送成功后 保存 红包ID.分享用
            that.setData({
              envelopeId: res.data.data.envelope_id,
              payModal: true,
              orderId: orderId
            })
          } else {
            wx.showToast({
              icon:'none',
              title: res.data.message,
            })
          }
        }
      })
    }else{
      wx.showModal({
        showCancel:false,
        title: '提示',
        content: '请完善红包信息后再次提交',
      })
    }
  },
  /* 支付成功调用方法 */
  paySuccess:function(e){
    let that = this;
    //console.log(e.detail);
    if (e.detail.payWay == 0) {
      ajax.GET({
        ajaxPoint: 'zforder/orderPayEnvelopes',
        params: {
          order_id: that.data.orderId,
          pay_type: 1,
          thirdpay_id: 2,
          thirdpay_type: 2,
          loginid: that.data.userInfo.aid
        },
        success: function (res) {
          if (res.data.code == 0) {
            let payInfo = res.data.data;
            wx.requestPayment({
              timeStamp: payInfo.timeStamp,
              nonceStr: payInfo.nonceStr,
              package: payInfo.package,
              signType: 'MD5',
              paySign: payInfo.paySign,
              success(res) {
                if (that.data.userInfo.tree_status.code == 1) {
                  let wxInfo = wx.getStorageSync('wxInfo');
                  wxInfo.tree_status.code = 2;
                  wx.setStorageSync('wxInfo', wxInfo);
                  that.setData({
                    jsbzState: false
                  })
                } else {
                  that.setData({
                    paySuccess: true
                  })
                }
              },
              fail(res) {
                wx.showModal({
                  showCancel: false,
                  title: '发送红包失败',
                  content: '请重新发送广播红包',
                })
              }
            })
          } else {
            wx.showToast({
              icon:'none',
              title: res.data.message,
            })
          }
        }
      })
    } else {
      ajax.GET({
        ajaxPoint: 'zforder/orderPayEnvelopes',
        params: {
          order_id: that.data.orderId,
          pay_type: 2,
          loginid: that.data.userInfo.aid
        },
        success: function (resdata) {
          if (resdata.data.code == 0) {
            if (that.data.userInfo.tree_status.code == 1) {
              let wxInfo = wx.getStorageSync('wxInfo');
              wxInfo.tree_status.code = 2;
              wx.setStorageSync('wxInfo', wxInfo);
              that.setData({
                jsbzState: false
              })
            } else {
              that.setData({
                paySuccess: true
              })
            }
          } else {
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: resdata.data.message,
            })
          }
        }
      })
    }
    that.setData({
      payModal:e.detail.payModal
    })
  },
  /*关闭弹窗 */
  closeModal:function(e){
    let that = this;
    that.setData({
      payModal: e.detail.payModal
    })
  },
  closePaySuccess:function(){
    let that = this;
    that.setData({
      paySuccess:false
    });
    wx.navigateBack({
      delta: 1
    })
  },
  bindPickerChange:function(e){
    this.setData({
      Index: e.detail.value
    })
  },
  choosePosition:function(e){
    let that = this;
    wx.chooseLocation({
      success:function(res){
        //console.log(res);
        let chooseLo = res;
        let qqmapSdk  =  new QQMapWX({
          key:'FW4BZ-GNORF-MBVJT-JL3A6-UGCIZ-QOF4S'
        });
        qqmapSdk.reverseGeocoder({
           location: {
             latitude: chooseLo.latitude,
             longitude: chooseLo.longitude
           },
           success:function(resdata){
             //console.log(resdata);
             that.setData({
               adcode:resdata.result.ad_info.adcode,
               adName: resdata.result.formatted_addresses.recommend,
               latitude: chooseLo.latitude,
               longitude: chooseLo.longitude
             })
           }
         })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /* 添加需要上传的图片  */
  addImage:function(){
    let that = this;
    let newPicList = that.data.addPicList;
    let length = newPicList.length;
    if(length==9){
      wx.showModal({
        title: '提示',
        content: '最多只能添加9张图片',
      })
    }else{
      wx.chooseImage({
        count: 9 - length,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],
        success(res) {
          // tempFilePath可以作为img标签的src属性显示图片
          const tempFilePaths = res.tempFilePaths;
          for (let i = 0; i < tempFilePaths.length; i++) {
            if (length == 0) {
              newPicList[i] = {
                pic: tempFilePaths[i],
                name:''
              }
            } else {
              newPicList[i + length] = {
                pic: tempFilePaths[i],
                name: ''
              }
            };
          }
          for(let i=0;i<newPicList.length;i++){
            wx.uploadFile({
              url: config.ajaxUrl+'zfcommon/savePics',
              filePath: newPicList[i].pic,
              name: 'pic',
              header: {
                "Content-Type": "multipart/form-data"
              },
              success(resdata) {
                let data = JSON.parse(resdata.data);
                if (data.code == 0) {
                  newPicList[i].name = data.data.pic[0].picname
                } else {
                  newPicList[i].name = undefined
                }
              },
              fail(resdata) {
                newPicList[i].name = undefined;
                wx.showModal({
                  title: '网络请求出错',
                  content: '请重新添加图片',
                  cancle: false
                })
              }
            })
          }
          let finalPicList = []
          for(let j=0;j<newPicList.length;j++){
            if (newPicList[j].name!==undefined){
              finalPicList.push(newPicList[j])
            }
          }
          console.log(finalPicList);
          that.setData({
            addPicList: finalPicList
          })
        }
      })
    }
  },
  removeImg:function(e){
    let removeId = e.currentTarget.dataset.id;
    let that = this;
    wx.showModal({
      content: '确认删除此图片？',
      success:function(res){
        if(res.confirm){
          let newPic = that.data.addPicList;
          newPic.splice(removeId, 1);
          //console.log(newPic);
          that.setData({
            addPicList: newPic
          })
        }
      }
    })
  },
  viewImg:function(e){
    let removeId = e.currentTarget.dataset.id;
    let that = this;
    let newPic = that.data.addPicList;
    let urlPics = [];
    for(let i =0;i<newPic.length;i++){
      urlPics.push(newPic[i].pic)
    }
    wx.previewImage({
      current: urlPics[removeId], // 当前显示图片的http链接
      urls: urlPics// 需要预览的图片http链接列表
    })
  },
  goInvite:function(e){
    let that = this;
    let envelopeId = that.data.envelopeId;
    let payNum = that.data.payNum;
    wx.redirectTo({
      url: '/pages/envelopeInvite/index?payNum=' + payNum + '&envelopeId=' + envelopeId,
    })
  },
  openTree: function () {
    this.setData({
      jsbzState: true
    });
    wx.redirectTo({
      url: '/pages/treePages/pages/myTree/myTree',
    })
  },
})