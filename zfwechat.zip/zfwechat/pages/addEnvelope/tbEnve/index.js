// pages/addEnvelope/appsEnve/index.js
var QQMapWX = require('../../../libs/qqmap-wx-jssdk.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    chooseInfo: [{ name: '全市', id: 0 }, { name: '全区', id: 1 }, { name: '一公里内', id: 2 }],
    Index: 0,
    currentId: 0,// 已选红包可视范围ID
    adcode: 0,// 红包位置地区编号
    adName: '点击选择',
    payNum: 0,// 红包金额
    rpNum: 0,// 红包个数
    word: '',// 红包文字内容
    payModal: false,
    addAppsData: {
      yyName: { word: '', length: 0 },
      yyIntro: { word: '', length: 0 },
      yyDown: { word: '', length: 0 },
      yyImg: ''
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  /* 添加应用 */
  addYY: function () {
    let that = this;
    let addAppsData = JSON.stringify(that.data.addAppsData);
    wx.navigateTo({
      url: '/pages/addEnvelope/tbEnve/addTbLink/index?addAppsData=' + addAppsData,
    })
  },
  /* */
  editWord: function (e) {
    let that = this;
    that.setData({
      word: e.detail.value
    })
  },
  /*修改红包金额 */
  price: function (e) {
    let that = this;
    that.setData({
      payNum: e.detail.value
    })
  },
  /*修改红包个数 */
  rpNum: function (e) {
    let that = this;
    that.setData({
      rpNum: e.detail.value
    })
  },
  /*支付 */
  goPay: function () {
    let that = this;
    if (that.data.word !== '' && that.data.rpNum !== 0 && that.data.payNum !== 0 && that.data.adcode !== 0) {
      that.setData({
        payModal: true
      })
    } else {
      wx.showModal({
        showCancel: false,
        title: '提示',
        content: '请完善红包信息后再次提交',
      })
    }
  },
  /* 支付成功调用方法 */
  paySuccess: function (e) {
    let that = this;
    console.log(e.detail);
    that.setData({
      payModal: e.detail.payModal
    })
    wx.showModal({
      showCancel: false,
      title: '提示',
      content: '支付成功！！！！',
    })
  },
  /*关闭弹窗 */
  closeModal: function (e) {
    let that = this;
    that.setData({
      payModal: e.detail.payModal
    })
  },
  bindPickerChange: function (e) {
    console.log('当前选中的数值下标为', e.detail.value)
    this.setData({
      Index: e.detail.value
    })
  },
  choosePosition: function (e) {
    let that = this;
    wx.chooseLocation({
      success: function (res) {
        console.log(res);
        let chooseLo = res;
        let qqmapSdk = new QQMapWX({
          key: 'FW4BZ-GNORF-MBVJT-JL3A6-UGCIZ-QOF4S'
        });
        qqmapSdk.reverseGeocoder({
          location: {
            latitude: chooseLo.latitude,
            longitude: chooseLo.longitude
          },
          success: function (resdata) {
            //console.log(resdata);
            that.setData({
              adcode: resdata.result.ad_info.adcode,
              adName: resdata.result.formatted_addresses.recommend
            })
          }
        })
      }
    })
  },
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log(this.data.addAppsData);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})