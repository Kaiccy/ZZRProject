// pages/addEnvelope/appsEnve/addApps/index.js
const config = require('../../../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    addAppsData:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let addAppsData = JSON.parse(options.addAppsData);
    that.setData({
      addAppsData: addAppsData
    })
    console.log(that.data.addAppsData)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  getYYname:function(e){
    let that = this;
    let yyName = 'addAppsData.yyName';
    that.setData({
      [yyName]:{
        name:e.detail.value,
        length:e.detail.value.length
      }
    })
  },
  getYYintro: function (e) {
    let that = this;
    let yyIntro = 'addAppsData.yyIntro';
    that.setData({
      [yyIntro]: {
        name: e.detail.value,
        length: e.detail.value.length
      }
    })
  },
  getYYDown: function (e) {
    let that = this;
    let yyDown = 'addAppsData.yyDown';
    that.setData({
      [yyDown]: {
        name: e.detail.value,
        length: e.detail.value.length
      }
    })
  },
  addthis:function(){
     let that = this;
     let thisAppData = that.data.addAppsData;
    let pages = getCurrentPages();
    let prevPage = pages[pages.length - 2];
     prevPage.setData({
       addAppsData: thisAppData
     })
    wx.navigateBack({
      delta: 1
    })
  },
  addImg:function(){
    let that = this;
    wx.chooseImage({
      count:1,
      success: function(res) {
        console.log(res.tempFilePaths);
        wx.uploadFile({
          url: config.ajaxUrl+'zfcommon/savePics',
          filePath: res.tempFilePaths[0],
          name: 'pic',
          success:function(resdata){
            let data = JSON.parse(resdata.data)
            if (data.code==0){
              let yyImg = 'addAppsData.yyImg'
              that.setData({
                [yyImg]: {
                  pic: data.data.pic[0].picpath,
                  picname: data.data.pic[0].picname
                }
              })
            }else{
              wx.showModal({
                title: '提示',
                content: '图片上传失败请重新上传',
              })
            }
          },
          fail:function(resdata){
            wx.showModal({
              title: '提示',
              content: '网络异常请重新上传图片',
            })
          }
        })
      },
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})