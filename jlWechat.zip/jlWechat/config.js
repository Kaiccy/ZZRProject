

var config = {

  // 接口地址
  ajaxUrl: 'https://international.cjlu.edu.cn/sms/webservise/',
  imgUrl: 'https://international.cjlu.edu.cn/upload/',
  fileUrl: 'https://international.cjlu.edu.cn/upload/docs/',
  webUrl: 'https://international.cjlu.edu.cn/sms/other/'

// 测试接口
  // ajaxUrl: 'http://192.168.0.60:8090/jlisms/webservise',
  // imgUrl: 'http://192.168.0.60:8090/upload/',
  // fileUrl: 'http://192.168.0.60:8090/upload/docs/'
};

module.exports = config;