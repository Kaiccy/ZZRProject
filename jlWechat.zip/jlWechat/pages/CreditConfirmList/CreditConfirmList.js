// pages/CreditConfirmList/CreditConfirmList.js

const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[]
  },

  onLoad: function (options) {
    let that = this;
    that.getList();
  },

  getList: function () {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    ajax.GET({
      ajaxPoint: '/getCreditList',
      params: {
        xh: userInfo.xh
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          that.setData({
            list: res.data.infolist
          })

        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },
  
  onPullDownRefresh: function () {
    let that = this;
    that.getList();
  },

  //确定
  correctBtn: function (e) {
    let that = this;
    let idx = e.currentTarget.dataset.id;
    ajax.GET({
      ajaxPoint: '/confirmCredit',
      params: {
        id: idx,
        qrzt: 2
      },
      success: function (res) {
        console.log(res.data.infolist);
        if (res.data.retcode == 0) {
          wx.showToast({
            title: 'Sent successfully!',
            icon: 'none'
          })
          that.getList();
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  //不正确
  notCorrectBtn: function (e) {
    let that = this;
    let idx = e.currentTarget.dataset.id;
    ajax.GET({
      ajaxPoint: '/confirmCredit',
      params: {
        id: idx,
        qrzt: 3
      },
      success: function (res) {
        console.log(res.data.infolist);
        if (res.data.retcode == 0) {
          wx.showToast({
            title: 'Sent successfully!',
            icon: 'none'
          })
          that.getList();
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  /*查看详情 */
  showDetail: function (e) {
    let that = this;
    let id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/ConfirmWebview/ConfirmWebview?id=' + id +'&type=1',
    })
  }

})