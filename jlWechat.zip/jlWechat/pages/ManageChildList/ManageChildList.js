// pages/ManageChildList/ManageChildList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemsList: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let itemsList = JSON.parse(options.itemsList)
    that.setData({
      itemsList: itemsList
    })
  },

  //跳转详情
  selectThis: function (e) {
    let that = this;
    let idx = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/ManageInfo/ManageInfo?infoId=' + that.data.itemsList[idx].id,
    })
  }

})