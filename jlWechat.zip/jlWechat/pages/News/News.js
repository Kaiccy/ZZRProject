// pages/News/News.js

const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pager: 1,
    pagersize: 10,
    pageTotal: 0,
    newsList: [],
    picAddress: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    that.setData({
      picAddress: config.imgUrl + 'news/'
    })
    let userInfo = wx.getStorageSync('userInfo');
    if (userInfo.aid && userInfo.aid !== '') {

    } else {
      wx.redirectTo({
        url: '/pages/login/login',
      })
    };
    wx.stopPullDownRefresh();
    ajax.GET({
      ajaxPoint: '/getNewList',
      params: {
        pager: 1,
        pagesize: 10
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          console.log(res.data.infolist);
          for (var i = 0; i < res.data.infolist.length; i++) {
            res.data.infolist[i].content = WxParse.wxParse('article', 'html', res.data.infolist[i].content, that, 5);
            if (res.data.infolist[i].pics !== ('' || null)) {
              res.data.infolist[i].pics = res.data.infolist[i].pics.split(',');
            }
          }
          that.setData({
            newsList: res.data.infolist,
            pageTotal: res.data.pageTotal
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  //页面显示时
  onShow: function () {
    this.onLoad()
  },

  getNewsList: function (pager, pagesize) {
    let that = this;
    let newArrar = that.data.newsList;
    ajax.GET({
      ajaxPoint: '/getNewList',
      params: {
        pager: pager,
        pagesize: pagesize
      },
      success: function (res) {
        that.setData({
          pager: pager
        })
        if (res.data.retcode == 0) {
          for (var i = 0; i < res.data.infolist.length; i++) {
            res.data.infolist[i].content = WxParse.wxParse('article', 'html', res.data.infolist[i].content, that, 5);
            if (res.data.infolist[i].pics !== ('' || null)) {
              res.data.infolist[i].pics = res.data.infolist[i].pics.split(',');
            }
            newArrar.push(res.data.infolist[i])
          }
          that.setData({
            newsList: newArrar
          })

        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  onReachBottom: function () {
    let that = this;
    if (that.data.pageTotal > that.data.pager) {
      that.getNewsList(that.data.pager + 1, that.data.pagesize)
    } else {
      wx.showToast({
        title: 'No More',
      })
    }
  },
  onPullDownRefresh: function () {
    this.onLoad()
  },
  /*查看新闻详情 */
  viewDetail: function (e) {
    wx.navigateTo({
      url: '/pages/newsDetail/index?id=' + e.currentTarget.dataset.id,
    })
  }

})