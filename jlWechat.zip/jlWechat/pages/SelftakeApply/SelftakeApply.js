// pages/SelftakeApply/SelftakeApply.js

const app = getApp()
const config = require('../../config.js')
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    hiddenModalput: true, //隐藏弹出输入框
    stuId: '', //学号
    isDownloaded: false, //是否有下载文件
    subject: '', //科目
    attachment: '', //附件图片
    imagePath: '', //临时图片路径
    reason:'',

    multiArr: [[], []],
    multiIndex: [0, 0],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });

    // 获取学年学期
    that.getYearList();
  },

  // 学期学年
  getYearList: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getXqList',
      params: {

      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infolist;
        if (res.data.retcode == 0) {
          var bArr = [];
          for (var i = 0; i < arr.length; i++) {
            bArr.push(arr[i].xns + '-' + arr[i].xne);
          }
          mArr[0] = bArr;
          mArr[1] = ['The first semester', 'The second semester'];

          that.setData({
            multiArr: mArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })

  },

  //获取课程
  getSubject: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      subject: value
    })
  },

  //获取理由
  getReason: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      reason: value
    })
  },

  //下载文件
  downloadFiles: function (e) {
    let that = this;
    that.setData({
      hiddenModalput: false
    })
  },

  //弹出框的取消按钮
  cancel: function () {
    let that = this;
    that.setData({
      hiddenModalput: true
    });
  },

  //弹出框的确认
  confirm: function () {
    let that = this;
    if (that.data.stuId == that.data.userInfo.number) {
      //下载
      let url = config.fileUrl + 'Application form for class self-study.docx';
      console.log(url);
      //文件 
      wx.showModal({
        title: "Form's link",
        content: url,
        cancelText: 'Cancel',
        confirmText: 'Copy',
        success(res) {
          if (res.confirm) {
            console.log(res);
            //复制链接
            wx.setClipboardData({
              data: url,
              success: function (res) {
                wx.getClipboardData({
                  success: function (res) {
                    wx.showToast({
                      title: 'Copy success!'
                    })
                    that.setData({
                      isDownloaded: true,
                      hiddenModalput: true,
                      stuId:''
                    })
                    that.saveDownRecord()
                  }
                })
              }
            })
          }
        }
      })
    } else {
      wx.showToast({
        title: 'Student id error!',
        icon: 'none'
      })
    }
  },

  //保存下载记录
  saveDownRecord: function (e) {
    let that = this;
    ajax.GET({
      ajaxPoint: '/SaveDownRecord',
      params: {
        aid: that.data.userInfo.aid,
        sqtype: 10
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          console.log('下载记录');
        } else {

        }
      }
    })
  },

  // 获取学号
  getStudentId: function (e) {
    let that = this;
    let xh = e.detail.value;
    that.setData({
      stuId: xh
    })
  },

  // 添加图片
  chooseFile: function () {
    let that = this;
    if (that.data.isDownloaded) {
      wx.chooseImage({
        count: 1,  //最多可以选择的图片总数  
        sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有  
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
        success: function (res) {
          var tempFilesSize = res.tempFiles[0].size;  //获取图片的大小，单位B
          if (tempFilesSize <= 3000000) { //不能大于3M
            let tempFilePaths = res.tempFilePaths;  //获取图片
            wx.showLoading({
              title: 'loading',
            })
            wx.uploadFile({
              url: config.ajaxUrl + '/savePics.action',
              filePath: tempFilePaths[0],
              name: 'pic',
              formData: {
                pic: tempFilePaths[0]
              },
              header: {
                "Content-Type": "multipart/form-data"
              },
              success: function (resdata) {
                wx.hideLoading();
                let data = JSON.parse(resdata.data)
                if (data.retcode == 0) {
                  that.setData({
                    attachment: data.pic,
                    imagePath: tempFilePaths[0]
                  })
                  console.log(data.pic);
                } else {
                  wx.showToast({
                    icon: 'none',
                    title: 'Request error,please try again'
                  })
                }
              }
            })
          } else {    //图片大于3M
            wx.showToast({
              title: 'Files cannot be larger than 3 MB!',
              icon: 'none'
            })
          }
        }
      })
    } else {
      wx.showModal({
        title: 'Tip',
        content: 'Please download and fill in the form first!',
      })
    }
  },

  //提交
  submit: function () {
    let that = this;
    let subject = that.data.subject;
    let atta = that.data.attachment;
    let reason = that.data.reason;
    let idx = that.data.multiIndex[1] + 1;
    let sterm = that.data.multiArr[0][that.data.multiIndex[0]] + '-' + idx;
    if (subject != '' && reason != '' && atta != '' && sterm !== '') {
      ajax.GET({
        ajaxPoint: '/saveSelfStudy',
        params: {
          aid: that.data.userInfo.aid,
          name: that.data.userInfo.xm,
          major: subject,          
          sqyy:reason,
          filename: atta,
          pxq: sterm
        },
        success: function (res) {
          if (res.data.retcode == 0) {
            wx.showModal({
              title: 'Tips',
              showCancel: false,
              content: 'Success!',
              success: function (res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          } else {
            wx.showModal({
              title: 'Error',
              content: res.data.meg,
              cancelText: 'Cancel',
              confirmText: 'Confirm',
              success(res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          }
        }
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: 'Please complete the information',
      })
    }

  }

})