// pages/Attendance/Attendance.js

const app = getApp()
const config = require('../../config.js')
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    courseAndFrequency: [],//各个科目成绩
    date: '',
    requiredFrequency:'',//应到次数
    actualFrequency:'', //实到次数
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    
    that.setData({
      date: Y + '-' + M
    });
  },

  //添加成绩
  addCourse: function () {
    let that = this;
    var arr = that.data.courseAndFrequency;
    arr.push({});
    that.setData({
      courseAndFrequency: arr
    })
  },

  //删除成绩
  deleteCourse: function (e) {
    let that = this;
    let index = e.currentTarget.dataset.id;
    var arr = that.data.courseAndFrequency;
    arr.splice(index, 1);
    that.setData({
      courseAndFrequency: arr
    })
  },

  //获取课程
  getCourse: function (e) {
    let that = this;
    let index = e.currentTarget.dataset.index;
    var arr = that.data.courseAndFrequency;
    arr[index].classname = e.detail.value
    this.setData({
      courseAndFrequency: arr
    })
    console.log(that.data.courseAndFrequency);
  },

  //获取到课率
  getFrequency: function (e) {
    let that = this;
    let index = e.currentTarget.dataset.index;
    var arr = that.data.courseAndFrequency;
    arr[index].dkl = e.detail.value
    this.setData({
      courseAndFrequency: arr
    })
    console.log(that.data.courseAndFrequency);
  },

  // 获取应到次数
  getRequiredFrequency: function (e) {
    let that = this;
    that.setData({
      requiredFrequency: e.detail.value
    })
  },

  // 获取实到次数
  getActuaFrequency: function (e) {
    let that = this;
    this.setData({
      actualFrequency: e.detail.value
    })
  },

  /* 时间 */
  bindDateChange: function (e) {
    let that = this;
    that.setData({
      date: e.detail.value
    })
  },

  //提交
  submit: function (e) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');

    let courceStr = JSON.stringify(that.data.courseAndFrequency);
    let subCourceStr = courceStr.substring(1, courceStr.length - 1);
    console.log(subCourceStr);

    if (that.data.date !== '' && that.data.requiredFrequency !== '' && that.data.actualFrequency !== '' && that.data.courseAndFrequency.length !== 0) {
      ajax.GET({
        ajaxPoint: '/addDkl',
        params: {
          xh: userInfo.xh,
          aid: userInfo.aid,
          dkltime: that.data.date,
          sactive: that.data.requiredFrequency,
          tactive: that.data.actualFrequency,
          kc: subCourceStr,
        },
        success: function (res) {
          if (res.data.retcode == 0) {
            wx.showModal({
              title: 'Tips',
              showCancel: false,
              content: 'Successful application',
              confirmText: 'Confirm',
              success: function (res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          } else {
            wx.showToast({
              title: res.data.meg,
              icon: 'none'
            })
          }
        }
      })
    } else {
      wx.showToast({
        title: 'Please improve the application information',
        icon: 'none'
      })
    }
  },

})