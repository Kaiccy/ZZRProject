// pages/leaveApply/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:[],
    date: '2016-09-01',
    lxyx:'',
    lxsj:'',
    sxfswc:'',
    byindex:0,//毕业申请
    index:0,//离校申请单
    byqxList: ['Learning in China', 'Working in China', 'Return home','Other'],
    lxsqd:['Complate','No'],
    byqx:'',
    lxsq:'',
    note:''
  },
  /* 离校原因 */
  bindLRChange:function(e){
    let that = this;
    that.setData({
      lxyx: e.detail.value
    })
  },
  /* 离校时间 */
  bindDateChange: function (e) {
    let that = this;
    that.setData({
      date: e.detail.value
    })
  },
  /* 毕业去向 */
  bindPickerChange: function (e) {
    let that = this;
    that.setData({
      byindex: Number(e.detail.value)
    })
  },
  /* 离校申请单 */
  bindDeChange: function (e) {
    let that = this;
    that.setData({
      index: Number(e.detail.value)
    })
  },
  /* 备注 */
  bindNoteChange: function (e) {
    let that = this;
    that.setData({
      note: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    console.log("当前时间：" + Y + '年' + M + '月' + D + '日');
    that.setData({
      date: Y+'-'+M+'-'+D
    });
  },
  /*提交申请 */
  tj:function(e){
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    if (that.data.lxyx !== '' && that.data.date !== '' && that.data.index !== '' && that.data.byindex !== '' ){
      ajax.GET({
        ajaxPoint: '/saveLeavingSchool',
        params: {
          xh: userInfo.xh,
          lxyx: that.data.lxyx,
          lxsj: that.data.date,
          sxfswc: that.data.index+1,
          byqx: that.data.byindex+1,
          bz: that.data.note
        },
        success:function(res){
          if(res.data.retcode==0){
            wx.showModal({
              title: 'Tips',
              showCancel:false,
              content: 'Successful application',
              confirmText: 'Confirm',
              success:function(res){
                if(res.confirm){
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          }else{
            wx.showToast({
              title: res.data.meg,
              icon: 'none'
            })
          }
        }
      })
    }else{
      wx.showToast({
        title: 'Please improve the application information',
        icon:'none'
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})