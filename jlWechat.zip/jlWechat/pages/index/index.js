//index.js
//获取应用实例
const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({
  data: {
    imgUrls: [
      'https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1835962148,2944781709&fm=173&app=25&f=JPEG?w=218&h=146&s=A9325A95481E79CA16125CD80300E0B8',
      'https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1835962148,2944781709&fm=173&app=25&f=JPEG?w=218&h=146&s=A9325A95481E79CA16125CD80300E0B8',
      'https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1835962148,2944781709&fm=173&app=25&f=JPEG?w=218&h=146&s=A9325A95481E79CA16125CD80300E0B8'
    ],
    pager:1,
    pagersize:10,
    pageTotal:0,
    newsList:[],
    picAddress:'',
    userInfo:''
  },
  onLoad: function () {
    let that = this;
    that.setData({
      picAddress: config.imgUrl + 'news/'
    })
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    })
    if (userInfo.aid && userInfo.aid !== '') {
      
    } else {
      wx.redirectTo({
        url: '/pages/login/login',
      })
    };
    wx.stopPullDownRefresh();
    ajax.GET({
      ajaxPoint: '/getNewList',
      params: {
        pager: 1,
        pagesize: 10
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          for (var i = 0; i < res.data.infolist.length; i++) {
            res.data.infolist[i].content = WxParse.wxParse('article', 'html', res.data.infolist[i].content, that, 5);
            if (res.data.infolist[i].pics!==(''||null)){
              res.data.infolist[i].pics = res.data.infolist[i].pics.split(',');
            }
          }
          that.setData({
            newsList:res.data.infolist,
            pageTotal: res.data.pageTotal
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },
  getNewsList: function (pager, pagesize){
    let that = this;
    let newArrar = that.data.newsList;
    ajax.GET({
      ajaxPoint: '/getNewList',
      params: {
        pager: pager,
        pagesize: pagesize
      },
      success: function (res) {
        that.setData({
          pager: pager
        })
        if (res.data.retcode == 0) {
          for(var i =0;i<res.data.infolist.length;i++){
            res.data.infolist[i].content = WxParse.wxParse('article', 'html', res.data.infolist[i].content, that, 5);
            if (res.data.infolist[i].pics !== ('' || null)) {
              res.data.infolist[i].pics = res.data.infolist[i].pics.split(',');
            }
            newArrar.push(res.data.infolist[i])
          }
          that.setData({
            newsList: newArrar
          })
          
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },
  // onReachBottom:function(){
  //   let that = this;
  //   if (that.data.pageTotal > that.data.pager) {
  //     that.getNewsList(that.data.pager + 1, that.data.pagesize)
  //   } else {
  //     wx.showToast({
  //       title: 'No More',
  //     })
  //   }
  // },
  // onPullDownRefresh:function(){
  //   this.onLoad()
  // },
  /*查看新闻详情 */
  viewDetail:function(e){
    wx.navigateTo({
      url: '/pages/newsDetail/index?id='+e.currentTarget.dataset.id,
    })
  }
})
