// pages/RewardPunishList/RewardPunishList.js

const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pager: 1,
    pagersize: 10,
    pageTotal: 0,
    rewardPunishList: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    
    let userInfo = wx.getStorageSync('userInfo');

    wx.stopPullDownRefresh();
    ajax.GET({
      ajaxPoint: '/jcCheckList',
      params: {
        pager: 1,
        pagesize: 10,
        xh:userInfo.xh
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          
          that.setData({
            rewardPunishList: res.data.infolist,
            pageTotal: res.data.pageTotal
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  //页面显示时
  onShow: function () {
    this.onLoad()
  },

  getRewardList: function (pager, pagesize) {
    let that = this;
    let newArrar = that.data.newsList;
    let userInfo = wx.getStorageSync('userInfo');
    ajax.GET({
      ajaxPoint: '/getNewList',
      params: {
        pager: pager,
        pagesize: pagesize,
        xh: userInfo.xh
      },
      success: function (res) {
        that.setData({
          pager: pager
        })
        if (res.data.retcode == 0) {
          for (var i = 0; i < res.data.infolist.length; i++) {
            newArrar.push(res.data.infolist[i])
          }
          that.setData({
            rewardPunishList: newArrar
          })

        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  onReachBottom: function () {
    let that = this;
    if (that.data.pageTotal > that.data.pager) {
      that.getRewardList(that.data.pager + 1, that.data.pagesize)
    } else {
      wx.showToast({
        title: 'No More',
      })
    }
  },
  onPullDownRefresh: function () {
    this.onLoad()
  },
  /*查看详情 */
  selectThis: function (e) {
    let that = this;
    let idx = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/RewardPunishInfo/RewardPunishInfo?id=' + that.data.rewardPunishList[idx].id + "&type=" + that.data.rewardPunishList[idx].jclx,
    })
  }

})