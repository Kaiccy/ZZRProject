// pages/leaveApply/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:[],
    date: '2016-09-01',
    lxyx:'',
    lxsj:'',
    sxfswc:'',
    byindex:0,//毕业申请
    index:0,//离校申请单
    byqxList: ['Learning in China', 'Working in China', 'Return home','Other'],
    lxsqd:['Complate','No'],
    byqx:'',
    lxsq:'',
    note:'',

    multiArr: [[], []],
    multiIndex: [0,0],
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    console.log("当前时间：" + Y + '年' + M + '月' + D + '日');
    that.setData({
      date: Y + '-' + M + '-' + D
    });

    // 获取学年学期
    that.getYearList();
  },

// 学期学年
  getYearList: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getXqList',
      params: {
        
      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infolist;
        if (res.data.retcode == 0) {
          var bArr = [];
          for (var i = 0; i < arr.length; i++) {
            bArr.push(arr[i].xns + '-' + arr[i].xne);
          }
          mArr[0] = bArr;
          mArr[1] = ['The first semester','The second semester'];

          that.setData({
            multiArr: mArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })
    
  },

  /* 离校原因 */
  bindLRChange:function(e){
    let that = this;
    that.setData({
      lxyx: e.detail.value
    })
  },
  /* 离校时间 */
  bindDateChange: function (e) {
    let that = this;
    that.setData({
      date: e.detail.value
    })
  },
  /* 毕业去向 */
  bindPickerChange: function (e) {
    let that = this;
    that.setData({
      byindex: Number(e.detail.value)
    })
  },
  /* 离校申请单 */
  bindDeChange: function (e) {
    let that = this;
    that.setData({
      index: Number(e.detail.value)
    })
  },
  /* 备注 */
  bindNoteChange: function (e) {
    let that = this;
    that.setData({
      note: e.detail.value
    })
  },
  
  /*提交申请 */
  tj:function(e){
    // console.log(e.detail.formId);
    
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    let idx = that.data.multiIndex[1] + 1;
    let sterm = that.data.multiArr[0][that.data.multiIndex[0]] + '-' + idx;
    if (that.data.lxyx !== '' && that.data.date !== '' && that.data.index !== '' && that.data.byindex !== '' && sterm !== ''){
      ajax.GET({
        ajaxPoint: '/saveLeavingSchool',
        params: {
          xh: userInfo.xh,
          lxyx: that.data.lxyx,
          lxsj: that.data.date,
          sxfswc: that.data.index+1,
          byqx: that.data.byindex+1,
          bz: that.data.note,
          // formid:e.detail.formId
          atype: 1,
          pxq: sterm
        },
        success:function(res){
          if(res.data.retcode==0){
            wx.showModal({
              title: 'Tips',
              showCancel:false,
              content: 'Successful application',
              confirmText: 'Confirm',
              success:function(res){
                if(res.confirm){
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          }else{
            wx.showToast({
              title: res.data.meg,
              icon: 'none'
            })
          }
        }
      })
    }else{
      wx.showToast({
        title: 'Please improve the application information',
        icon:'none'
      })
    }
  },


})