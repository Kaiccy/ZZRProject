// pages/personnal/personal.js

const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemsList: [
      { name: "Application record" },
      { name: "Manage method list" },
      { name: "Rewards and punishments list" },
      { name: "Credit confirmation list" },
      { name: "Student status confirmation list" }, 
      { name: "Change the password"},
      { name: "Log out"}
                ],
    headImage:'/static/images/headIcon.png',
    loginname:''           
  },

  selectThis: function (e){
    let that = this;
    let itemId = e.currentTarget.dataset.id;
    // 申请记录
    if (itemId == 0) {
      wx.navigateTo({
        url: '/pages/applyRecord/applyRecord',
      })
    }
    // 管理列表
    if (itemId == 1) {
      wx.navigateTo({
        url: '/pages/ManageList/ManageList',
      })
    }
    // 奖惩列表
    if (itemId == 2) {
      wx.navigateTo({
        url: '/pages/RewardPunishList/RewardPunishList',
      })
    }
    // 学分确认
    if (itemId == 3) {
      wx.navigateTo({
        url: '/pages/CreditConfirmList/CreditConfirmList',
      })
    }
    // 学籍确认
    if (itemId == 4) {
      wx.navigateTo({
        url: '/pages/StuStatusConfirmList/StuStatusConfirmList',
      })
    }
    // 修改密码
    if (itemId == 5){
      wx.navigateTo({
        url: '/pages/changePassword/changePassword',
      })
    }
    // 退出登录
    if (itemId == 6){
      try {
        wx.clearStorageSync()
      } catch (e) {
        
      }
      wx.redirectTo({
        url: '/pages/login/login',
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    console.log(userInfo);
    that.setData({
      loginname: userInfo.loginname
    })
    if (userInfo.zp != '' && userInfo.zp != null){
      that.setData({
        headImage: config.imgUrl + userInfo.sqbh + '/' + userInfo.zp
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})