// pages/Scholarship/Scholarship.js
const app = getApp()
const config = require('../../config.js')
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    scholarshipList:[],
    fName:'',
    gName:'',
    chineseName:'',
    college:'',
    institude:'',
    major:'',
    scholarshipIdx:0,
    reason:'',
    achivement:'',
    credit:'',
    courseAndScore: [],//各个科目成绩

    scoreImagesUrl: [], //附件图片临时地址
    scoreImages: [],  //服务器返回 
    scoreAttaCount:0, //成绩单附件个数

    hskImagesUrl:[],//临时路径
    hskImages:[], //服务器返回
    hskAttaCount: 0, //hsk附件个数

    otherImagesUrl: [],//临时路径
    otherImages: [], //服务器返回
    otherAttaCount: 0, //其他证书附件个数

    otherAchive:'', //其他成就

    userTypeArr: ['Degree-seeking Student', 'Language student ','1+3 program student'], //学生类型
    typeIndex:0,

    scholarFirstArr:null,
    scholarSecArr: null,
    multiArr: [[], []],
    multiIndex: [0,0],
    isScroll: false, //是否有滑动
    col: 0, //滚动第几列
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });
    that.getScholarshipList('');
  },

  //请求奖学金列表
  getScholarshipList: function (id) {
    let that = this;
    ajax.GET({
      ajaxPoint: '/burseList',
      params: {
        jtype: id
      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infolist;
        if (res.data.retcode == 0) {
          if (!that.data.isScroll) {
            //未滑动
            if (that.data.scholarFirstArr == null) {
              var fArr = [];
              for (var i = 0; i < arr.length; i++) {
                fArr.push(arr[i]);
              }
              mArr[0] = fArr;
              that.setData({
                scholarFirstArr: arr
              })
              that.getScholarshipList(arr[0].id);
            } else if (that.data.scholarSecArr == null) {
              var sArr = [];
              for (var i = 0; i < arr.length; i++) {
                sArr.push(arr[i]);
              }
              mArr[1] = sArr;
              that.setData({
                scholarSecArr: arr
              })
              // that.getScholarshipList(arr[0].id);
            }
          } else {
            //有滑动            
            switch (that.data.col + 1) {
              case 1:
                var sArr = [];
                for (var i = 0; i < arr.length; i++) {
                  sArr.push(arr[i]);
                }
                mArr[1] = sArr;
                that.setData({
                  floorArr: arr,
                  col: 1
                })
                if (arr.length != 0) {
                  let pid = arr[0].id;
                  that.getScholarshipList(pid);
                }
                break;
            }
          }
          that.setData({
            multiArr: mArr
          })
          console.log(that.data.multiArr)
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

// 学生类型
  bindPickerChange: function (e) {
    let that = this;
    that.setData({
      typeIndex: Number(e.detail.value)
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })
    var pid = '';
    var mutA = that.data.multiArr;
    switch (e.detail.column) {
      case 0:
        let arr0 = that.data.scholarFirstArr;
        for (var i = 0; i < arr0.length; i++) {
          if (e.detail.value == i) {
            pid = arr0[i].id;
          }
        }
        mutA[1] = [];
        that.setData({
          scholarSecArr: null,
          multiArr: mutA
        })
        break;
    }
    that.setData({
      isScroll: true
    })
    that.getScholarshipList(pid);
  },

  //获取姓
  getFamilyName: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      fName: value
    })
  },

  //获取名
  getGivenName: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      gName: value
    })
  },

  //获取中文名
  getChineseName: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      chineseName: value
    })
  },

  //获取学校
  getCollege: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      college: value
    })
  },

  //获取研究所
  getInstitute: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      institude: value
    })
  },

  //获取主修
  getMajor: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      major: value
    })
  },

  //获取奖学金
  getScholarship: function (e) {
    let that = this;
    that.setData({
      scholarshipIdx: Number(e.detail.value)
    })
  },

  //获取自我介绍
  getReason: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      reason: value
    })
  },

  //获取成就
  getAchievement: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      achivement: value
    })
  },

  //获取总学分
  getTotalCredits: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      credit: value
    })
  },

  //获取其他成就
  getOtherAchive: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      otherAchive: value
    })
  },

  //添加成绩
  addCourse: function () {
    let that = this;
    var arr = that.data.courseAndScore;
    arr.push({});
    that.setData({
      courseAndScore: arr
    })
  },

  //删除成绩
  deleteCourse: function (e) {
    let that = this;
    let index = e.currentTarget.dataset.id;
    var arr = that.data.courseAndScore;
    arr.splice(index, 1);
    that.setData({
      courseAndScore: arr
    })
  },

  //获取课程
  getCourse: function (e) {
    let that = this;
    let index = e.currentTarget.dataset.index;
    var arr = that.data.courseAndScore;
    arr[index].km = e.detail.value
    this.setData({
      courseAndScore: arr
    })
    console.log(that.data.courseAndScore);
  },

  //获取成绩
  getScore: function (e) {
    let that = this;
    let index = e.currentTarget.dataset.index;
    var arr = that.data.courseAndScore;
    arr[index].cj = e.detail.value
    this.setData({
      courseAndScore: arr
    })
    console.log(that.data.courseAndScore);
  },

  //删除成绩单图片
  deleteScoreImage: function (e) {
    let that = this;
    let idx = e.currentTarget.dataset.idx;
    var arrPic = that.data.scoreImages;
    arrPic.splice(idx, 1);
    var arrUrl = that.data.scoreImagesUrl;
    arrUrl.splice(idx, 1);
    let num = that.data.scoreAttaCount - 1;
    that.setData({
      scoreImages: arrPic,
      scoreImagesUrl: arrUrl,
      scoreAttaCount: num
    })
    // console.log(that.data.scoreImages);
    // console.log(that.data.scoreImagesUrl);
  },

// 删除hsk附件
  deleteHSKImage: function (e) {
    let that = this;
    let idx = e.currentTarget.dataset.idx;
    var arrPic = that.data.hskImages;
    arrPic.splice(idx, 1);
    var arrUrl = that.data.hskImagesUrl;
    arrUrl.splice(idx, 1);
    let num = that.data.hskAttaCount - 1;
    that.setData({
      hskImages: arrPic,
      hskImagesUrl: arrUrl,
      hskAttaCount: num
    })
    // console.log(that.data.hskImages);
    // console.log(that.data.hskImagesUrl);
  },

  // 删除其他证书
  deleteOtherImage: function (e) {
    let that = this;
    let idx = e.currentTarget.dataset.idx;
    var arrPic = that.data.otherImages;
    arrPic.splice(idx, 1);
    var arrUrl = that.data.otherImagesUrl;
    arrUrl.splice(idx, 1);
    let num = that.data.otherAttaCount - 1;
    that.setData({
      otherImages: arrPic,
      otherImagesUrl: arrUrl,
      otherAttaCount: num
    })
  },

  // 添加成绩附件
  chooseScoreFile: function () {
    let that = this;
    let num = 4 - that.data.scoreAttaCount;
    wx.chooseImage({
      count: num,  //最多可以选择的图片总数  
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      success: function (res) {
        //判断文件大小
        for (var i = 0; i < res.tempFiles.length; i++) {
          var tempFilesSize = res.tempFiles[i].size;  //获取图片的大小，单位B
          if (tempFilesSize > 3000000) { //不能大于3M
            wx.showToast({
              title: 'Every file cannot be larger than 3 MB!',
              icon: 'none'
            })
            return;
          }
        }
        //上传文件
        let tempFilePaths = res.tempFilePaths;  //获取图片路径
        var count = 0;
        for (var i = 0; i < tempFilePaths.length; i++) {
          wx.showLoading({
            title: 'loading',
          })
          wx.uploadFile({
            url: config.ajaxUrl + '/savePics.action',
            filePath: tempFilePaths[i],
            name: 'pic',
            formData: {
              pic: tempFilePaths[i]
            },
            header: {
              "Content-Type": "multipart/form-data"
            },
            success: function (resdata) {
              wx.hideLoading();

              let data = JSON.parse(resdata.data)
              if (data.retcode == 0) {
                var arrUrl = that.data.scoreImagesUrl;
                arrUrl.push(tempFilePaths[count]); //上传有延迟所以使用count来计数
                var arrPic = that.data.scoreImages;
                arrPic.push(data.pic);
                that.setData({
                  scoreImages: arrPic,
                  scoreImagesUrl: arrUrl
                })
                count++;
                // console.log(that.data.scoreImages);
                // console.log(that.data.scoreImagesUrl);
                let scoreAttNum = that.data.scoreAttaCount + 1;
                that.setData({
                  scoreAttaCount: scoreAttNum
                })
              } else {
                wx.showToast({
                  icon: 'none',
                  title: 'Request error,please try again'
                })
              }
            }
          })
        }

      }
    })
  },

//hsk 附件
  chooseHSKFile: function () {
    let that = this;
    let num = 2 - that.data.hskAttaCount;
    wx.chooseImage({
      count: num,  //最多可以选择的图片总数  
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      success: function (res) {
        //判断文件大小
        for (var i = 0; i < res.tempFiles.length; i++) {
          var tempFilesSize = res.tempFiles[i].size;  //获取图片的大小，单位B
          if (tempFilesSize > 3000000) { //不能大于3M
            wx.showToast({
              title: 'Every file cannot be larger than 3 MB!',
              icon: 'none'
            })
            return;
          }
        }
        //上传文件
        let tempFilePaths = res.tempFilePaths;  //获取图片路径
        var count = 0;
        for (var i = 0; i < tempFilePaths.length; i++) {
          wx.showLoading({
            title: 'loading',
          })
          wx.uploadFile({
            url: config.ajaxUrl + '/savePics.action',
            filePath: tempFilePaths[i],
            name: 'pic',
            formData: {
              pic: tempFilePaths[i]
            },
            header: {
              "Content-Type": "multipart/form-data"
            },
            success: function (resdata) {
              wx.hideLoading();

              let data = JSON.parse(resdata.data)
              if (data.retcode == 0) {
                var arrUrl = that.data.hskImagesUrl;
                arrUrl.push(tempFilePaths[count]); //上传有延迟所以使用count来计数
                var arrPic = that.data.hskImages;
                arrPic.push(data.pic);
                that.setData({
                  hskImages: arrPic,
                  hskImagesUrl: arrUrl
                })
                count++;
                // console.log(that.data.hskImages);
                // console.log(that.data.hskImagesUrl);
                let hskAttNum = that.data.hskAttaCount + 1;
                that.setData({
                  hskAttaCount: hskAttNum
                })
              } else {
                wx.showToast({
                  icon: 'none',
                  title: 'Request error,please try again'
                })
              }
            }
          })
        }

      }
    })
  },

  //其他证书附件
  chooseOtherFile: function () {
    let that = this;
    let num = 10 - that.data.otherAttaCount;
    wx.chooseImage({
      count: num,  //最多可以选择的图片总数  
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      success: function (res) {
        //判断文件大小
        for (var i = 0; i < res.tempFiles.length; i++) {
          var tempFilesSize = res.tempFiles[i].size;  //获取图片的大小，单位B
          if (tempFilesSize > 3000000) { //不能大于3M
            wx.showToast({
              title: 'Every file cannot be larger than 3 MB!',
              icon: 'none'
            })
            return;
          }
        }
        //上传文件
        let tempFilePaths = res.tempFilePaths;  //获取图片路径
        var count = 0;
        for (var i = 0; i < tempFilePaths.length; i++) {
          wx.showLoading({
            title: 'loading',
          })
          wx.uploadFile({
            url: config.ajaxUrl + '/savePics.action',
            filePath: tempFilePaths[i],
            name: 'pic',
            formData: {
              pic: tempFilePaths[i]
            },
            header: {
              "Content-Type": "multipart/form-data"
            },
            success: function (resdata) {
              wx.hideLoading();

              let data = JSON.parse(resdata.data)
              if (data.retcode == 0) {
                var arrUrl = that.data.otherImagesUrl;
                arrUrl.push(tempFilePaths[count]); //上传有延迟所以使用count来计数
                var arrPic = that.data.otherImages;
                arrPic.push(data.pic);
                that.setData({
                  otherImages: arrPic,
                  otherImagesUrl: arrUrl
                })
                count++;

                let otherAttNum = that.data.otherAttaCount + 1;
                that.setData({
                  otherAttaCount: otherAttNum
                })
              } else {
                wx.showToast({
                  icon: 'none',
                  title: 'Request error,please try again'
                })
              }
            }
          })
        }

      }
    })
  },

  //提交
  submit: function () {
    let that = this;
    console.log('=======');
    let courceStr = JSON.stringify(that.data.courseAndScore);
    let subCourceStr = courceStr.substring(1, courceStr.length - 1);
    console.log(subCourceStr);
    let chineseName = that.data.chineseName;
    let institude = that.data.institude;
    let idx = that.data.scholarshipIdx;
    let reason = that.data.reason;
    let gName = that.data.gName;
    let fName = that.data.fName;
    let cred = that.data.credit;
    let otherAchive = that.data.otherAchive;
    let maj = that.data.major;
    let scoreLength = that.data.courseAndScore.length;
    let type = that.data.typeIndex + 1;
    var scholarType = '';

    // 获取奖学金id
    if(that.data.multiArr[1].length == 0){
      scholarType = that.data.multiArr[0][that.data.multiIndex[0]].id;
    }else{
      scholarType = that.data.multiArr[1][that.data.multiIndex[1]].id;
    }
    console.log('scholarType == ' + scholarType);
    console.log(that.data.multiArr[1][that.data.multiIndex[1]]);

    if (type == 3 && that.data.hskAttaCount == 0){
      wx.showToast({
        icon: 'none',
        title: 'Please upload the HSK certificate',
      })
      return;
    }

    if (chineseName != '' && institude != '' && reason != '' && gName != '' && cred != '' && fName != '' && that.data.scoreAttaCount > 0 && maj != '' && scoreLength > 0 && scholarType != '') {
      ajax.GET({
        ajaxPoint: '/saveBurse',
        params: {
          aid: that.data.userInfo.aid,
          xh: that.data.userInfo.xh,
          sqyy: reason,
          stutype: type,
          chname: chineseName,
          enname: gName+' '+fName,
          institute:institude,
          jxjname: scholarType,
          gkcj: subCourceStr,
          credits: that.data.credit,
          cjdfj: that.data.scoreImages.join(","),
          qtzs: that.data.otherImages.join(","),
          qtcj: otherAchive,
          major: maj,
          hsk: that.data.hskImages.join(",")
        },
        success: function (res) {
          if (res.data.retcode == 0) {
            wx.showModal({
              title: 'Tips',
              showCancel: false,
              content: 'Success!',
              confirmText: 'Confirm',
              success: function (res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          } else {
            wx.showModal({
              title: 'Error',
              content: res.data.meg,
              cancelText: 'Cancel',
              confirmText: 'Confirm',
              success(res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          }
        }
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: 'Please complete the information',
      })
    }

  }

})