// pages/ManageInfo/ManageInfo.js

const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:{},
    infoId:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      infoId: JSON.parse(options.infoId)
    })
    this.getData();
  },

  //请求数据
  getData: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/loadMethod',
      params: {
        id: that.data.infoId
      },
      success: function (res) {
        let font = res.data.content.replace(/<[^>]+>/g, '');
        if (res.data.retcode == 0) {
          // 解析标签
          let content = res.data.content.replace(/<[^>]+>/g, '');
          res.data.content = content;
          that.setData({
            info: res.data
          })
        } else {
          wx.showToast({
            title: 'Network error！',
            icon: 'none'
          })
        }
      }
    })
  },

})