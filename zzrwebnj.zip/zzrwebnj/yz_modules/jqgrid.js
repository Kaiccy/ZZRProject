/**
 * Created by yz on 2018-1-07.
 */
exports.yzJqGrid = yzJqGrid;
exports.gridPagerInfo = gridPagerInfo;
function yzJqGrid(option){
    if  (!Array.isArray(option.opmols)) {
        return {gridBody:yzJqGridBody(option),gridDivBody:gridDiv(option),gridActBody:gridMultiAct(option)};
    }else{
        return {gridBody:yzJqGridBody(option),gridDivBody:gridDiv(option),gridActBody:gridAct(option)};
    }
}
function yzJqGridBody(option){
    var jqGridBody=[];
    jqGridBody.push('$(document).ready(function () {');
    jqGridBody.push('$("#'+option.id+'").jqGrid({');
    jqGridBody.push('url: "'+option.url+'",');
    jqGridBody.push('mtype: "POST",');
    jqGridBody.push('styleUI: "Bootstrap",');
    jqGridBody.push('datatype: "json",');
    jqGridBody.push('colModel: '+ JSON.stringify(option.colModels)+",");
    jqGridBody.push('autowidth: true,');
    jqGridBody.push('autoheight:true,');
    jqGridBody.push('viewrecords: true,');
    jqGridBody.push('multiselectWidth: 60,');
    if(option.multiselect){
        jqGridBody.push('multiselect: '+option.multiselect+',');
    }
    if(option.rownumbers){
        jqGridBody.push('rownumbers: '+option.rownumbers+',');
    }
    if(option.rowNum){
        jqGridBody.push('rowNum: '+option.rowNum+',');
    }else{
        jqGridBody.push('rowNum: 10,');
    }
    //设置自定义jsonReader
    if(option.dymaicLoadComplete){
        jqGridBody.push(' loadComplete: function() { ');
        jqGridBody.push(' var userdata =  jQuery("#'+option.id+'").getGridParam("userData") ;  ');
        option.summtypros.forEach(function(value,index,array){
            jqGridBody.push(' $('+value+').'+option.method+'(userdata.'+value+') ; ');
            }
        );
        jqGridBody.push(' } ,');
    }
    jqGridBody.push('gridComplete: function () {');
    jqGridBody.push(gridComplete(option));
    jqGridBody.push('},');
    jqGridBody.push('pager: "#'+option.id+'Pager"');
    jqGridBody.push('});');
    jqGridBody.push('});');
    return jqGridBody.join("").toString("");
}
function gridComplete(option) {
    var gridCompleteBody=[];
    gridCompleteBody.push('if(jQuery.isFunction(window.gridLayout)) gridLayout("'+option.id+'");');
    if(option.loadfunction){
        gridCompleteBody.push(option.loadfunction);
    }
    gridCompleteBody.push(' if (typeof(opmol'+option.id+') != "undefined" || typeof(opmol) != "undefined") {');
    gridCompleteBody.push('var ids = jQuery("#'+option.id+'").getDataIDs();');
    gridCompleteBody.push('for (var i = 0; i < ids.length; i++) {');
    gridCompleteBody.push('if (typeof(opmol'+option.id+') != "undefined") {');
    gridCompleteBody.push('var op = opmol'+option.id+';');
    gridCompleteBody.push('} else {');
    gridCompleteBody.push('var op = opmol;');
    gridCompleteBody.push('}');
    gridCompleteBody.push('for (var o in op) {');
    gridCompleteBody.push('for (var oo in op[o]) {');
    gridCompleteBody.push('var op_ = "";');
    gridCompleteBody.push('for (var j = 0; j < op[o][oo].length; j++) {');
    gridCompleteBody.push('var i_qeFun = op[o][oo][j].event;');
    gridCompleteBody.push('if (i_qeFun != undefined) {');
    gridCompleteBody.push('if (typeof i_qeFun == "function") {');
    gridCompleteBody.push('var rd = jQuery("#'+option.id+'").getRowData(ids[i]);');
    gridCompleteBody.push('if (i_qeFun(rd) || i_qeFun(rd) == undefined) {');
    gridCompleteBody.push("op_=op_+\"<a href='javascript:void(0);' class='grid-nav-bot  \"+op[o][oo][j].className+\"' onclick='\"+op[o][oo][j].onclick+\"(\\\"\"+ids[i]+\"\\\")'\";");
    gridCompleteBody.push("if(op[o][oo][j].ioc){op_=op_+\" title='\"+op[o][oo][j].title+\"' >\"+op[o][oo][j].ioc+\"</a>\";}else{op_=op_+\" title='\"+op[o][oo][j].title+\"' >\"+op[o][oo][j].title+\"</a>\";}");
    gridCompleteBody.push('}}');
    gridCompleteBody.push('} else {');
    gridCompleteBody.push('var rd = jQuery("#'+option.id+'").getRowData(ids[i]);');
    gridCompleteBody.push("op_=op_+\"<a href='javascript:void(0);' class='grid-nav-bot  \"+op[o][oo][j].className+\"' onclick='\"+op[o][oo][j].onclick+\"(\\\"\"+ids[i]+\"\\\")'\";");
    gridCompleteBody.push("if(op[o][oo][j].ioc){op_=op_+\" title='\"+op[o][oo][j].title+\"' >\"+op[o][oo][j].ioc+\"</a>\";}else{op_=op_+\" title='\"+op[o][oo][j].title+\"' >\"+op[o][oo][j].title+\"</a>\";}");
    gridCompleteBody.push('}');
    gridCompleteBody.push('var act = {};');
    gridCompleteBody.push('act[oo] = op_;');
    gridCompleteBody.push('}');
    gridCompleteBody.push(' jQuery("#'+option.id+'").jqGrid("setRowData", ids[i], act);');
    gridCompleteBody.push('}}}}');
    gridCompleteBody.push('jQuery("#'+option.id+'").jqGrid("navGrid", "#'+option.id+'Pager", {edit : false,add : false,del:false,search:false,refresh:true});');
    return gridCompleteBody.join("").toString("");
}
function gridDiv(option) {
    var gridDivBody=[];
    gridDivBody.push('<div id="div_'+option.id+'" style="border-left:1px solid #d7d7d7;border-right:1px solid #d7d7d7"><table id="'+option.id+'"></table><div id="'+option.id+'Pager"></div></div>');
    return gridDivBody.join("").toString("");
}
function gridAct(option) {
    var gridActBody=[];
    for(var i in option.opmols) {
       var  onclick=option.opmols[i]["onclick"];
       var  title=option.opmols[i]["title"];
       var  event=option.opmols[i]["event"];
        var  className=option.opmols[i]["className"];
       var opmol="{onclick:'"+onclick+"',title:'"+title+"',className:'"+ className +"'";
       if(event!=undefined){
           opmol+=",event:"+event;
       }
        opmol+="}";
        gridActBody.push(opmol);
    }
    return 'var opmol'+option.id+'=[{act:['+gridActBody.join(",").toString("")+']}];';
}
function gridMultiAct(option) {
    var act={};
    var gridActBody="";
    for(var key in option.opmols) {
        var acts=option.opmols[key]
        var gridAct=[];
        for(var i in acts) {
            var  onclick=acts[i]["onclick"];
            var  title=acts[i]["title"];
            var  event=acts[i]["event"];
            var  className=acts[i]["className"];
            var opmol="{\"onclick\":\""+onclick+"\",\"title\":\""+title+"\",\"className\":\""+ className +"\"";
            if(event!=undefined){
                opmol+=",\"event\":"+event;
            }
            opmol+="}";
            gridAct.push(opmol);
        }
        gridActBody+='{'+key+':['+gridAct.join(",").toString("")+']},';
    }
    return 'var opmol'+option.id+'=['+gridActBody+'];';
}
function gridPagerInfo(retdata) {
    var pagerinfo={};
    if(retdata.length>0){
       pagerinfo.records=1;
        pagerinfo.total=1;
        pagerinfo.page=1;
        pagerinfo.rows=retdata;
    }else{
        pagerinfo={"total":"1","page":"1","records":"1","rows":[]};
    }
    return JSON.stringify(pagerinfo);
}