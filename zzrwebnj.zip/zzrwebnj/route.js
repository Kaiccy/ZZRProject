/**
 * Created by dyl on 2018-11-22.
 */
module.exports = function(app) {
    //首页菜单配置
    app.use('/admin/webmenu', require('./routes/admin/webmenu'));
    //合作伙伴
    app.use('/admin/cooperative', require('./routes/admin/cooperative'));
    //首页logo配置
    app.use('/admin/logoconfig', require('./routes/admin/logoconfig'));
    //经典案例
    app.use('/admin/cases', require('./routes/admin/cases'));
    //文章管理
    app.use('/admin/news', require('./routes/admin/news'));
    //解决方案
    app.use('/admin/solution', require('./routes/admin/solution'));
    //seo优化信息
    app.use('/admin/seoinfo', require('./routes/admin/seoinfo'));
    //产品中心
    app.use('/admin/goods', require('./routes/admin/goods'));
    //广告轮播
    app.use('/admin/ad', require('./routes/admin/ad'));
    //人才招聘
    app.use('/admin/zpxx', require('./routes/admin/zpxx'));
    //关于我们
    app.use('/admin/about', require('./routes/admin/about'));
    //留言板
    app.use('/admin/contactus', require('./routes/admin/contactus'));


    //系统管理--管理员角色设置
    app.use('/admin/role', require('./routes/admin/role'));
    //系统管理--系统人员管理
    app.use('/admin/sysuser', require('./routes/admin/sysuser'));
    //系统管理--组织机构管理
    app.use('/admin/department', require('./routes/admin/department'));
    app.use('/admin/role', require('./routes/admin/role'));



    app.use('/admin', require('./routes/admin/index'));
};