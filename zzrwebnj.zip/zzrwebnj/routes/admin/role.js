/**
 * Created by Administrator on 2018/11/27 0027.
 */
var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid');

/*管理员角色设置 ---首页*/
router.get('/browseRole.action', function (req, res) {
    var colModels = [
        {label: '主键id', name: 'id', hidden: true},
        {label: '角色名称', name: 'rolename', width: 90},
        {label: '数据域', name: 'dataarea', width: 90},
        {label: '操作', name: 'act'}];

    var opmols = [{onclick: "edit", title: "编辑"},
        {onclick: "delate", title: '注销'}];
    var option = {
        id: 'sysuser',
        url: '/admin/role/listSysRole',
        colModels: colModels,
        opmols: opmols,
        multiselect: false
    };
    var retjqgrid = jqgrid.yzJqGrid(option);
    res.render('admin/sysRole/browseRole', {jqgrid: retjqgrid}) //跳转页面
})
router.post('/listSysRole', function (req, res) {
    var callback=function(err,result) {
        res.send(jqgrid.gridPagerInfo(result));
    }
    dbCommon.query("select * from sysrole",callback);
})

/*新增管理员角色*/
router.get('/addRole',function (req,res) {
    var callback=function(err,result) {
        res.render('admin/sysRole/addRole',{rolist:result});
    }
    dbCommon.query("select * from sysrole",callback);
})

/*编辑管理员角色信息*/
router.post('/editRole',function (req,res) {
    var userid = req.body.id;
    var callback=function(err,result) {
        console.log(result);
        res.render('admin/sysRole/editRole')
    }
    dbCommon.query("select * from sysrole where id="+ userid +"",callback);
})
module.exports = router;