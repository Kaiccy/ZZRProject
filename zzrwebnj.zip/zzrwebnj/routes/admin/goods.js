var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid')
/* GET users listing. */
router.get('/browseGoods.action', function (req, res) {
    var colModels = [
        {label: '主键id', name: 'goods_id', hidden: true},
        {label: '产品名', name: 'goods_name' },
        {label: '产品编号', name: 'goods_sn'},
        {label: '产品分类', name: 'cat_name' },
        {label: '点击量', name: 'click_count' },
        {label: '上架状态', name: 'is_on_sale'},
        {label: '显示顺序', name: 'sort_order'},
        {label: '操作', name: 'act'}];

    var opmols = [{onclick: "xg", title: "编辑"},
        {onclick: "del", title: '删除'},
        {onclick: "sj", title: '产品上架',event:"function(rowdata){if(rowdata['is_on_sale']==2){return true;}else{return false;}}"},
        {onclick: "xj", title: '产品下架',event:"function(rowdata){if(rowdata['is_on_sale']==1){ return true;}else{return false;}}"}
    ];
    var option = {
        id: 'goodslist',
        url: '/admin/goods/listGoods',
        colModels: colModels,
        opmols: opmols,
        multiselect: false
    };
    var retjqgrid = jqgrid.yzJqGrid(option);
    res.render('admin/goods/browseGoods', {jqgrid: retjqgrid}) //跳转页面
})
//加载商品列表
router.post('/listGoods', function (req, res) {
    var callback=function(err,result) {
        res.send(jqgrid.gridPagerInfo(result));
    }
    var params=req.body;
    var where=''
    if(params.goods_name!=null && params.goods_sn!=null && params.cat_id!=null) {
        var goods_name = params.goods_name == '' ? '' : where += " and g.goods_name like '%" + params.goods_name + "%'";
        var goods_sn = params.goods_sn == '' ? '' : where += " and g.goods_sn='" + params.goods_sn + "'";
        var cat_id = params.cat_id == '' ? '' : where += " and g.cat_id=" + params.cat_id;
    }
    console.log("where==="+where);
    dbCommon.query("select g.*,c.cat_name cat_name from zzr_goods g,zzr_goodscategory c where g.cat_id=c.cat_id"+where,callback);
})
//获取下拉选项信息
router.post('/getCategory',function(req,res){
    var callback=function(err,result){
      res.send(result);
    }
    dbCommon.query("select cat_id,cat_name,pid,sort_order from zzr_goodscategory",callback);
})
//跳转商品信息新增页
router.get('/addGoods',function(req,res){
    res.render("admin/goods/addGoods");
})

//跳转商品修改页
router.get('/editGoods',function(req,res){
    var param=req.query;
    var callback=function(err,result){
        res.render('admin/goods/editGoods',{goods:result});
    }
    dbCommon.query("select * from zzr_goods where goods_id="+param.id,callback);
})

//删除商品信息
router.post('/delGoods',function(req,res){
    var param=req.body;
    var callback=function(err,result){
      if(result.affectedRows>0){
          res.send({status:0,info:'删除成功'});
      }else{
          res.send({status:-1,info:'删除失败['+param.id+']'});
      }
    }
    dbCommon.query("delete from zzr_goods where goods_id="+param.id,callback);
})
//商品上下架
router.post('/onSaleGoods',function(req,res){
    var param=req.body;
    var callback=function(err,result){
        if(result.affectedRows>0){
            res.send({status:0,info:'操作成功'});
        }else{
            res.send({status:-1,info:'操作失败失败['+param.id+']'});
        }
    }
    dbCommon.query("update zzr_goods set is_on_sale="+param.is_on_sale+" where goods_id="+param.id,callback);
})


module.exports = router;
