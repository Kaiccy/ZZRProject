var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
/* GET users listing. */
router.get('/', function(req, res, next) {
    res.render('admin/index');
});
router.get('/login', function(req, res, next) {
    res.render('admin/login');
});
/*验证码*/
router.get('/yzcode', function (req, res) {
    const captcha = svgCaptcha.create({ fontSize: 40, width: 100, height: 40 });
    res.setHeader('Content-Type', 'image/svg+xml');
    req.session.yzcode=captcha.text;
    res.write(captcha.data);
    res.end();
})
router.post('/dologin', function(req, res, next) {
    if(req.body.loginname==null||req.body.loginname==''){
        res.send({"status":1,info:'登录名不能为空'});
        return;
    }
    if(req.body.loginpwd==null||req.body.loginpwd==''){
        res.send({"status":1,info:'密码不能为空'});
        return;
    }
    if(req.body.rand==null||req.body.rand==''){
        res.send({"status":1,info:'验证码不能为空'});
        return;
    }
    if((req.body.rand).toUpperCase()!=(req.session.yzcode).toUpperCase()){
        res.send({"status":1,info:'验证码出错'});
        return;
    }
    var callback=function (err,result) {
        if(result.length<=0){
            res.send({"status":1,info:'用户不存在'});
            return;
        }else{
           var sysuser=result[0];
            var md5=require('md5-node');
            if(sysuser.loginpwd!=md5(req.body.loginpwd)){
                res.send({"status":1,info:'密码不正确'});
                return;
            }else{
                req.session.adminuser=sysuser;
                res.send({"status":0,info:'登录成功'});
                return;
            }

        }
    }
    dbCommon.query("select * from sysuser where loginname=?",[req.body.loginname],callback);
});
/*登出页面*/
router.get('/logout', function (req, res) {
    req.session.destroy(function(err) {
        if(err){
            res.redirect('/');
            return;
        }
        res.render('login')
    });

})
router.get('/getmenu', function (req, res) {
    const authrole = require('../../yz_modules/authrole');
    var getChildrenNodes=function(parentnode, sysmenus,privilegemap){
        var childrenNodes=[];
        if(Object.keys(parentnode).length === 0){
            for(var i in sysmenus) {
                var mt = sysmenus[i];
                if(mt.menuparent==99999999){
                    var childrenNodes_c=getChildrenNodes(mt, sysmenus, privilegemap);
                    childrenNodes.push(mt);
                }
            }
           return childrenNodes;
        }else{
            for(var i in sysmenus) {
                var mt = sysmenus[i];
                if(mt.menuparent==parentnode.id){
                    if (typeof(parentnode.ChildNodes)=='undefined'){
                        parentnode.ChildNodes=[];
                    }
                    parentnode.ChildNodes.push(mt);
                    getChildrenNodes(mt, sysmenus, privilegemap);
                }
            }
        }
    }
    var callback=function(err,result) {
        var rootnode={};
        var rettree=getChildrenNodes(rootnode,result,'');
        res.send(rettree);
        return;
    }
    dbCommon.query("select * from sysmenu where valid=1 and functiontype!=4",callback);
})
module.exports = router;
