var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid')
/* GET users listing. */
router.get('/browseSysuser.action', function (req, res) {
    var colModels = [
        {label: '主键id', name: 'id', hidden: true},
        {label: '登录名', name: 'loginname', width: 90},
        {label: '所属角色', name: 'privilege', width: 90},
        {label: '所属组织机构', name: 'depid', width: 90},
        {label: '状态', name: 'isclose', width: 150},
        {label: '操作', name: 'act'}];

    var opmols = [{onclick: "xg", title: "编辑"},
        {onclick: "logoff", title: '注销'}];
    var option = {
        id: 'sysuser',
        url: '/admin/sysuser/listSysuser',
        colModels: colModels,
        opmols: opmols,
        multiselect: false
    };
    var retjqgrid = jqgrid.yzJqGrid(option);
    res.render('admin/sysuser/browseSysuser', {jqgrid: retjqgrid}) //跳转页面
})
router.post('/listSysuser', function (req, res) {
    var callback=function(err,result) {
        res.send(jqgrid.gridPagerInfo(result));
    }
    dbCommon.query("select s.*,d.depname,r.rolename from sysuser s left join sysrole r on s.privilege=r.id left join department d on s.depid=d.id",callback);
})
/*新增管理员信息*/
router.get('/addSysuser',function (req,res) {
    res.render('admin/sysuser/addSysuser')
})
/*编辑管理员信息*/
router.get('/editSysuser',function (req,res) {
    var userid = req.query.id;
    var callback=function(err,result) {
        console.log(result);
        var callback1=function(err1,result1) {
            console.log(result1);
            res.render('admin/sysuser/editSysuser',{userInfo:result,role:result1})
        }
        dbCommon.query("select * from sysrole",callback1);
    }

    dbCommon.query("select s.*,d.depname,r.rolename from sysuser s\n" +
        "left join sysrole r on s.privilege=r.id\n" +
        "left join department d on s.depid=d.id where s.id="+ userid +"",callback);
})


module.exports = router;
