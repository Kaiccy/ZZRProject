/**
 * Created by Administrator on 2018/11/27 0027.
 */
var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid');

module.exports = router;