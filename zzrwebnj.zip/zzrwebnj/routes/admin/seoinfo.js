var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
/* GET users listing. */
router.get('/browseSeoinfo.action', function (req, res) {
        var callback=function(err,result) {
            res.render('admin/seoinfo/browseSeoinfo',{seoinfo:result}) //跳转页面
        }
    dbCommon.query("select keywords,description from zzr_seoinfo",callback);
})
//跳转编辑页
router.get('/editSeoinfo',function(req,res){
    var param=req.query;
    res.render('admin/seoinfo/editSeoinfo',{seoinfo:param});
})
//修改seo信息
router.post('/updateSeoinfo',function(req,res){
    var param=req.body;
    var callback=function(err,result){
        if(result.affectedRows>0){
            res.send({status:0,info:'信息修改成功'});
        }else{
            res.send({status:-1,info:'信息修改错误'});
        }
    }
    dbCommon.query("update zzr_seoinfo set keywords='"+param.keywords+"',description='"+param.description+"'",callback);

})
module.exports = router;
