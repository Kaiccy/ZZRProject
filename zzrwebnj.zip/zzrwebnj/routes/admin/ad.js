var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid')
/* GET users listing. */
router.get('/browseAd.action', function (req, res) {
    var colModels = [
        {label: '主键id', name: 'ad_id', hidden: true},
        {label: '轮播名称', name: 'ad_name' },
        {label: '轮播链接', name: 'ad_link'},
        {label: '点击数', name: 'click_count' },
        {label: '广告类型', name: 'ad_type' },
        {label: '是否关闭', name: 'enabled'},
        {label: '轮播排序', name: 'oder'},
        {label: '轮播图片', name: 'ad_code'},
        {label: '操作', name: 'act'}];

    var opmols = [{onclick: "xg", title: "编辑"},
        {onclick: "del", title: '删除'}];
    var option = {
        id: 'adlist',
        url: '/admin/ad/listAd',
        colModels: colModels,
        opmols: opmols,
        multiselect: false
    };
    var retjqgrid = jqgrid.yzJqGrid(option);
    res.render('admin/ad/browseAd', {jqgrid: retjqgrid}) //跳转页面
})
//加载广告信息列表
router.post('/listAd', function (req, res) {
    var callback=function(err,result) {
        res.send(jqgrid.gridPagerInfo(result));
    }
    var params=req.body;
    var where=''
    if(params.ad_name!=null ) {
         params.ad_name == '' ? '' : where += " and ad_name like '%" + params.ad_name + "%'";
    }
    console.log("where==="+where);
    dbCommon.query("select ad_id,ad_name,ad_link,click_count,ad_type,enabled,oder,ad_code from zzr_ad where 1=1 "+where,callback);
})
//跳转广告信息新增页
router.get('/addAd',function(req,res){
    res.render("admin/ad/addAd");
})

//跳转广告信息修改页
router.get('/editAd',function(req,res){
    var param=req.query;
    var callback=function(err,result){
        res.render('admin/ad/editAd',{ad:result});
    }
    dbCommon.query("select * from zzr_ad where ad_id="+param.id,callback);
})
//删除商品信息
router.post('/delAd',function(req,res){
    var param=req.body;
    var callback=function(err,result){
        if(result.affectedRows>0){
            res.send({status:0,info:'删除成功'});
        }else{
            res.send({status:-1,info:'删除失败['+param.id+']'});
        }
    }
    dbCommon.query("delete from zzr_ad where ad_id="+param.id,callback);
})

module.exports = router;
