var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid')
/* GET users listing. */
router.get('/browseContactus.action', function (req, res) {
    var colModels = [
        {label: '主键id', name: 'id', hidden: true},
        {label: '留言内容', name: 'content', width: 150},
        {label: '姓名', name: 'name', width: 80},
        {label: '邮箱', name: 'email', width: 90},
        {label: '联系方式', name: 'phone', width: 90},
        {label: '留言时间', name: 'ctime', width: 90},
        {label: '回复内容', name: 'reply', width: 90},
        {label: '回复时间', name: 'rtime', width: 130},
        {label: '操作', name: 'act'}];

    var opmols = [{onclick: "hf", title: "回复",event:function(rowdata){
        if(rowdata['rtime']!=null && rowdata['rtime']!=''){
        return false;
    }else{
        return true;
    }
}},
        {onclick: "del", title: '删除回复',event:function(rowdata){
            if(rowdata['rtime']!=null && rowdata['rtime']!=''){
        return true;
    }else{
        return false;
    }
}}];
    var option = {
        id: 'contactus',
        url: '/admin/contactus/listContactus',
        colModels: colModels,
        opmols: opmols,
        multiselect: false
    };
    var retjqgrid = jqgrid.yzJqGrid(option);
    res.render('admin/contactus/browseContactus', {jqgrid: retjqgrid}) //跳转页面
})
router.post('/listContactus', function (req, res) {
    var model = req.body;
    var callback=function(err,result) {
        res.send(jqgrid.gridPagerInfo(result));
    }
    if(model.keywords == null){
        dbCommon.query("select id,DATE_FORMAT(ctime,'%Y-%m-%d %T') ctime,name,email,phone,content,reply,DATE_FORMAT(rtime,'%Y-%m-%d %T') rtime from zzr_contactus",callback);
    }else{
        dbCommon.query("select id,DATE_FORMAT(ctime,'%Y-%m-%d %T') ctime,name,email,phone,content,reply,DATE_FORMAT(rtime,'%Y-%m-%d %T') rtime from zzr_contactus where name like '%"+model.keywords+"%' or content like '%"+model.keywords+"%'",callback);
    }
    })

router.get('/editContactus',function (req,res) {
    var model = req.query; //获取前台传递的数据
    var callback=function(err,result) {
        res.render('admin/contactus/editContactus',{contactus:result})//跳转页面
    }

    dbCommon.query("select id,name,email,phone,content,reply,rtime,DATE_FORMAT(ctime,'%Y-%m-%d %T') ctime from zzr_contactus where id="+model.id,callback);
})

router.get('/updateContactus',function (req,res) {
    //获取当前时间
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;//月份是从0开始的
    var day = date.getDate();
    var hh = date.getHours();
    var mm = date.getMinutes();
    var ss = date.getSeconds();
    var model = req.query; //获取前台传递的数据
    model.rtime = date.toLocaleString();
    var callback=function(err,result) {
        if(result.affectedRows>0){
            res.send({status:0,info:'回复成功！'});
        }else{
            res.send({status:-1,info:'回复失败！'});
        }

    }

    dbCommon.query("update zzr_contactus set ctime='"+model.ctime+"',name='"+model.name+"',email='"+model.email+"',phone='"+model.phone+"',content='"+model.content+"',reply='"+model.reply+"',rtime='"+model.rtime+"' where id='"+model.id+"';",callback);
})

router.post('/delReply',function (req,res) {
    var model = req.body; //获取前台传递的数据
    console.log(model);
    var callback=function(err,result) {
        if(result.affectedRows>0){
            res.send({status:0,info:'删除回复成功！'});
        }else{
            res.send({status:-1,info:'删除回复失败！'});
        }
    }

    dbCommon.query("update zzr_contactus set reply=null,rtime=null where id='"+model.id+"';",callback);
})



module.exports = router;
