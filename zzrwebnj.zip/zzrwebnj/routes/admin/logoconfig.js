var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
/*const jqgrid = require('../../yz_modules/jqgrid')*/
/* GET users listing. */
router.get('/browseLogoConfig.action', function (req, res) {
    var callback=function(err,result) {
        res.render('admin/logoconfig/browseLogoConfig',{logo:result}) //跳转页面
    }
    dbCommon.query("select * from zzr_config where code='logo'",callback);
})
router.get('/editLogoConfig',function (req,res) {
    res.render('admin/logoconfig/editLogoConfig')
})

module.exports = router;
