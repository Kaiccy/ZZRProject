var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid')
/* GET users listing. */
router.get('/browseZpxx.action', function (req, res) {
    var colModels = [
        {label: '主键id', name: 'id', hidden: true},
        {label: '职务名称', name: 'zwmc' },
        {label: '植物类别', name: 'zwlb'},
        {label: '招聘人数', name: 'zprs' },
        {label: '学历要求', name: 'xlyq' },
        {label: '工作年限', name: 'gznx'},
        {label: '每月薪资', name: 'myxz'},
        {label: '操作', name: 'act'}];

    var opmols = [{onclick: "xg", title: "编辑"},
        {onclick: "del", title: '删除'}];
    var option = {
        id: 'zpxxlist',
        url: '/admin/zpxx/listZpxx',
        colModels: colModels,
        opmols: opmols,
        multiselect: false
    };
    var retjqgrid = jqgrid.yzJqGrid(option);
    res.render('admin/zpxx/browseZpxx', {jqgrid: retjqgrid}) //跳转页面
})
router.post('/listZpxx', function (req, res) {
    var callback=function(err,result) {
        res.send(jqgrid.gridPagerInfo(result));
    }
    var params=req.body;
    var where=''
    if(params.zwmc!=null ) {
        params.zwmc == '' ? '' : where += " and zwmc like '%" + params.zwmc + "%'";
    }
    console.log("where==="+where);
    dbCommon.query("select id,zwmc,zwlb,zprs,xlyq,gznx,myxz,rzyq,ctime from zzr_zpxx where 1=1 "+where,callback);
})
//跳转招聘信息新增页
router.get('/addZpxx',function(req,res){
    res.render("admin/zpxx/addZpxx");
})

//跳转招聘信息修改页
router.get('/editZpxx',function(req,res){
    var param=req.query;
    var callback=function(err,result){
        res.render('admin/zpxx/editZpxx',{zpxx:result});
    }
    dbCommon.query("select * from zzr_zpxx where id="+param.id,callback);
})
//删除招聘信息
router.post('/delZpxx',function(req,res){
    var param=req.body;
    var callback=function(err,result){
        if(result.affectedRows>0){
            res.send({status:0,info:'删除成功'});
        }else{
            res.send({status:-1,info:'删除失败['+param.id+']'});
        }
    }
    dbCommon.query("delete from zzr_zpxx where id="+param.id,callback);
})


module.exports = router;
