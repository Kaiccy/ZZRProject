var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid');
router.get('/browseAbout.action', function (req, res) {
    var callback=function(err,result) {
        res.render('admin/about/browseAbout',{about:result}) //跳转页面
    }
    dbCommon.query("select pic,content,progress from zzr_about ",callback);
})

router.get('/editAbout',function (req,res) {
    var callback=function(err,result) {
        res.render('admin/about/editAbout',{about:result}) //跳转页面
    }
    dbCommon.query("select pic,content,progress from zzr_about ",callback);

})
module.exports = router;
