var express = require('express');
var router = express.Router();
var dbCommon = require('../../yz_modules/DbCommon');
const jqgrid = require('../../yz_modules/jqgrid')
/* GET users listing. */
router.get('/browseWebmenu.action', function (req, res) {
    var colModels = [
        {label: '主键id', name: 'id', hidden: true},
        {label: '菜单名称', name: 'actname', width: 150},
        {label: '菜单链接', name: 'acturl', width: 150},
        {label: '父级菜单', name: 'p_name', width: 90},
        {label: '同级菜单序号', name: 'actorder', width: 90},
        {label: '是否有效', name: 'valid', width: 90},
        {label: '操作', name: 'act'}];

    var opmols = [{onclick: "xg", title: "编辑"},
        {onclick: "del", title: '删除'}];
    var option = {
        id: 'webmenu',
        url: '/admin/webmenu/listWebmenu',
        colModels: colModels,
        opmols: opmols,
        multiselect: false
    };
    var retjqgrid = jqgrid.yzJqGrid(option);
    res.render('admin/webmenu/browseWebmenu', {jqgrid: retjqgrid}) //跳转页面
})
router.post('/listWebmenu', function (req, res) {
    var callback=function(err,result) {
        res.send(jqgrid.gridPagerInfo(result));
    }
    dbCommon.query("select c1.*,c2.actname p_name from zzr_webmenu c1 left join zzr_webmenu c2 on c1.pid=c2.id where 1=1",callback);
})


module.exports = router;
