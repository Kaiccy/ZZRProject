module.exports = {
    title : "企业网站",
    template : "template-a",
    dbconfig:{
        connectionLimit: 50,
        host: '192.168.0.60',
        user: 'root',
        password: '123456',
        database: 'zzrwebnj'
    }
}