$('.zzrUi-slide').on('click','a[data-href]',function () {
    var zzrFrameAdmin = $('#zzrFrameAdmin');
    var iSrc = $(this).attr('data-href');
    zzrFrameAdmin.attr('src',iSrc)
});
$('.zzrAdmin-slide').on('mouseenter','.layui-nav-item>a',function () {
    var domInfo =  $(this);
    if($('.layadmin-side-shrink').length){
        layui.use('layer',function () {
            var layer = layui.layer;
            var that = this;
            layer.tips(domInfo.attr('lay-tips'),domInfo.parent('li'))
        })
    }
}).on('mouseleave',function () {
    layui.use('layer',function () {
        var layer = layui.layer;
        var that = this;
        layer.closeAll('tips')
    })
});
$('.zzrAdmin').on('click','.layui-side-menu .layui-nav-item>a',function (e) {
    if($(this).attr('data-href')==undefined){
        $('.zzrAdmin').removeClass('layadmin-side-shrink');
        $('#LAY_app_flexible').find('i').addClass('layui-icon-shrink-right').removeClass('layui-icon-spread-left')
    }
    e.stopPropagation()
});
$('#LAY_app_flexible').on('click',function(){
    var a  = document.body.clientWidth;
    if(a<=992){
        if($('.zzrAdmin').hasClass('layadmin-side-spread-sm')){
            $('.zzrAdmin').removeClass('layadmin-side-spread-sm');
            $('.zzrAdmin-shade').hide()
        }else{
            $('.zzrAdmin').addClass('layadmin-side-spread-sm');
            $('.zzrAdmin-shade').show()
        }
        if($(this).find('i').hasClass('layui-icon-shrink-right')){
            $(this).find('i').removeClass('layui-icon-shrink-right').addClass('layui-icon-spread-left')
        }else{
            $(this).find('i').addClass('layui-icon-shrink-right').removeClass('layui-icon-spread-left')
        }
    }else{
        if($(this).find('i').hasClass('layui-icon-shrink-right')){
            $(this).find('i').removeClass('layui-icon-shrink-right').addClass('layui-icon-spread-left')
            $('.zzrAdmin').addClass('layadmin-side-shrink')
        }else{
            $(this).find('i').addClass('layui-icon-shrink-right').removeClass('layui-icon-spread-left')
            $('.zzrAdmin').removeClass('layadmin-side-shrink')
        }
    }
});
$('.zzrAdmin-shade').on('click',function () {
    $('.zzrAdmin-shade').hide();
    $('.zzrAdmin').removeClass('layadmin-side-spread-sm');
    if($('#LAY_app_flexible').find('i').hasClass('layui-icon-shrink-right')){
        $('#LAY_app_flexible').find('i').removeClass('layui-icon-shrink-right').addClass('layui-icon-spread-left')
    }else{
        $('#LAY_app_flexible').find('i').addClass('layui-icon-shrink-right').removeClass('layui-icon-spread-left')
    }
});
$(window).resize(function () {
    var a  = document.body.clientWidth;
    if(a<=992){
        $('.zzrAdmin').removeClass('layadmin-side-shrink');
        $('#LAY_app_flexible').find('i').addClass('layui-icon-shrink-right').removeClass('layui-icon-spread-left')
    }
})