 function gridLayout(gridid){
	 //alert(getViewSizeWithoutScrollbar()['width']);
	 var isparent=$('.layui-layer', parent.document).length > 0;
	 var qtwidth=0;
	 jQuery("body").find("div").each(function(i){
		 if(jQuery(this).attr('class')=='maillist-left'){
			 qtwidth=qtwidth+jQuery(this).width()+10;
		 }
	 });
	/* jQuery("#"+gridid).jqGrid("setGridWidth",getViewSizeWithoutScrollbar(isparent)['width']-10-qtwidth); */
	 var qtheigth=jQuery(".zzrUi-page-head").outerHeight();//页面内部head高度
	 var qwidth=jQuery(".zzrUi-page-body").outerWidth();
	// var navH = jQuery('#navbar').outerHeight()+ jQuery('#Hui-tabNav').outerHeight();
	 var browser=getBrowserName();
//	 if(browser!='IE'&&getBrowserName()!='Others'){
//		 qtheigth+=8;
//	 }
     if(isparent){
		 //var bodyHei = $(parent.window).height()-50-34-qtheigth-42-55-8;
    	 var bodyHei =$('body').height()-$('.zzrUi-page-head').outerHeight()-30-38-65;
		 if(!jQuery("#"+gridid).getGridParam("autowidth")){
			 bodyHei=bodyHei-18;
		 }
		 jQuery("#"+gridid).jqGrid("setGridHeight",bodyHei);
	 }else{
		 var bodyHei =window.parent.$('.zzrAdmin-body').outerHeight()-$('.zzrUi-page-head').outerHeight()-110;
         jQuery("#"+gridid).jqGrid("setGridWidth",qwidth-25);
		 jQuery("#"+gridid).jqGrid("setGridHeight",bodyHei-20);
	 }
 }
 
 function getViewSizeWithoutScrollbar(isparent) {// 不包含滚动条
	if (isparent) {
		return {
			width : $(window.parent).width(),
			/*height : $(window.parent).height()*/
			
		}
	} else {
		return {
			width : $(window).width(),
			/*height : $(window).height()*/
			
		}
	}
}
	 var ua = navigator.userAgent.toLowerCase();
	 function check(r){
	   return r.test(ua);
	 }