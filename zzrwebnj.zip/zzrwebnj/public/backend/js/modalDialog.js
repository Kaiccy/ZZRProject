function modalDialogWait(id,content) {
		if(typeof(id)=="undefined"||id==null||id==''){
			id = now.getFullYear()+""+now.getMonth()+""+now.getDay()+""+now.getHours()+""+now.getMinutes()+""+now.getSeconds();
		}
		var w="";
		var h="";
		var body = $("body");
		var waitlength = $('.fixcontent').length;
		var waitmodal = $("<div class=\"waitmodal\" id=\""+id+"\">");
		var fixcontent = $("<div class=\"fixcontent\">");
		var waitimg = $("<img src=\""+basepath+"/admin/img/load.gif\" width=\"100\">");
		body.append(waitmodal);
		waitmodal.append(waitimg,fixcontent);
}

function modalDialogContent(id,title,w,h,content,fn) {
	/*if(typeof(id)=="undefined"||id==null||id==''){
		id = now.getFullYear()+""+now.getMonth()+""+now.getDay()+""+now.getHours()+""+now.getMinutes()+""+now.getSeconds();
	}
	var option_box = $('#'+id).children('alert-body');
	if(!w){
		w=250;
	}
	if(!h){
		h=150;
	}
	var body = $("body");
	var alertmodal = $("<div class=\"alertmodel\"  style=\"width:"+w+"px;height:"+h+"px\" id=\""+id+"\">");
	var fixcontent = $("<div class=\"fixcontent\">");
	var alerthead = $("<div class=\"alert-title\">"+title+"<i class=\"right icon icon-remove red alertremove\"></i></div>");
	var alertbody = $("<div class=\"alert-body\">"+content+"</div>");
	var alertfoot = $("<div class=\"alert-foot\">");
	var alertbutton_p=$("<div class=\"alert-button\">");
	var alertbutton=$("<button class=\"btn btn-primary\">确定</button>").on('click', fn);
	alertbutton_p.append(alertbutton);
	alertfoot.append(alertbutton_p);
	body.append(alertmodal);
	alertmodal.append( alerthead , alertbody , alertfoot ,fixcontent );
	$(alertmodal).height(parseInt(h-66));
	$(alertmodal).css({
		'margin-top':- (h-66/2),
		'margin-left':- (w/2)
	});
	$('.alertremove').on('click',function(){
		closeDialog(id)
	});*/
	if(!w){
		w=250;
	}
	if(!h){
		h=150;
	}
	layui.use('layer',function(){
		layer.open({
			title:title,
			content:content,
			btn: ['确定'],
			btn1: function(index, layero){
			    //do something
				var a = fn;
				a();
			    layer.close(index); //如果设定了yes回调，需进行手工关闭
			},
			//area: [w+'px', h+'px']
		})
	})
}
function modalDialogconfim(id,content,buttons) {
	if(typeof(id)=="undefined"||id==null||id==''){
	  id = now.getFullYear()+""+now.getMonth()+""+now.getDay()+""+now.getHours()+""+now.getMinutes()+""+now.getSeconds();
	}
	var option_box = $('#'+id).children('alert-body');
	var title="提示";
	w=250;
	h=150;
	var body = $("body");
	var alertmodal = $("<div class=\"alertmodel\"  style=\"width:"+w+"px;height:"+h+"px\" id=\""+id+"\">");
	var fixcontent = $("<div class=\"fixcontent\">");
	var alerthead = $("<div class=\"alert-title\">"+title+"<i class=\"right icon icon-remove red alertremove\"></i></div>");
	var alertbody = $("<div class=\"alert-body\">"+content+"</div>");
	var alertfoot = $("<div class=\"alert-foot\">");
	var alertbutton_p=$("<div class=\"alert-button\">");
	
	$(buttons).each(function(index,item){
		var alertbutton=$("<button class=\"btn btn-primary\">"+item.name+"</button>").on('click', item.fn);
		alertbutton_p.append(alertbutton);
	});
	alertfoot.append(alertbutton_p);
	body.append(alertmodal);
	alertmodal.append( alerthead , alertbody , alertfoot ,fixcontent );
	var modalHei = $('.alert-body').outerHeight();
	$(alertmodal).css({
		/*'margin-top': -(alertmodal.height()),*/
		'margin-left':- (w/2),
		'height':modalHei + 112,
		'margin-top': -(modalHei + 112)/2
	});
	$('.alertremove').on('click',function(){
		closeDialog(id)
	});
}
/**
 * 弹出框
 * @param content弹出显示内容
 * @param icon弹出框类别1成功2失败
 * @returns
 */
function modalDialogAlert(content,icon) {
	if(typeof(icon) == "undefined"){
		icon=1;
	}
	 layui.use('layer', function () {
	        var layer = layui.layer;
	        var mpdal=layer.msg(content, {
				  time: 0 //不自动关闭
				  ,btn: ['确定']
		          ,icon:icon,
		          shade: 0.3
				  ,yes: function(index){
					  layer.close(mpdal);
				  }
		});
	 });
}
/**
 * 弹出框2
 * @param content弹出显示内容
 * @param icon弹出框类别1成功2失败
 ****接受回调的提示层，点击确定按钮后执行回调,否则不执行
 * @returns
 */
function msgAlertAndClose(content,icon,yesback){
    if(typeof(icon) == "undefined"){
        icon=1;
    }
    layui.use('layer', function () {
        var layer = layui.layer;
        var mpdal=layer.msg(content, {
            time: 0 //不自动关闭
            ,btn: ['确定']
            ,icon:icon
            ,shade: 0.3
            ,yes: function(index){
                yesback();
                layer.close(mpdal);
            }
        });
    });
}

function closeDialog(id) {
	$('#'+id).remove();
}
function closeDialogm(id) {
	$('#'+id).modal('hide');
}
function refreshGrid(id) {
	jQuery("#"+id).trigger("reloadGrid");
	
}
function creatIframe(href, titleName, navNum) {
	var topWindow = $(window.parent.document);
	var show_nav = topWindow.find('#frame-tab');
	show_nav.find('li').removeClass("active");
	var iframe_box = topWindow.find('#iframe_box');
	//show_nav.append('<li class="active"><span data-href="'+href+'">'+titleName+'</span><i></i><em></em></li>');
	/*show_nav.append('<li class="active"><a href="#' + href + '" data-href="' + href + '" id="tab_'+navNum+'" data-toggle="tab"><span>' + titleName + '</span><i></i><em></em></a></li>');
	*/
	show_nav.append('<li class="active"><a href="#' + href + '"  id="tab_'+navNum+'" ><span>' + titleName + '</span><i></i><em></em></a></li>');
	var w = show_nav.width();
	var liW = show_nav.find('li.active').width();
	show_nav.css('width',w+liW);
	var nav_wrap = topWindow.find('#Hui-tabNav').width();
	var nav_more = topWindow.find('#Hui-tabNav .nav-more');
	if(w+liW >nav_wrap){
		nav_more.show();
	}else{
		nav_more.hide();
		nav_more.css('left','0');
	}
	var iframeBox = iframe_box.find('.show_iframe');
	iframeBox.hide();
	iframe_box.append('<div class="show_iframe"><div class="loading"></div><iframe frameborder="0" src=' + href + ' id="frame_'+navNum+'" class="boxiframe"></iframe></div>');
	var showBox = iframe_box.find('.show_iframe:visible');
	showBox.find('iframe').attr("src", href).load(function() {
		showBox.find('.loading').hide();
	});
}
/**
 * 
 * @param options.id 弹出框的id
 * @param options.iframeurl 加载iframe的页面
 * @param options.url 加载第三方的页面的html
 * @param options.title 弹出框的标题
 */
(function(jQuery) {     
	jQuery.fn.yzIframeDialog = function(options) { 
		if(typeof(options.id)=="undefined"||options.id==null||options.id==''){
			options.id="myModal";
		}
		var w="";
		if(options.width){
			w="style=\"width:"+options.width+"\";";
		}else{
			w="style=\"width:"+($(window).width()-100)+"px\";";
		}
		var h="";
		if(options.height){
			h="style=\"height:"+options.height+"\";";
		}else{
			h="style=\"height:"+($(window).height()-150)+"px\";";
		}
		var body=$("body");
		var modaldiv=$("<div class=\"modal fade bs-example-modal-lg\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myLargeModalLabel\" id=\""+options.id+"\">");
		var documentdiv=$("<div class=\"modal-dialog modal-lg\" role=\"document\" "+w+">");
		var contentdiv=$("<div class=\"modal-content\">");
		var headerdiv=$("<div class=\"modal-header\">");
		var headerbutton=$("<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>");
		var headertitle=$("<h4 class=\"modal-title\" id=\""+options.id+"Label\">"+options.title+"</h4>");
		headerdiv.append(headerbutton).append(headertitle);
		contentdiv.append(headerdiv);
		var bodydiv=$("<div class=\"modal-body\" "+h+">");
		var iframe;
		if(typeof(options.iframeurl)!="undefined"&&options.iframeurl!=null&&options.iframeurl!=''){
		    iframe=jQuery('<iframe id="'+options.id+'ifr" frameborder="no" width="100%"/>');
			bodydiv.append(iframe);
		}else{
			bodydiv.append(options.bodycontent);
		}
		contentdiv.append(bodydiv);
		if(typeof(options.iframeurl)=="undefined"||options.iframeurl==null||options.iframeurl==''){
		var footerdiv=$("<div class=\"modal-footer\">");
		var footerbutton=$(" <div type=\"button\" class=\"btn btn-primary\" >确定</div>").on('click', options.dosubmit);
				footerdiv.append(footerbutton);
				contentdiv.append(footerdiv);
		}
		documentdiv.append(contentdiv);
		modaldiv.append(documentdiv);
		body.append(modaldiv);
		$('#'+options.id).on('shown.bs.modal', function () {
			if(typeof(options.iframeurl)!="undefined"&&options.iframeurl!=null&&options.iframeurl!=''){
				var now=new Date();
				var tempdate = now.getFullYear()+""+now.getMonth()+""+now.getDay()+""+now.getHours()+""+now.getMinutes()+""+now.getSeconds();
				var url=options.iframeurl;
				if(url.indexOf("?")==-1){
					
					url=url+"?tempdate="+tempdate;
				}else{
					url=url+"&tempdate="+tempdate;
				}
			iframe.attr('src',url);
			}
			})
		$('#'+options.id).on('hidden.bs.modal', function (e) {
			$('#'+options.id).remove();
		});
	};   
})(jQuery);    
