(function(jQuery) {
    jQuery.fn.uploadImg =  function (options) {
        let id = options.id
        let maxNum = options.maxNum?options.maxNum:10;
        $('#'+options.id +' .uoload-bot').change(function (event) {
            let obJect = event?event:'' //传入file  目前只支持单张传输
            if(obJect!==''){
                var objLength = $('#'+options.id).parent('.layui-image-upload').find('.layui-image-ipt').length;
                if(objLength>=maxNum){
                    layui.use('layer', function(){
                        layer.msg('最多支持上传'+ maxNum +'张图片', {icon: 5});
                    })
                }else{
                    var optionCon = obJect.target.files;
                    let file;
                    if(window.FileReader) {
                        for(let i = 0;i<optionCon.length;i++){
                            var newObj = document.querySelector('#'+id).querySelector('.uoload-bot').cloneNode(true);
                            var fr = new FileReader();
                            file = optionCon[i];
                            fr.readAsDataURL(file);
                            fr.onloadend = function(e) {
                                event.target.value = '';
                                var imgBox = document.createElement('div')
                                imgBox.setAttribute('class','layui-image layui-image-ipt')
                                var Html = '<img class="imgSc" src="'+ e.target.result +'" alt=""><i title="删除" class="layui-icon layui-icon-close remove-image"></i>'
                                imgBox.innerHTML = Html;
                                imgBox.append(newObj)
                                $('#'+id).before(imgBox);
                            };
                        }
                    }
                }
            }
        });
        $(document).on('click','.layui-image-ipt i.remove-image',function (e) {
            e.stopPropagation()
            var parentDom = $(this).parent()
            layer.msg('确定删除此图片？',{
                time: 0 //不自动关闭
                ,btn: ['确认', '取消']
                ,yes: function(index){
                    layer.close(index);
                    parentDom.remove()
                }
            });
        })
    }
})(jQuery);