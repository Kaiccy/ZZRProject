//
//  DeviceListView.m
//  IDCardBluetooth
//
//  Created by YZBookPro on 2018/6/29.
//  Copyright © 2018年 YZBookPro. All rights reserved.
//

#import "DeviceListView.h"
#import "Masonry.h"
#import "MyPeripheral.h"

@interface DeviceListView ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) UIButton *closeBtn;

@end

@implementation DeviceListView

- (instancetype)init{
    self = [super init];
    if (self) {
        
        self.backgroundColor = kWXColor(0, 0, 0, 0.3);
        
        //tableView
        self.tableView  = [[UITableView alloc] init];
        [self addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([UITableViewCell class])];
        _tableView.showsVerticalScrollIndicator = NO;
//        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.bottom.mas_equalTo(-100);
            make.left.mas_equalTo(50);
            make.right.mas_equalTo(-50);
        }];
        
        //关闭按钮
        self.closeBtn = [[UIButton alloc] init];
        [self addSubview:_closeBtn];
        [_closeBtn setImage:[UIImage imageNamed:@"close"] forState:(UIControlStateNormal)];
        [_closeBtn addTarget:self action:@selector(closeView) forControlEvents:(UIControlEventTouchUpInside)];
        [_closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self->_tableView.mas_top).mas_equalTo(-30);
            make.left.equalTo(self->_tableView.mas_right).mas_equalTo(0);
            make.width.height.mas_equalTo(30);
        }];
        
        //手势
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeView)];
//        [self addGestureRecognizer:tap];
    }
    return self;
}

#pragma UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _deviceArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([UITableViewCell class]) forIndexPath:indexPath];
    
    MyPeripheral *myper = _deviceArr[indexPath.row];
    if ([myper.Peripheral.name isEqual:@"CVR-100B"]) {
        cell.textLabel.text =[NSString stringWithFormat:@"名称：%@  RSSI: %d dBm",myper.Peripheral.name,[myper.RSSI intValue]];
    }
    
    cell.detailTextLabel.text = myper.Peripheral.identifier.UUIDString;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 35;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.delegate connectDevice:indexPath.row];
    self.hidden = YES;
}

#pragma actions
- (void)closeView{
    self.hidden = YES;
}

#pragma setter
- (void)setDeviceArr:(NSArray *)deviceArr{
    _deviceArr = deviceArr;
    [self.tableView reloadData];
}

@end











