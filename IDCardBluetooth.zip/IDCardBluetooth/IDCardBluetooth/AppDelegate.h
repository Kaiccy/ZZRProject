//
//  AppDelegate.h
//  IDCardBluetooth
//
//  Created by YZBookPro on 2018/6/29.
//  Copyright © 2018年 YZBookPro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

