//
//  ShowTool.h
//  ZhongBao
//
//  Created by YZBookPro on 2018/3/2.
//  Copyright © 2018年 YZBookPro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShowTool : NSObject

//参数排序，加密
+ (NSDictionary *)params:(NSDictionary *)params;

//提示弹框
+ (void)showHud:(NSString *)text view:(UIView *)view;

//设置返回
+ (void)setNavigationBarWithTitle:(NSString *)title controller:(UIViewController *)controller;

//切圆角
+ (void)setViewAllCorner:(UIView *)view cornerSize:(CGFloat)cornerSize;

//切圆角加边框
+ (void)setViewAllCorner:(UIView *)view cornerSize:(CGFloat)cornerSize borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor;

/**
 *  压缩图片到指定文件大小
 *
 *  @param image 目标图片
 *  @param size  目标大小（最大值）
 *
 *  @return 返回的图片文件
 */
+ (NSData *)zh_compressOriginalImage:(UIImage *)image toMaxDataSizeKBytes:(CGFloat)size;
//图片base64编码后的处理，// 由于字符串中会有“+”，“+”上传到服务器会变空格，此处用了支付宝支付时带的编码方法
+ (NSString *)encode:(NSString *)str;

@end
