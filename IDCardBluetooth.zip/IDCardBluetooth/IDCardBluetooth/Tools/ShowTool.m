//
//  ShowTool.m
//  ZhongBao
//
//  Created by YZBookPro on 2018/3/2.
//  Copyright © 2018年 YZBookPro. All rights reserved.
//

#import "ShowTool.h"

@implementation ShowTool

//参数排序，加密
+ (NSDictionary *)params:(NSDictionary *)params{
    
    NSArray *keyArr = [params allKeys];
    
    //排序
    NSStringCompareOptions comparisonOptions = NSCaseInsensitiveSearch|NSNumericSearch|NSWidthInsensitiveSearch|NSForcedOrderingSearch;
    NSComparator sort = ^(NSString *obj1,NSString *obj2){
        NSRange range = NSMakeRange(0,obj1.length);
        return [obj1 compare:obj2 options:comparisonOptions range:range];
    };
    NSArray *resultArray = [keyArr sortedArrayUsingComparator:sort];
    
    //拼接加密
    NSString *md5Str = @"";
    for (NSString *key in resultArray) {
        md5Str = [NSString stringWithFormat:@"%@%@",md5Str,params[key]];
    }
    md5Str = [NSString stringWithFormat:@"%@%@",md5Str,kRandomStr];
    CocoaSecurityResult *md5 = [CocoaSecurity md5:md5Str];
    
    //添加加密字段
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:params];
    [dic setValue:md5.hex forKey:@"sign"];
    
    return dic;
}

+(void)showHud:(NSString *)text view:(UIView *)view{
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.mode = MBProgressHUDModeText;
    
    hud.label.text = text;
    [hud showAnimated:YES];
    [hud hideAnimated:YES afterDelay:1];
    hud.removeFromSuperViewOnHide = YES;
}

//设置返回
+ (void)setNavigationBarWithTitle:(NSString *)title controller:(UIViewController *)controller{
    controller.title = title;
    [controller.navigationController.navigationBar setTitleTextAttributes:@{ NSForegroundColorAttributeName:kMainTextColor,NSFontAttributeName:[UIFont fontWithName:@"PingFangSC-Light" size:18]}];
    
    //返回按钮
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [btn setImage:[UIImage imageNamed:@"back"] forState:(UIControlStateNormal)];
    [btn setTitleColor:kMainTextColor forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:13];
    [btn addTarget:self action:@selector(back:) forControlEvents:(UIControlEventTouchUpInside)];
    controller.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    
    //添加侧滑返回
    UISwipeGestureRecognizer *ges = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(slideBack:)];
    [controller.view addGestureRecognizer:ges];
}

+ (void)back:(UIButton *)sender{
    UINavigationController *vc = [[UINavigationController alloc] init];
    for (UIView* next = [sender superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UINavigationController class]]) {
            vc = (UINavigationController*)nextResponder;
            [vc.topViewController.navigationController popViewControllerAnimated:YES];
            return;
        }
    }
}

+ (void)slideBack:(UIGestureRecognizer *)recognizer{
    //    recognizer.view.
    UINavigationController *vc = [[UINavigationController alloc] init];
    for (UIView* next = [recognizer.view superview]; next; next = next.superview) {
        UIResponder *nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UINavigationController class]]) {
            vc = (UINavigationController*)nextResponder;
            [vc.topViewController.navigationController popViewControllerAnimated:YES];
            //            [vc.view.window endEditing:YES];
            return;
        }
    }
}

//切圆角
+ (void)setViewAllCorner:(UIView *)view cornerSize:(CGFloat)cornerSize{
    view.layer.masksToBounds = YES;
    view.layer.cornerRadius = cornerSize;
}

//切圆角加边框
+ (void)setViewAllCorner:(UIView *)view cornerSize:(CGFloat)cornerSize borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor{
    view.layer.masksToBounds = YES;
    view.layer.cornerRadius = cornerSize;
    view.layer.borderWidth = borderWidth;
    view.layer.borderColor = borderColor.CGColor;
}

//图片处理
+ (NSData *)zh_compressOriginalImage:(UIImage *)image toMaxDataSizeKBytes:(CGFloat)size
{
    NSData *data = UIImageJPEGRepresentation(image, 1.f);
    
    CGFloat dataKBytes = data.length / 1000.f;
    
    CGFloat maxQuality = .9f;
    
    CGFloat lastData = dataKBytes;
    
    while (dataKBytes > size && maxQuality > .01f)
    {
        maxQuality -= .01f;
        
        data = UIImageJPEGRepresentation(image, maxQuality);
        
        dataKBytes = data.length / 1000.f;
        
        NSLog(@"当前图片大小：%fKB", dataKBytes);
        
        if (lastData == dataKBytes)
        {
            break;
        }
        else
        {
            lastData = dataKBytes;
        }
    }
    return data;
}

+ (NSString *)encode:(NSString *)str
{
    return (__bridge_transfer  NSString*)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (__bridge CFStringRef)str, NULL, (__bridge CFStringRef)@"!*'();:@&=+$,/?%#[]", kCFStringEncodingUTF8 );
}


@end
