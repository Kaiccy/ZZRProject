//
//  HBCardInfo.h
//  CardReader
//
//  Created by xiangby on 14-5-17.
//  Copyright (c) 2014年 Chinaidcard. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
/** 身份证信息
 *
 *
 */
@interface certificate : NSObject

/**
 * @brief 姓名
 *
 *
 */
@property(nonatomic, copy) NSString *partyName;

/**
 * @brief 性别代号
 *
 *
 */
@property(nonatomic, assign) NSInteger gender;

/**
 *  性别
 */
@property(nonatomic,copy)NSString* Sex;


/**
 * @brief 民族
 *
 *
 */
@property(nonatomic, copy) NSString *nation;

/**
 * @brief 生日
 *
 *
 */
@property(nonatomic, copy) NSString *bornDay;

/**
 * @brief 住址
 *
 *
 */
@property(nonatomic, copy) NSString *certAddress;

/**
 * @brief 身份证号
 *
 *
 */
@property(nonatomic, copy) NSString *cardNumber;

/**
 * @brief 签证机关
 *
 *
 */
@property(nonatomic, copy) NSString *certOrg;

/**
 * @brief 有效地址，开始
 *
 *
 */
@property(nonatomic, copy) NSString *effDate;

/**
 * @brief 有效地址，到期
 *
 *
 */
@property(nonatomic, copy) NSString *expDate;

/**
 * @brief 头像
 *
 *
 */
@property(nonatomic, strong) UIImage *avatarImage;

/**
 *  显示信息
 *
 *  @return 身份证信息
 */
- (NSString *)certificate;
@end
