//
//  UnPack.h
//  UnPack
//
//  Created by xiangby on 14/12/14.
//  Copyright (c) 2014年 HB. All rights reserved.
//

#ifdef __cplusplus
extern "C" {
#endif
    
int Unpack(char Infile[], char Outfile[]);

#ifdef __cplusplus
}
#endif
