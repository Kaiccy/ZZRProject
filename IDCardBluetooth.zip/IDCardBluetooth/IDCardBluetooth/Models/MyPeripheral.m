//
//  MyPeripheral.m
//  F562Demo
//
//  Created by Andreliu on 16/3/11.
//  Copyright © 2016年 Chinaidcard. All rights reserved.
//


#import "MyPeripheral.h"

@implementation MyPeripheral

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.Peripheral=[CBPeripheral alloc];
        self.RSSI=0;
        self.advertisementData=[[NSDictionary alloc] init];
    }
    return self;
}

@end


