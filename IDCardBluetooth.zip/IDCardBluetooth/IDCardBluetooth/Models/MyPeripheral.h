//
//  MyPeripheral.h
//  F562Demo
//
//  Created by Andreliu on 16/3/11.
//  Copyright © 2016年 Chinaidcard. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface MyPeripheral : NSObject

@property(nullable, nonatomic,copy) CBPeripheral* Peripheral;
@property(nullable, nonatomic,copy) NSNumber *RSSI;
@property(nullable, nonatomic,copy) NSDictionary * advertisementData;

@end
