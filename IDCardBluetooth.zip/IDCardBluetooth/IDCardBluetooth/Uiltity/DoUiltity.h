//
//  DoUiltity.h
//  BLETool
//
//  Created by Andrewliu on 15/6/29.
//  Copyright (c) 2015年 YunTu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCrypto.h>
#import "GTMBase64.h"

@interface DoUiltity : NSObject
+(NSData *)EncMode:(NSData *)bufferdata key:(NSData *)key;
+(NSData *)DecMode:(NSData *)bufferdata key:(NSData *)key;

+ (NSData *)TripleDES:(NSString*)plainText encryptOrDecrypt:(CCOperation)encryptOrDecrypt key:(NSString*)key;

@end
