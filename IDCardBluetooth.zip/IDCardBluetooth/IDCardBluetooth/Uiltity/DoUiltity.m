//
//  DoUiltity.m
//  BLETool
//
//  Created by Andrewliu on 15/6/29.
//  Copyright (c) 2015年 YunTu. All rights reserved.
//

#import "DoUiltity.h"
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonDigest.h>
#import <Security/Security.h>


@implementation DoUiltity
+(NSData *)EncMode:(NSData *)bufferdata key:(NSData *)key
{
    CCOperation encryptOrDecrypt=kCCEncrypt;
    const void *vplainText;
    size_t plainTextBufferSize;
    plainTextBufferSize = [bufferdata length];
    
    
    CCCryptorStatus ccStatus;
    uint8_t *bufferPtr = NULL;
    size_t bufferPtrSize = 0;
    size_t movedBytes = 0;
    
    bufferPtrSize = (plainTextBufferSize + kCCBlockSize3DES) & ~(kCCBlockSize3DES - 1) ;
    bufferPtr = malloc( bufferPtrSize * sizeof(uint8_t));
    memset((void *)bufferPtr, 0x00, bufferPtrSize);
    
    vplainText = malloc( bufferPtrSize * sizeof(uint8_t));
    memset((void *)vplainText, 0x00, bufferPtrSize);
    
    memccpy((void *)vplainText,[bufferdata bytes], 0, bufferdata.length);
    uint8_t iv[kCCBlockSize3DES] = {0, 1, 2, 3, 4, 5, 6, 7};
    
    //NSData *keyData = [self dataFromHexString:key];
    
    ccStatus = CCCrypt(encryptOrDecrypt,
                       kCCAlgorithm3DES,
                       0x0000,//填充方式
                       (const void *)[key bytes],
                       kCCKeySize3DES,
                       iv,
                       vplainText,
                       bufferPtrSize,
                       (void *)bufferPtr,
                       bufferPtrSize,
                       &movedBytes);
    if (ccStatus == kCCSuccess) NSLog(@"SUCCESS");
    else if (ccStatus == kCCParamError) NSLog( @"PARAM ERROR");
    
    
    NSData *result;
    NSLog(@"length = %lu", (unsigned long)movedBytes);
    if (encryptOrDecrypt == kCCDecrypt) {
        result = [NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)movedBytes];
        
    }
    else
    {
        result = [NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)movedBytes];
    }
    
    return result;
}

+(NSData *)DecMode:(NSData *)bufferdata key:(NSData *)key
{
    CCOperation encryptOrDecrypt=kCCDecrypt;
    const void *vplainText;
    size_t plainTextBufferSize;
    plainTextBufferSize = (size_t)[bufferdata length];
    vplainText = (const void *)[bufferdata bytes];
    
    CCCryptorStatus ccStatus;
    uint8_t *bufferPtr = NULL;
    size_t bufferPtrSize = 0;
    size_t movedBytes = 0;
    
    bufferPtrSize = (plainTextBufferSize + kCCBlockSize3DES) & ~(kCCBlockSize3DES - 1);
    bufferPtr = malloc( bufferPtrSize * sizeof(uint8_t));
    memset((void *)bufferPtr, 0x0, bufferPtrSize);
    
    uint8_t iv[kCCBlockSize3DES] = {0, 1, 2, 3, 4, 5, 6, 7};
    
    //NSData *keyData = [self dataFromHexString:key];
    
    ccStatus = CCCrypt(encryptOrDecrypt,
                       kCCAlgorithm3DES,
                       0x0000,//填充方式
                       [key bytes],
                       kCCKeySize3DES,
                       iv,
                       vplainText,
                       plainTextBufferSize,
                       (void *)bufferPtr,
                       bufferPtrSize,
                       &movedBytes);
    if (ccStatus == kCCSuccess) NSLog(@"SUCCESS");
    else if (ccStatus == kCCParamError) NSLog( @"PARAM ERROR");
    
    
    NSData *result;
    NSLog(@"length = %lu", (NSUInteger)movedBytes);
    if (encryptOrDecrypt == kCCDecrypt) {
        result = [NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)movedBytes];
        
    }
    else
    {
        result = [NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)movedBytes];
    }
    
    return result;
}

+ (NSData *)TripleDES:(NSString *)plainText encryptOrDecrypt:(CCOperation)encryptOrDecrypt key:(NSString*)key {
    const void *vplainText;
    size_t plainTextBufferSize;
    
    if (encryptOrDecrypt == kCCDecrypt) //解密
    {
        NSData *EncryptData = [GTMBase64 decodeData:[plainText dataUsingEncoding:NSUTF8StringEncoding]];
        plainTextBufferSize = [EncryptData length];
        vplainText = [EncryptData bytes];
    }
    else //加密
    {
        NSData *data = [plainText dataUsingEncoding:NSUTF8StringEncoding];
        plainTextBufferSize = [data length];
        vplainText = (const void *)[data bytes];
    }
    
    CCCryptorStatus ccStatus;
    uint8_t *bufferPtr = NULL;
    size_t bufferPtrSize = 0;
    size_t movedBytes = 0;
    
    bufferPtrSize = (plainTextBufferSize + kCCBlockSize3DES) & ~(kCCBlockSize3DES - 1);
    bufferPtr = malloc( bufferPtrSize * sizeof(uint8_t));
    memset((void *)bufferPtr, 0x0, bufferPtrSize);
    
    uint8_t iv[kCCBlockSize3DES] = {0, 1, 2, 3, 4, 5, 6, 7};
    
    NSData *keyData = [self dataFromHexString:key];
    
    ccStatus = CCCrypt(encryptOrDecrypt,
                       kCCAlgorithm3DES,
                       0x0000,//填充方式
                       [keyData bytes],
                       kCCKeySize3DES,
                       iv,
                       vplainText,
                       plainTextBufferSize,
                       (void *)bufferPtr,
                       bufferPtrSize,
                       &movedBytes);
    if (ccStatus == kCCSuccess) NSLog(@"SUCCESS");
    else if (ccStatus == kCCParamError) NSLog( @"PARAM ERROR");
    //     else if (ccStatus == kCCBufferTooSmall) NSLog (@"BUFFER TOO SMALL");
    //     else if (ccStatus == kCCMemoryFailure) NSLog (@"MEMORY FAILURE");
    //     else if (ccStatus == kCCAlignmentError) NSLog @"ALIGNMENT";
    //     else if (ccStatus == kCCDecodeError) NSLog @"DECODE ERROR";
    //     else if (ccStatus == kCCUnimplemented) NSLog @"UNIMPLEMENTED";
    
    NSData *result;
    NSLog(@"length = %lu", (NSUInteger)movedBytes);
    if (encryptOrDecrypt == kCCDecrypt) {
        result = [NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)movedBytes];
        
        //                NSString *s1 = [[NSString alloc] initWithData:[result subdataWithRange:NSMakeRange(0, 20)] encoding:NSUTF8StringEncoding];
        //
        //        //        NSString *s2 = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        //                NSLog(@"encodeResult1 = %@", s1);
        //        NSLog(@"encodeResult2 = %@", s2);
        //
        //        result = [[NSString alloc] initWithData:[NSData dataWithBytes:(const void *)bufferPtr
        //                                                                length:(NSUInteger)movedBytes]
        //                                        encoding:NSUTF8StringEncoding];
    }
    else
    {
        result = [NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)movedBytes];
        //        result = [GTMBase64 stringByEncodingData:myData];
    }
    
    return result;
}

+ (NSData *)dataFromHexString: (NSString *) hex {
    const char *chars = [hex UTF8String];
    int i = 0, len = hex.length;
    
    NSMutableData *data = [NSMutableData dataWithCapacity:len / 2];
    char byteChars[3] = {'\0','\0','\0'};
    unsigned long wholeByte;
    
    while (i < len) {
        byteChars[0] = chars[i++];
        byteChars[1] = chars[i++];
        wholeByte = strtoul(byteChars, NULL, 16);
        [data appendBytes:&wholeByte length:1];
    }
    
    return data;
}

@end
