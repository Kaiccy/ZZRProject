//
//  OperationController.m
//  IDCardBluetooth
//
//  Created by YZBookPro on 2018/6/29.
//  Copyright © 2018年 YZBookPro. All rights reserved.
//

#import "OperationController.h"
#import "DeviceListView.h"
#import <HSDZBleTool/HSBleTool.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <HSDZBleTool/certificate.h>
#import "MyPeripheral.h"
#import "HSUpdateApp.h"

@interface OperationController ()<CBCentralManagerDelegate,BR_Callback,DeviceListViewDelegate,CBPeripheralDelegate>
{
    CBCentralManager *centralmanager;
}

@property (weak, nonatomic) IBOutlet UIImageView *imgV;

@property (weak, nonatomic) IBOutlet UILabel *tipL;

@property (weak, nonatomic) IBOutlet UIButton *connectBtn;

@property (weak, nonatomic) IBOutlet UIButton *readCardBtn;

@property (weak, nonatomic) IBOutlet UIButton *breakBtn;

@property (nonatomic, strong) DeviceListView *deviceListV;

@property (nonatomic, strong) NSMutableArray *discoverDevices;
@property (nonatomic, strong) CBPeripheral *peripheral;
//@property (nonatomic, strong) CBCentralManager *centralmanager;

@property (nonatomic, strong) HSBleTool *bleTool;

@property (nonatomic, strong) NSDictionary *idcardInfo;

//@property (nonatomic, strong) MyPeripheral *p; //当前连接的设备
@property (nonatomic, strong) NSString *sam;

@end

@implementation OperationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setViews];
    [self updateVersion];
    
    _discoverDevices = [[NSMutableArray alloc] init];
    
    self.bleTool= [[HSBleTool alloc]init:self];//初始化接口
    self.bleTool.delegate=self;
    
    //将centralmanager 放入一线程,否则无法读取到消息
    dispatch_queue_t centralQueue = dispatch_queue_create("myBLeQueue",DISPATCH_QUEUE_CONCURRENT);
    centralmanager = [[CBCentralManager alloc] initWithDelegate:self
                                                          queue:centralQueue];
    centralmanager.delegate=self;
    
    //扫描设备
//    [self searchBT];
}

- (void)setViews{
    [self setViewCorners:_connectBtn corner:15];
    [self setViewCorners:_readCardBtn corner:15];
    [self setViewCorners:_breakBtn corner:15];
    
    //设备列表
    self.deviceListV = [[DeviceListView alloc] init];
    [self.view addSubview:_deviceListV];
    _deviceListV.delegate = self;
    _deviceListV.hidden = YES;
    [_deviceListV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.mas_equalTo(0);
    }];
}

- (void)setViewCorners:(UIView *)view corner:(CGFloat)corner{
    view.layer.masksToBounds = YES;
    view.layer.cornerRadius = corner;
}

//设置提示信息
- (void)setTipsWithTitle:(NSString *)tipStr tipImg:(NSString *)tipImg{
    dispatch_async(dispatch_get_main_queue(), ^{
        self.tipL.text = tipStr;
        self.imgV.image = [UIImage imageNamed:tipImg];
    });
}

#pragma mark - cbcentralmanagerdelegate
-(void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    if (central.state != CBCentralManagerStatePoweredOn) {
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:[NSString stringWithFormat:@"蓝牙不支持!"] delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil];
            [alertView show];
            [self setTipsWithTitle:@"蓝牙不支持!" tipImg:@"sb"];
        });
    }else {
        dispatch_async(dispatch_get_main_queue(), ^{
         [self setTipsWithTitle:@"蓝牙已连接!" tipImg:@"cg"];
        });
    }
}

-(void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"已经连接");
}

#pragma 扫描到设备后的回调
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI

{
    for (MyPeripheral * pi in _discoverDevices) {
        if  ([[peripheral.identifier UUIDString] isEqualToString:[pi.Peripheral.identifier UUIDString]])
        {
            return;
        }
    }
    if (peripheral!=nil) {
        
        MyPeripheral *per=[MyPeripheral alloc];
        per.Peripheral=peripheral;
        per.advertisementData=advertisementData;
        per.RSSI=RSSI;
        if ([peripheral.name isEqual:@"CVR-100B"]) {
            NSLog(@"peripheral=%@",peripheral);
            NSLog(@"peripheral.name=%@",peripheral.name);
            [_discoverDevices addObject:per];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.deviceListV.deviceArr = self->_discoverDevices;
            });
        }
    }
    
}


#pragma DeviceListViewDelegate
- (void)connectDevice:(NSInteger)row{
    [self.bleTool disconnectBt];
    
    MyPeripheral *p = _discoverDevices[row];
    
    if (@available(iOS 9.0, *)) {
        if (p.Peripheral.state == CBPeripheralStateDisconnected || p.Peripheral.state == CBPeripheralStateDisconnecting) {
            
            [self setTipsWithTitle:@"正在连接..." tipImg:@"sb"];

            dispatch_async(dispatch_get_global_queue(0,0), ^{
                [self.bleTool connectBt:p.Peripheral usingCBManager:self->centralmanager];
            });
        }
    } else {
        // Fallback on earlier versions
        
    }
}

#pragma BR_Callback
-(void)BR_connectResult:(BOOL)isconnected
{
    if (isconnected) {
        // 连接成功
        [self setTipsWithTitle:@"连接成功" tipImg:@"cg"];
        _sam = [self.bleTool readSAM];
        
    }
    else
    {
        [self setTipsWithTitle:@"连接失败" tipImg:@"sb"];
    }
}


#pragma mark - search
-(void)searchBT
{
    NSLog(@"进入搜索外围设备方法");
    [centralmanager scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:@NO}];
} 

#pragma actions

- (IBAction)searchDevice:(UIButton *)sender {
    centralmanager.delegate=self;
    self.bleTool.delegate=self;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self searchBT];
        if (self.deviceListV.deviceArr.count == 0) {
            self.deviceListV.hidden = YES;
            [self setTipsWithTitle:@"未扫描到可连接设备!" tipImg:@"sb"];
        }else{
            
            self.deviceListV.hidden = NO;
            [self setTipsWithTitle:@"有可连接设备!" tipImg:@"cg"];
        }
    });
}

- (IBAction)readCard:(UIButton *)sender {
    [self setTipsWithTitle:@"正在读卡..." tipImg:@"sb"];
    [self didReadIDCardInfo: [self.bleTool readCert]];
}

- (IBAction)breakDevice:(UIButton *)sender {
    
    [self.bleTool disconnectBt];
    self.bleTool.delegate=nil;
    [self setTipsWithTitle:@"已断开连接" tipImg:@"sb"];
}

//读卡
- (void)didReadIDCardInfo:(NSDictionary *)infoDictionary {
    _idcardInfo = infoDictionary;
    if ([_idcardInfo[@"resultFlag"] integerValue] ==0) { // resultFlag=0成功
        
        NSLog(@"=======%@",_idcardInfo);
        
        certificate *resultString = _idcardInfo[@"resultContent"];
        [self uploadCardInfo:resultString];
    }
    else
    {
        [self setTipsWithTitle:_idcardInfo[@"errorMsg"] tipImg:@"sb"];
    }
}

//上传信息
- (void)uploadCardInfo:(certificate *)certificate{

//    NSString *sam = [self.bleTool readSAM];
    
    NSDictionary *dic = @{
                          @"cardnum":certificate.cardNumber,
                          @"name":certificate.partyName,
                          @"sex":certificate.Sex,
                          @"nation":certificate.nation,
                          @"birth":certificate.bornDay,
                          @"address":certificate.certAddress,
                          @"location":certificate.certOrg,
                          @"svalidity":certificate.effDate,
                          @"evalidity":certificate.expDate,
                          @"mac":_sam
                          };
    NSDictionary *params = [ShowTool params:dic];

    NSData *data = UIImagePNGRepresentation(certificate.avatarImage);
    
//    dispatch_async(dispatch_get_global_queue(0, 0), ^{
    
        AFHTTPSessionManager *manager = [[AFHTTPSessionManager manager] initWithBaseURL:[NSURL URLWithString:kUrl(@"addCardinfo")]];
        //证书
        //  设置证书模式
        NSString * cerPath = [[NSBundle mainBundle] pathForResource:@"scadahzsoc" ofType:@"cer"];
        NSData * cerData = [NSData dataWithContentsOfFile:cerPath];
        manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate withPinnedCertificates:[[NSSet alloc] initWithObjects:cerData, nil]];
        //     客户端是否信任非法证书
        manager.securityPolicy.allowInvalidCertificates = YES;
        // 是否在证书域字段中验证域名
        [manager.securityPolicy setValidatesDomainName:NO];
        
        [manager POST:kUrl(@"addCardinfo") parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            
            [formData appendPartWithFileData:data
                                        name:@"img"
                                    fileName:@"pic.jpeg"
                                    mimeType:@"image/jpeg"];
            
        } progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
            NSLog(@"Response: %@", responseObject[@"meg"]);
//            dispatch_async(dispatch_get_main_queue(), ^{
            
                NSInteger retcode = [responseObject[@"retcode"] integerValue];
                if (retcode == 0) {
                    [self setTipsWithTitle:@"读卡成功" tipImg:@"cg"];
                }else{
                    [self setTipsWithTitle:[NSString stringWithFormat:@"%@",responseObject[@"meg"]] tipImg:@"sb"];
                }
                
//            });//主线程
            
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            NSLog(@"Error: %@", error);
            
//            dispatch_async(dispatch_get_main_queue(), ^{
                [self setTipsWithTitle:@"读卡失败" tipImg:@"sb"];
//            });
        }];
//    });
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.bleTool disconnectBt];
}


- (void)didReceiveMemoryWarning {
    [centralmanager stopScan];
    [super didReceiveMemoryWarning];
    
}

//版本更新
- (void)updateVersion{
    //检测版本
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"firstLaunch"]) {
        [HSUpdateApp hs_updateWithAPPID:nil withBundleId:nil block:^(NSString *currentVersion, NSString *storeVersion, NSString *openUrl, BOOL isUpdate) {
            if (isUpdate) {
                [self showAlertViewTitle:@"版本更新" subTitle:[NSString stringWithFormat:@"检测到新版本%@,是否更新？",storeVersion] openUrl:openUrl];
            }else{
                //最新版本则不需要处理
            }
        }];
    }
}

-(void)showAlertViewTitle:(NSString *)title subTitle:(NSString *)subTitle openUrl:(NSString *)openUrl{
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:title message:subTitle preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *sure = [UIAlertAction actionWithTitle:@"更新" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:openUrl] options:@{} completionHandler:^(BOOL success) {
                
            }];
        } else {
            // Fallback on earlier versions
        }
    }];
    [alertVC addAction:cancel];
    [alertVC addAction:sure];
    [self presentViewController:alertVC animated:YES completion:nil];
}

@end
