

var config = {

  // 接口地址
  ajaxUrl: 'http://192.168.0.60/zzrshopOSP/webService',
  imgUrl: 'http://192.168.0.60/zzrshopOSP/upload'

};

module.exports = config;