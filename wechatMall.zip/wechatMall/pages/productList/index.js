// pages/productList/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    listStyleSrc2:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgBAMAAACBVGfHAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAASUExURUdwTJqampeXl5iYmJeXl5eXl1O4rb8AAAAFdFJOUwAc6aa2pMgIbwAAAEVJREFUKM9jYDQKDQ1VFmBggDGEQkFAkQHOMHVkYGAQCWaAM1SBqhkYgxjgjFAGEAhlgDNoIoBhLYbDMJyO4TlqgBEVYgByQDUhHeAroQAAAABJRU5ErkJggg==',
    listStyleSrc:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAWAgMAAADcN3bXAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAJUExURUdwTJmZmZmZmevOPJsAAAACdFJOUwC1zZiKOwAAABZJREFUCNdjCGBbBQIrGeAMagE6mgwA9FYZ5+rL+eoAAAAASUVORK5CYII=',
    siteUrl:'',
    proList:[],
    selectList: [{ name: '综合排序', sortid: ''}, { name: '销量优先', sortid: 'sell_number' }, { name: '价格优先', sortid: 'shop_price' }],
    selectId:0,
    pager: 1,
    pagesize: 10,
    total:0,
    listFlex:true,
    cat_id:'',
    goods_name:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    //console.log(options);
    let cat_id = options.catid? options.catid:'';
    let goods_name = options.goodsname ? options.goodsname : '';
    that.setData({
      siteUrl: app.globalData.imgUrl,
      cat_id: cat_id,
      goods_name: goods_name
    })
    that.getProList();
  },
  select:function(e){
    let that = this;
    let index = e.currentTarget.dataset.index;
    if(index!==that.data.selectId){
      that.setData({
        pager: 1,
        total: 0,
        selectId:index
      })
    }
    that.getProList()
  },
  getProList:function(){
    let that = this;
    let cat_id = that.data.cat_id;
    wx.showLoading({
      title: '正在加载',
    })
    ajax.GET({
      ajaxPoint: '/getGoodsList',
      params: {
        cat_id: cat_id,
        pager: 1,
        pagesize: 10,
        sortid: that.data.selectList[that.data.selectId].sortid,
        goods_name: that.data.goods_name
      },
      success: function (res) {
        wx.hideLoading()
        if (res.data.retcode == 0) {
          let productList = res.data.infolist;
          for (let i = 0; i < productList.length; i++) {
            if (productList[i].goods_service !== 'null' && productList[i].goods_service) {
              productList[i].goods_service.code = productList[i].goods_service.code.split(',')
            }
          }
          that.setData({
            proList: productList,
            total: res.data.total
          })
        }
      }
    })
  },
  errorFunction: function (ev) {
    var _that = this;
    imgError.errImgFun(ev, _that);
  },
  changeList:function(){
    let that = this;
    that.setData({
      listFlex: !that.data.listFlex
    })
  },
  viewGoodsDetail:function(e){
    let goodsid = e.currentTarget.dataset.goodsid;
    wx.navigateTo({
      url: '/pages/proDetail/index?proid=' + goodsid,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    let that = this;
    if (that.data.total>that.data.pager*that.data.pagesize){
      wx.showLoading({
        title: '正在加载',
      })
      that.setData({
        pager:that.data.pager*1+1
      })
      let cat_id = that.data.cat_id;
      ajax.GET({
        ajaxPoint: '/getGoodsList',
        params: {
          cat_id: cat_id,
          pager: that.data.pager,
          pagesize: 10,
          sortid: that.data.selectList[that.data.selectId].sortid,
          goods_name: that.data.goods_name
        },
        success: function (res) {
          wx.hideLoading()
          if (res.data.retcode == 0) {
            let productList = res.data.infolist;
            for (let i = 0; i < productList.length; i++) {
              if (productList[i].goods_service !== 'null' && productList[i].goods_service) {
                productList[i].goods_service.code = productList[i].goods_service.code.split(',')
              }
            }
            that.setData({
              proList: that.data.proList.concat(productList),
              total: res.data.total
            })
          }
        }
      })
    }else{
      wx.showToast({
        icon:'none',
        title: '没有更多了',
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})