// pages/search/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputShowed:false,
    goodsName:'',
    historyList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    that.setData({
      inputShowed:true
    });
    try {
      var value = wx.getStorageSync('search');
      if (value) {
        that.setData({
          historyList: value
        })
      }else{
        console.log('暂无历史记录')
      }
    } catch (e) {
      console.log(2)
    }
    // wx.getStorage({
    //   key: 'search',
    //   success: function (res) {
    //     var hLast = res.data
    //     that.setData({
    //       historyList: hLast
    //     })
    //   }
    // })
  },
  getSearchName:function(e){
    let name = e.detail.value;
    this.setData({
      goodsName: name
    })
  },
  search:function(){
    let that = this;
    console.log(that.data.goodsName);
    if(that.data.goodsName!==''){
      var arr = that.data.historyList;//获取历史记录
      console.log(arr);
      arr.push(that.data.goodsName);
      let arrNew = Array.from(new Set(arr));
      if (arrNew.length>30){
        arrNew.shift()
      }
      wx.setStorage({
        key: "search",
        data: arrNew,
        success:function(){
          wx.redirectTo({
            url: '/pages/productList/index?goodsname=' + that.data.goodsName,
          })
        }
      })
    }else{
      wx.redirectTo({
        url: '/pages/productList/index',
      })
    }
  },
  viewHistory:function(e){
    let that = this;
    let index = e.currentTarget.dataset.index;
    let hisTory = that.data.historyList;
    wx.redirectTo({
      url: '/pages/productList/index?goodsname=' + hisTory[index],
    })
  },
  remove:function(){
    let that= this;
    wx.showModal({
      content: '确定清空历史搜索吗?',
      success:function(res){
        if(res.confirm){
          wx.removeStorage({
            key: 'search',
            success:function(){
              that.setData({
                historyList: []
              })
              that.onLoad();
            }
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})