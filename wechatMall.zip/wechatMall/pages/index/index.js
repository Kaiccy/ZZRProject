//index.js
//获取应用实例
const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')
Page({
  data: {
    adUrl:'',
    aidList:[],//广告列表
    catList:[],//精品分类
    productList:[],//首页推荐产品
    total:0,
    pager:1,
    pagesize:10
  },
  onLoad: function () {
    wx.showLoading({
      title: '正在加载',
    })
    this.getAdList();
    this.getCatList();
    this.getProductList();
    this.setData({
      adUrl: config.imgUrl
    });
  },
  errorFunction: function (ev) {
    var _that = this;
    imgError.errImgFun(ev, _that);
  },
  getAdList:function(){
    let that = this;
    ajax.GET({
      ajaxPoint:'/getAdList',
      params:{
        ad_type:1
      },
      success:function(res){
        if(res.data.retcode==0){
          that.setData({
            aidList:res.data.infolist
          })
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.meg,
          })
        }
      }
    })
  },
  getCatList:function(){
    let that = this;
    ajax.GET({
      ajaxPoint: '/getCatList',
      params: {
        pid: 1, is_recommend: 1
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          that.setData({
            catList: res.data.infolist
          })
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.meg,
          })
        }
      }
    })
  },
  getProductList: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getGoodsList',
      params: {
        pager: 1,
        pagesize: that.data.pagesize,
        sortid: 'ctime',
        sorttype: 'desc',
        is_recommend: '1'
      },
      success: function (res) {
        wx.stopPullDownRefresh();
        wx.hideLoading()
        if (res.data.retcode == 0) {
          var productList = res.data.infolist
          for (var i = 0; i < productList.length;i++){
            if (productList[i].goods_service !== 'null' && productList[i].goods_service){
              productList[i].goods_service.code = productList[i].goods_service.code.split(',')
            }
          }
          that.setData({
            productList: productList,
            total:res.data.total
          })
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.meg,
          })
        }
      }
    })
  },
  onReachBottom:function(){
    let that = this;
    if(that.data.pager*that.data.pagesize<=that.data.total){
      wx.showLoading({
        title: '正在加载',
      })
      let pager = that.data.pager+1;
      ajax.GET({
        ajaxPoint:'/getGoodsList',
        params: {
          pager: pager,
          pagesize: that.data.pagesize,
          sortid: 'ctime',
          sorttype: 'desc',
          is_recommend: '1'
        },
        success: function (res) {
          wx.hideLoading();
          if (res.data.retcode == 0) {
            let productList = that.data.productList;
            that.setData({
              productList: productList.concat(res.data.infolist),
              total: res.data.total,
              pager: pager
            })
          }else{
            wx.showToast({
              icon:'none',
              title: res.data.meg,
            })
          }
        }
      })
    }
  },
  onPullDownRefresh:function(){
    this.getAdList();
    this.getCatList();
    this.getProductList();
  }
})
