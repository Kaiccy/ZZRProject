// pages/orderList/orderList.js

const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    siteUrl:'',
    orderArr:[],
    orderState:['全部','待付款','待发货','待收货','待评价','已完成','已取消'],
    select_state:0,
    total: 0,
    pager: 1,
    pagesize: 10
  },
  getNewOrder:function(e){
    let state = e.currentTarget.dataset.index;
    console.log(state);
    this.getQuestionList(state);
    this.setData({
      select_state:state
    });
  },
  viewDetail:function(e){
    let orderid = e.currentTarget.dataset.orderid;
    wx.navigateTo({
      url: '/pages/orderList/orderInfo/index?orderid=' + orderid,
    })
  },
  delate:function(e){
    let that =this;
   let order_id = e.currentTarget.dataset.orderid;
   wx.showModal({
     content: '确认删除此订单？',
     success:function(res){
       if(res.confirm){
         wx.showLoading({
           title: '正在删除',
         })
         ajax.POST({
           ajaxPoint: '/delOrder',
           params: {
             order_id: order_id
           },
           success: function (resdata) {
             wx.hideLoading();
             if (resdata.data.retcode==0){
               wx.showToast({
                 icon:'none',
                 title: '订单删除成功',
               })
               that.getQuestionList(that.data.select_state)
             }else{
               wx.showToast({
                 icon: 'none',
                 title: '订单删除失败,请重新尝试',
               })
             }
           }
         })
       }
     }
   })
  },
  onSignfor:function(e){
    let that = this;
    let order_id = e.currentTarget.dataset.orderid;
    wx.showModal({
      content: '确认此订单已签收？',
      success:function(res){
        if(res.confirm){
          wx.showLoading({
            title: '请等待',
          })
          ajax.GET({
            ajaxPoint:'/confirmOrder',
            params:{
              order_id: order_id
            },
            success:function(resdata){
              wx.hideLoading();
              if(resdata.data.retcode==0){
                wx.showToast({
                  icon:'none',
                  title: '确认收货成功',
                });
                that.getQuestionList(that.data.select_state)
              }else{
                wx.showToast({
                  icon: 'none',
                  title: resdata.data.meg,
                })
              }
            }
          })
        }
      }
    })
  },
  cancel:function(e){
    let that = this;
    let order_id = e.currentTarget.dataset.orderid;
    wx.showModal({
      content: '确认取消此订单？',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({
            title: '请等待',
          })
          ajax.GET({
            ajaxPoint: '/cancelOrder',
            params: {
              order_id: order_id
            },
            success: function (resdata) {
              wx.hideLoading();
              if (resdata.data.retcode == 0) {
                wx.showToast({
                  icon: 'none',
                  title: '订单已取消',
                });
                that.getQuestionList(that.data.select_state)
              } else {
                wx.showToast({
                  icon: 'none',
                  title: resdata.data.meg,
                })
              }
            }
          })
        }
      }
    })
  },
  onRefund:function(e){
    let that = this;
    let order_id = e.currentTarget.dataset.orderid;
    wx.showModal({
      content: '确认申请退款?',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({
            title: '请等待',
          })
          ajax.GET({
            ajaxPoint: '/cancelOrder',
            params: {
              order_id: order_id
            },
            success: function (resdata) {
              wx.hideLoading();
              if (resdata.data.retcode == 0) {
                wx.showToast({
                  icon: 'none',
                  title: '订单已取消',
                });
                that.getQuestionList(that.data.select_state)
              } else {
                wx.showToast({
                  icon: 'none',
                  title: resdata.data.meg,
                })
              }
            }
          })
        }
      }
    })
  },
  // 请求订单列表
  getQuestionList: function (state) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    if (state==0){
      state = '';
    };
    ajax.GET({
      ajaxPoint: '/getOrderList',
      params: {
        cuser_id: userInfo.id,
        pager: 1,
        order_status: state,
        pagesize: that.data.pagesize
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == 0) {
          let addQsList = res.data.infolist;
          that.setData({
            orderArr: addQsList,
            total: res.data.total
          })
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.meg,
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '正在加载',
    });
    this.setData({
      siteUrl: config.imgUrl
    })
    this.getQuestionList(this.data.select_state);
    var arr = [0, 15, 23, 48, -105, 100, 47, 98];
    var newArr = [];
    for (var i = 0; i < arr.length; i++) {
      newArr.push( Math.abs(arr[i] - 80))
    };
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.getQuestionList();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    if (that.data.pager * that.data.pagesize < that.data.total) {
      wx.showLoading({
        title: '正在加载',
      })
      let pager = that.data.pager + 1;
      var order_status = that.data.select_state;
      if (that.data.select_state==0){
        order_status = ''
      }
      ajax.GET({
        ajaxPoint: '/getOrderList',
        params: {
          cuser_id: userInfo.id,
          pager: pager,
          pagesize: that.data.pagesize,
          order_status: order_status,
        },
        success: function (res) {
          wx.hideLoading();
          if (res.data.retcode == 0) {
            let addQsList = that.data.orderArr;
            that.setData({
              orderArr: addQsList.concat(res.data.infolist),
              total: res.data.total,
              pager: pager
            })
          } else {
            wx.showToast({
              icon: 'none',
              title: res.data.meg,
            })
          }
        }
      })
    }
  }
  
})