// pages/my_address/addAddress/index.js
const app = getApp()
const ajax = require('../../../utils/request.js')
const config = require('../../../config.js')
const imgError = require('../../../utils/imgError.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    region: [],
    mr_address: 0,//默认地址 0--不设置 1---设为默认
    name: '',
    phone: '',
    addDetail: '',
    cityCode: [],
    addressid:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let addid = options.addid;
    let userInfo = wx.getStorageSync('userInfo');
    let that = this;
    that.setData({
      addressid:addid
    })
    ajax.GET({
      ajaxPoint:'/getAddressList',
      params:{
        cuser_id:userInfo.id
      },
      success:function(res){
        if(res.data.retcode==0){
          let addList = res.data.infolist;
          for(var i=0;i<addList.length;i++){
            if (addList[i].address_id == addid){
              that.setData({
                my_address: addList[i].isdefult,
                name: addList[i].consignee,
                addDetail: addList[i].address,
                phone: addList[i].mobile
              })
            }
          }
        }
      }
    })
  },
  getAddName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  getAddPhone: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },
  getAddDetail: function (e) {
    this.setData({
      addDetail: e.detail.value
    })
  },
  bindRegionChange: function (e) {
    console.log(e)
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      region: e.detail.value,
      cityCode: e.detail.code
    })
  },
  selected: function (e) {
    let isMr = e.detail.value;
    if (isMr) {
      this.setData({
        mr_address: 1
      })
    } else {
      this.setData({
        mr_address: 0
      })
    }
  },
  saveAddress: function () {
    let that = this;
    if (that.data.name == '') {
      wx.showToast({
        title: '联系人不能为空',
      })
    } else if (that.data.phone == '') {
      wx.showToast({
        title: '手机号码不能为空',
      })
    }
    else if (that.data.cityCode == '') {
      wx.showToast({
        title: '所在地区不能为空',
      })
    } else if (that.data.getAddDetail == '') {
      wx.showToast({
        title: '详细地址',
      })
    } else {
      let userInfo = wx.getStorageSync('userInfo');
      ajax.GET({
        ajaxPoint: '/editAddress',
        params: {
          cuser_id: userInfo.id,
          name: that.data.name,
          phone: that.data.phone,
          address: that.data.addDetail,
          province: that.data.cityCode[0],
          city: that.data.cityCode[1],
          district: that.data.cityCode[2],
          isdefult: that.data.mr_address,
          address_id: that.data.addressid
        },
        success: function (res) {
          if (res.data.retcode == 0) {
            wx.showToast({
              title: '修改地址成功',
            })
            setTimeout(function(){
              wx.navigateBack({
                delta:1
              })
            },1500)
          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})