// pages/mine/index.js
const isLogin = require('../../utils/login.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isLogin:false,
    userInfo:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    console.log(userInfo);
    if(userInfo){
      that.setData({
        isLogin:true,
        userInfo:userInfo
      })
    }else{
      that.setData({
        isLogin: false
      })
    }
  },
  onShow:function(){
    // let that = this;
    // let userInfo = wx.getStorageSync('userInfo');
    // console.log(userInfo);
    // if (userInfo) {
    //   that.setData({
    //     isLogin: true
    //   })
    // }
  },
  login:function(){
    wx.navigateTo({
      url: '/pages/login/index',
    })
  },
  loginOut:function(){
    let that = this;
    wx.clearStorageSync('userInfo');
    that.onLoad();
  },

  // 收货地址
  viewShdz:function(){
    isLogin.login('/pages/my_address/index')
  },

  // 常见问题
  showCommonProblems: function () {
    isLogin.login('/pages/questionList/questionList')
  },

  // 我的订单
  showOrderList: function () {
    isLogin.login('/pages/orderList/orderList')
  },

  // 修改密码
  goChangePassword: function () {
    isLogin.login('/pages/changePassword/changePassword')
  },

  // 优惠券
  showCouponList: function () {
    isLogin.login('/pages/couponList/couponList')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})