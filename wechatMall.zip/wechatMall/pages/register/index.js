// pages/register/index.js
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phoneYz:'获取验证码',
    canIgetYzm:true,
    loginname:'',
    password:'',
    passwordYz:'',
    phoneYzm:'',
    yzmTime:60,//验证码时长
    openCode:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getSetting({
      success: function (res) {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: function (res) {
              console.log('判断是否授权')
              console.log(res);
            }
          });
        }
      }
    })
  },
  getLoginName: function (e) {
    let that = this;
    that.setData({
      loginname: e.detail.value
    })
  },
  getPassword: function (e) {
    let that = this;
    that.setData({
      password: e.detail.value
    })
  },
  getPasswordYz: function (e) {
    let that = this;
    that.setData({
      passwordYz: e.detail.value
    })
  },
  bindgetuserinfo:function(e){
    let that = this;
    if(e.detail.userInfo){
      wx.login({
        success: res=>{
          var code = res.code;
          console.log(res)
          wx.getUserInfo({
            success(res) {
              const userInfo = res.userInfo
              const nickName = userInfo.nickName
              const avatarUrl = userInfo.avatarUrl
              const gender = userInfo.gender // 性别 0：未知、1：男、2：女
              const province = userInfo.province
              const city = userInfo.city
              const country = userInfo.country
              ajax.POST({
                ajaxPoint: '/addWxInfo',
                params: {
                  code: code,
                  nickname: encodeURI(nickName),
                  headimgurl: avatarUrl,
                  province: province,
                  city: city,
                  country: country,
                  sex: gender
                },
                success: function (res) {
                  if (res.data.retcode == 0) {
                    that.setData({
                      openCode: res.data.openid
                    });
                    that.login()
                  }
                }
              })
            }
          })
          //that.login()
        }
      })
    }else{

    }
  },
  getCode:function(e){
    let that = this;
    that.setData({
      loginYzm: e.detail.value
    })
  },
  loginYzm:function(){
    let that = this;
    let phone = that.data.loginname;
    if (phone!==''){
      if (!(/^1[34578]\d{9}$/.test(phone))){
        wx.showToast({
          icon:'none',
          title: '请输入正确手机号',
          duration:2000
        })
      }else{
        ajax.GET({
          ajaxPoint:'/vPhone',
          params:{
            phone: phone
          },
          success:function(res){
            if (res.data.retcode == 0 && res.data.isexist=='N'){
              ajax.GET({
                ajaxPoint:'/getCode',
                params:{
                  phone: phone
                },
                success:function(res){
                  if(res.data.retcode==0){
                    wx.showToast({
                      icon:'none',
                      title: '短信验证码已发送',
                    });
                    let timer = setInterval(function(){
                      let time = that.data.yzmTime;
                      time--;
                      if(time==0){
                        clearInterval(timer);
                        that.setData({
                          yzmTime: 60,
                          phoneYz:'获取验证码',
                          canIgetYzm:true
                        })
                      }else{
                        that.setData({
                          canIgetYzm:false,
                          yzmTime: time,
                          phoneYz: time+'s后重新获取'
                        })
                      }
                      
                    },1000)
                  }
                }
              })
            }else{
              wx.showModal({
                title: '提示',
                content: '该手机号已被注册,是否找回密码?',
                success:function(res){
                  if(res.confirm){
                    //关闭本页或直接跳转到 找回密码
                  }
                }
              })
            }
          }
        })
      }
    }
  },
  login:function(){
    let that = this;
    if (!(/^1[34578]\d{9}$/.test(that.data.loginname))) {
        wx.showToast({
          icon: 'none',
          title: '请输入正确手机号',
          duration: 2000
        })
      } else if (that.data.password !== that.data.passwordYz) {
        wx.showToast({
          icon: 'none',
          title: '两次密码输入不一致',
          duration: 2000
        })
      } else {
        wx.showLoading({
          title: '正在注册',
        });
      var inviter_id ='';
      if (wx.getStorageSync('inviter_id')){
        inviter_id = wx.getStorageSync('inviter_id')
      }
      wx.showLoading({
        title: '正在注册',
      })
        ajax.GET({
          ajaxPoint: '/reg',
          params: {
            phone: that.data.loginname,
            code: that.data.loginYzm,
            password: that.data.password,
            repassword: that.data.passwordYz,
            openid: that.data.openCode,
            inviter_id: inviter_id
          },
          success:function(res){
            wx.hideLoading();
            if(res.data.retcode==0){
              wx.showToast({
                title: '注册成功',
              });
              setTimeout(function(){
                wx.navigateBack({
                  delta: 1
                })
              },1500)
            }
          }
        })
      }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})