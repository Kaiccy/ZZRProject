// pages/kindClass/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    siteUrl:'',
    kindList:[],//分类列表
    scrollTopNav:0,//分类导航滚动高度
    currentTab:0,//左侧导航已选
    navHeight:0,
    miniKindList:[],//右侧分类列表
    imgFile:'goods_category'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    wx.showLoading({
      title: '正在加载',
    });
    ajax.GET({
      ajaxPoint:'/getCatList',
      params:{
        pid:1
      },
      success:function(res){
        wx.hideLoading();
        if(res.data.retcode==0){
          that.setData({
            kindList:res.data.infolist,
            siteUrl: config.imgUrl
          })
          let cat_id = res.data.infolist[0].cat_id;
          let childNum = res.data.infolist[0].childnum;
          if (childNum==0){
            that.getKindList(cat_id)
          }else{
            that.getMiniKindList(cat_id)
          }
        }else{
          wx.showToast({
            icon: 'none',
            title: res.data.meg,
          })
        }
      }
    });

    const query = wx.createSelectorQuery()
    query.select('#kind-nav-bar').boundingClientRect()
    query.selectViewport().scrollOffset()
    query.exec(function (res) {
      res[0].top       // #the-id节点的上边界坐标
      res[1].scrollTop // 显示区域的竖直滚动位置
      console.log('打印demo的元素的信息', res);
      console.log('打印高度', res[0].height);
      that.setData({
        navHeight: res[0].height
      })
    })
  },
  errorFunction: function (ev) {
    var _that = this;
    imgError.errImgFun(ev, _that);
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    function fn(a,b){
      console.log(this);
    };
    fn(1,2)
  },
  viewProList:function(e){
    let cat_id = e.currentTarget.dataset.catid;
    wx.navigateTo({
      url: '/pages/productList/index?catid='+cat_id,
    })
  },
  viewGoodsDetail:function(e){
    let cat_id = e.currentTarget.dataset.catid;
    wx.navigateTo({
      url: '/pages/proDetail/index?proid='+cat_id,
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  navbarTab:function(e){
    let that = this;
    let currentIndex = e.currentTarget.dataset.index;
    let cat_id = e.currentTarget.dataset.id;
    let childNum = e.currentTarget.dataset.childnum;
    let navHeight = that.data.navHeight;
    var resHeight = 0;
    var query = wx.createSelectorQuery();
    //选择id
    query.select('#kind-nav-bar .item').boundingClientRect(function (rect) {
      //console.log(rect.height)
      resHeight = rect.height;
      var curr = (currentIndex - 1) * resHeight;
      console.log(curr)
      that.setData({
        scrollTopNav: curr,
        currentTab: currentIndex
      })
    }).exec();
    if(childNum==0){
      that.getKindList(cat_id)
    }else{
      that.getMiniKindList(cat_id);
    }
  },
  getKindList: function (cat_id) {
    let that = this;
    wx.showLoading({
      title: '正在加载',
    })
    ajax.GET({
      ajaxPoint: '/getGoodsList',
      params: {
        cat_id: cat_id
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == 0) {
          that.setData({
            miniKindList: res.data.infolist,
            imgFile: 'goods'
          })
        }
      }
    })
  },
  getMiniKindList:function(cat_id){
    let that = this;
    wx.showLoading({
      title: '正在加载',
    })
    ajax.GET({
      ajaxPoint: '/getCatList',
      params: {
        pid: cat_id
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.retcode == 0) {
          that.setData({
            miniKindList: res.data.infolist,
            imgFile: 'goods_category'
          })
        }
      }
    })
  }
})