// pages/orderPage/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
    addressList: [],
    orderList:[],
    address_id:'',
    total_price:0,
    couponList:[],
    coupon:'请选择优惠券',
    couponId:'',
    selectCoupon:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let orderList = wx.getStorageSync('orderList');
    var total_price = 0;
    for(var i=0;i<orderList.length;i++){
      total_price += parseFloat(orderList[i].shop_price) * parseFloat(orderList[i].goods_number)
    }
    total_price = that.toDecimal2(total_price)
    that.setData({
      imgUrl: config.imgUrl,
      orderList: orderList,
      total_price: total_price
    });
  },
  toDecimal2: function (x) {
    var f = parseFloat(x);
    if (isNaN(f)) {
      return false;
    }
    var f = Math.round(x * 100) / 100;
    var s = f.toString();
    var rs = s.indexOf('.');
    if (rs < 0) {
      rs = s.length;
      s += '.';
    }
    while (s.length <= rs + 2) {
      s += '0';
    }
    return s;
  },
  creatOrder:function(){
    let that = this;
    wx.showLoading({
      title: '生成订单中',
    })
    let userInfo = wx.getStorageSync('userInfo');
    let goodsjson = [];
    for(let i = 0;i<that.data.orderList.length;i++){
      goodsjson.push({ goods_id: that.data.orderList[i].goods_id, goods_number: that.data.orderList[i].goods_number, attr_id: that.data.orderList[i].goods_attr_id})
    };
    ajax.POST({
      ajaxPoint:'/addOrder',
      params:{
        cuser_id: userInfo.id,
        address_id: that.data.address_id,
        goodsjson: JSON.stringify(goodsjson),
        ucou_id: that.data.couponId
      },
      success:function(res){
        wx.hideLoading()
        if(res.data.retcode==0){
          wx.showToast({
            title: '订单已生成',
          })
          let orderId = res.data.order_id;
          wx.showLoading({
            title: '调起微信支付',
          })
          ajax.GET({
            ajaxPoint: '/orderPay_wx_mobile',
            params: {
              order_id: orderId
            },
            success: function (res) {
              wx.hideLoading();
              if (res.data.retcode == 0) {
                let wxpayinfo = res.data;
                wx.removeStorage({
                  key: 'orderList',
                  success(resdata) {
                    wx.requestPayment({
                      timeStamp: wxpayinfo.timeStamp,
                      nonceStr: wxpayinfo.nonceStr,
                      package: wxpayinfo.package,
                      signType: wxpayinfo.signType,
                      paySign: wxpayinfo.paySign,
                      success(res) {
                        wx.redirectTo({
                          url: '/pages/orderList/orderList',
                        })
                      },
                      fail(res) {
                        wx.redirectTo({
                          url: '/pages/orderList/orderList',
                        })
                      }
                    })
                  }
                })
              }
            }
          })
        }else{
          wx.showToast({
            icon:'none',
            title: '订单生成失败,请重新尝试',
          })
        }
      }
    })
  },
  getAddress: function () {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    ajax.GET({
      ajaxPoint: '/getAddressList',
      params: {
        cuser_id: userInfo.id
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          that.setData({
            addressList: res.data.infolist
          })
          var total_price;
          for (let i = 0; i < res.data.infolist.length;i++){
            if (res.data.infolist[i].isdefult==1){
              that.setData({
                address_id: res.data.infolist[i].address_id
              })
            }
          }
        }
      }
    })
  },
  selectAddress:function(){
    // wx.navigateTo({
    //   url: '/pages/my_address/index?select=1',
    // })
  },
  chooseCoupon:function(){
    let that =this;
    that.setData({
      selectCoupon:true
    })
  },
  chooseThis:function(e){
    let that = this;
    let couponId = e.currentTarget.dataset.id;
    let couponList = that.data.couponList;
    //先判断此优惠券是否已选, 否则取消选中
    if(couponId == that.data.couponId){
      that.setData({
        couponId: '',
        coupon: '请选择优惠券'
      })
    }else{
      for (let i = 0; i < couponList.length; i++) {
        if (couponList[i].ucou_id == couponId) {
          that.setData({
            couponId: couponId,
            coupon: couponList[i].cou_name
          })
        }
      }
    }
    that.setData({
      selectCoupon:false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that= this;
    that.getAddress();
    that.getCoupon()
  },
  getCoupon:function(){
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    let goodsjson = [];
    for (let i = 0; i < that.data.orderList.length; i++) {
      goodsjson.push({ goods_id: that.data.orderList[i].goods_id, goods_number: that.data.orderList[i].goods_number, attr_id: that.data.orderList[i].goods_attr_id })
    };
    ajax.POST({
      ajaxPoint:'/getValidUserCouponList',
      params:{
        user_id:userInfo.id,
        goodsjson: JSON.stringify(goodsjson)
      },
      success:function(res){
        console.log(res);
        if(res.data.retcode==0){
          that.setData({
            couponList:res.data.infolist
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})