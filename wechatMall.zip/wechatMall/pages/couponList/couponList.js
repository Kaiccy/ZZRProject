// pages/couponList/couponList.js
const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    couponList:[],
    isSelect:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    if (options.select){
      that.setData({
        isSelect:true
      })
    }
  },
  getCoupon:function(e){
    let that = this;
    let couponId = e.currentTarget.dataset.id;
    let couponList = that.data.couponList;
    var pages = getCurrentPages();
    var prevPage = pages[pages.length - 2]; // 上一个页面
    for (let i = 0; i < couponList.length;i++){
      if (couponList[i].id == couponId){
        prevPage.setData({
          coupon: couponList[i].cou_name,
          couponId:couponList[i].id
        });
        wx.navigateBack({
          delta: 1
        });
        return
      }
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this;
    that.getCouponList()
  },
  getCouponList:function(){
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    ajax.GET({
      ajaxPoint:'/getUserCouponList',
      params:{
        user_id:userInfo.id,
      },
      success:function(res){
        console.log(res);
        if(res.data.retcode==0){
          that.setData({
            couponList:res.data.infolist
          })
        }
      }
    })
  },
  // getCoupon:function(e){
  //   let that = this;
  //   let cou_id = e.currentTarget.dataset.id;
  //   let userInfo = wx.getStorageSync('userInfo');
  //   wx.showLoading({
  //     title: '正在领取',
  //   })
  //   ajax.GET({
  //     ajaxPoint:'/addUserCoupon',
  //     params:{
  //       cou_id: cou_id,
  //       user_id:userInfo.id
  //     },
  //     success:function(res){
  //       wx.hideLoading();
  //       if(res.data.retcode==0){
  //         wx.showToast({
  //           title: '领取成功',
  //         });
  //         setTimeout(function(){
  //           that.getCouponList()
  //         },1500)
  //       }else{
  //         wx.showToast({
  //           icon:'none',
  //           title: '领取失败请重新领取',
  //         });
  //       }
  //     }
  //   })
  //   console.log(e);
  // },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})