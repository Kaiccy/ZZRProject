// pages/proDetail/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    adUrl: '',
    proInfo: {},
    skuList: [],
    detailShow: false,
    attrList:[],
    skuBeanList:[],
    haveSkuBean:[],
    infoText: "请选择商品",
    price:0,
    count:0,
    sellPoints:0,
    buyNum:1,//购买数量
    isIphoneX:false,
    sku_way:1 // 商品多属性选择控制  1--加入购物车  2---购买
  },

  /**
   * 生命周期函数--监听页面加载
   */
  viewCart:function(){
    wx.switchTab({
      url: '/pages/cart/index',
    })
  },
  selectSku: function() {
    let that = this;
    that.setData({
      detailShow: true,
      sku_way:2
    })
  },
  onLoad: function(options) {
    let that = this;
    let pro_id = options.proid;
    wx.getSystemInfo({
      success: function (res) {
        wx.showToast({
          title: res.model.search('iPhone X') != -1,
        })
        if (res.model.search('iPhone X') != -1) {
          that.setData({
            isIphoneX: true
          })
        }
      }
    })　
    ajax.GET({
      ajaxPoint: '/getGoodsInfo',
      params: {
        goods_id: pro_id
      },
      success: function(res) {
        if (res.data.retcode == 0) {
          let proInfo = res.data;
          let picList = proInfo.goods_img_info;
          let goods_img_info_original = proInfo.goods_img_info_original;
          proInfo.goods_img_info = picList.split(',');
          proInfo.goods_img_info_original = goods_img_info_original.split(',');
          if (proInfo.goods_service !== 'null' && proInfo.goods_service){
            proInfo.goods_service.code = proInfo.goods_service.code.split(',')
          }
          that.setData({
            adUrl: config.imgUrl,
            proInfo: proInfo,
            price: proInfo.shop_price
          });
          wx.setNavigationBarTitle({
            title: proInfo.goods_name
          })
        }
      }
    });
    ajax.GET({
      ajaxPoint: '/getGoodsAttrList',
      params: {
        goods_id: pro_id
      },
      success: function(res) {
        if (res.data.retcode == 0) {
          let attrList = res.data.infolist;
          for(let i=0;i<attrList.length;i++){
            for(let j=0;j<attrList[i].childlist.length;j++){
              attrList[i].childlist[j]['enable'] = false,
              attrList[i].childlist[j]['select'] = false
            }
          }
          let skuBeanList = res.data.salesattrlist;
          that.setData({
            skuList: res.data,
            attrList: attrList,
            skuBeanList: skuBeanList
          });
          that.onData();
        }
      }
    })
  },
  //初始化选择项
  onData:function(){

    var attrListIn = this.data.attrList;

    //console.log(this.data.attrList, "待扫描 列表清单");
    //console.log(this.data.skuBeanList, "待扫描 库存清单");

    for (var i = 0; i < attrListIn.length; i++) {
      var attrListBig = attrListIn[i];

      //当前类别之外的选择列表
      var attrsOtherSelect = [];
      for (var j = 0; j < attrListIn.length; j++) {
        var attrListSmall = attrListIn[j];
        if (attrListSmall.attr_id != attrListBig.attr_id) {
          for (var k = 0; k < attrListSmall.childlist.length; k++) {
            var attrListSmallAttr = attrListSmall.childlist[k];
            if (attrListSmallAttr.enable && attrListSmallAttr.select) {
              attrsOtherSelect.push(attrListSmallAttr);
            }
          }
        }
      }
      //console.log(attrsOtherSelect, '当前类别之外的选择列表');
      var enableIds = [];

      var skuBeanListIn = this.data.skuBeanList;

      for (var z = 0; z < skuBeanListIn.length; z++) {
        var ism = true;
        var skuBean = skuBeanListIn[z];
        for (var j = 0; j < attrsOtherSelect.length; j++) {
          var enable = false;
          for (var k = 0; k < skuBean.attributeList.length; k++) {

            var goodAttrBean = skuBean.attributeList[k];

            if (attrsOtherSelect[j].pid == goodAttrBean.attributeId
              && attrsOtherSelect[j].attr_id == goodAttrBean.attributeValId) {
              enable = true;
              break;
            }
          }
          ism = enable && ism;
        }

        if (ism) {
          console.log('skuBean');
          console.log(skuBean);
          for (var o = 0; o < skuBean.attributeList.length; o++) {
            var goodAttrBean = skuBean.attributeList[o];

            if (attrListBig.attr_id == goodAttrBean.attributeId) {
              enableIds.push(goodAttrBean.attributeValId);
            }
          }
        }
      }

      //console.log(enableIds, "sku算法 扫描结果");

      var integers = enableIds;
      for (var s = 0; s < attrListBig.childlist.length; s++) {
        var attrItem = attrListBig.childlist[s];
        //console.log(attrItem, '++++赋值前+++++');
        //console.log(integers);
        attrItem.enable = integers.indexOf(attrItem.attr_id.toString()) != -1;
        //console.log(integers.indexOf(attrItem.attr_id.toString()) != -1,attrItem, '++++赋值后+++++');
      }
    }

    // 重新赋值
    this.setData({
      attrList: attrListIn,
      skuBeanList: skuBeanListIn
    })
  },
  onChangeShowState: function (event) {
    var listItem = this.data.attrList;
    var items = listItem[event.currentTarget.dataset.idx];
    var item = items.childlist[event.currentTarget.dataset.index];

    if (!item.enable) {
      return;
    }
    var select = !item.select;
    for (var i = 0; i < items.childlist.length; i++) {
      items.childlist[i].select = false;
    }
    item.select = select;

    // 获取点击属性列表
    var canGetInfo = [];
    for (var skuIndex = 0; skuIndex < listItem.length; skuIndex++) {
      for (var skuIndexIn = 0; skuIndexIn < listItem[skuIndex].childlist.length; skuIndexIn++) {
        if (listItem[skuIndex].childlist[skuIndexIn].enable && listItem[skuIndex].childlist[skuIndexIn].select) {
          canGetInfo.push(listItem[skuIndex].childlist[skuIndexIn]);
        }
      }
    }

    //console.log(canGetInfo, "目前点击的属性");

    var canGetInfoLog = "";

    var skuBeanList = this.data.skuBeanList;

    var haveSkuBean = [];
    // 对应库存清单扫描
    for (var skuBeanIndex = 0; skuBeanIndex < skuBeanList.length; skuBeanIndex++) {
      var iListCount = 0;
      for (var skuBeanIndexIn = 0; skuBeanIndexIn < skuBeanList[skuBeanIndex].attributeList.length; skuBeanIndexIn++) {
        if (canGetInfo.length == skuBeanList[skuBeanIndex].attributeList.length) {
          if (skuBeanList[skuBeanIndex].attributeList[skuBeanIndexIn].attributeValId == canGetInfo[skuBeanIndexIn].attr_id) {
            iListCount++;
          }
        } else {
          canGetInfoLog =  ",";
        }
      }
      if (iListCount == skuBeanList[skuBeanIndex].attributeList.length) {
        haveSkuBean.push(skuBeanList[skuBeanIndex]);
      }
    }

    //console.log(haveSkuBean, "存在于库存清单");
    if (canGetInfo.length==0){
      canGetInfoLog = '请选择商品'
    }else{
      for (var iox = 0; iox < canGetInfo.length; iox++) {
        if (iox == 0) {
          canGetInfoLog = '当前已选择：' + canGetInfo[iox].attr_value + "";
        } else {
          canGetInfoLog += "," + canGetInfo[iox].attr_value;
        }
      }
    }

    if (haveSkuBean.length != 0) {
      //canGetInfoLog += "价钱:" + haveSkuBean[0].shop_price + " 库存量:" + haveSkuBean[0].goods_number;
      let price = haveSkuBean[0].shop_price;
      let count = haveSkuBean[0].goods_number;
      let sellPoints = haveSkuBean[0].id;
      this.setData({
        price: price,
        count: count,
        sellPoints: sellPoints,
        haveSkuBean: haveSkuBean
      })
    }

    // 重新赋值
    this.setData({
      attrList: listItem,
      infoText: canGetInfoLog,
    })

    // 重新sku运算
    this.onData();
  },
  closeSku:function(e){
    let iox = e.target.dataset.close;
    if(iox){
      this.setData({
        detailShow: false
      })
    }
  },
  minus:function(){
    let that = this;
    if(that.data.buyNum==1){
      return;
    }else{
      that.setData({
        buyNum: that.data.buyNum-1
      })
    }
  },
  plus: function () {
    let that = this;
    that.setData({
      buyNum: that.data.buyNum + 1
    })
  },
  getBuyNum:function(e){
    let that = this;
    let detail = e.detail.value;
    if(detail<1){
      that.setData({
        buyNum:1
      })
    }else{
      that.setData({
        buyNum: detail
      })
    }
  },
  addCart:function(){
    let that = this;
    that.setData({
      detailShow: true,
      sku_way:1
    })
  },
  sku_choose_suc:function(){
    //检测是否选择完成
    let that = this;
    let hasBeenSelect = that.data.attrList;
    var selectJson = [];
    for(var i =0;i<hasBeenSelect.length;i++){
      selectJson.push({ 'name': hasBeenSelect[i].attr_tit, 'select': -1})
      for (var j = 0; j < hasBeenSelect[i].childlist.length;j++){
        if (hasBeenSelect[i].childlist[j].select) { //把所有选中的置入 selectJson
          selectJson[i]['select'] = hasBeenSelect[i].childlist[j].attr_id
        }
      }
    }
    var tips = '';
    for (var m = 0; m < selectJson.length;m++){
      console.log(selectJson[m]['select']);
      if (selectJson[m]['select']==-1){
        tips += selectJson[m].name + ' '
      }
    }
    console.log(selectJson,tips)
    if(tips==''){
      let userInfo = wx.getStorageSync('userInfo');
      if (userInfo.id){
        if (that.data.sku_way == 1) {
          wx.showLoading({
            title: '请稍后',
          })
          ajax.GET({
            ajaxPoint: '/addCart',
            params: {
              cuser_id:userInfo.id,
              goods_id: that.data.proInfo.goods_id,
              attids:that.data.haveSkuBean[0].attids,
              goods_number:that.data.buyNum
            },
            success:function(res){
              wx.hideLoading();
              if(res.data.retcode==0){
                that.setData({
                  detailShow:false
                })
                wx.showToast({
                  title: '加入购物车成功',
                })
              }
            }
          })
        } else {
          wx.setStorage({
            key:'order_base_msg',
            data:{
              infoText: that.data.infoText.replace('当前已选择：',''),
              goods_number:that.data.buyNum,
              proInfo: that.data.proInfo,
              price:that.data.price,
              haveSkuBean:that.data.haveSkuBean
            },
            success:function(res){
              wx.navigateTo({
                url: '/pages/orderPage/index',
              })
            }
          })
        }
      }else{
        //未登录则提醒登陆
        wx.navigateTo({
          url: '/pages/login/index',
        })
      }
    }else{
      wx.showToast({
        icon:'none',
        title: '请选择  '+tips,
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    this.setData({
      detailShow:false
    })
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})