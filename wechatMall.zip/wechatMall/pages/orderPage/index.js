// pages/orderPage/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:'',
    addressList:[],
    orderInfo: {},
    address_id:0,
    couponList: [],
    coupon: '请选择优惠券',
    couponId: '',
    selectCoupon: false,
    total_price: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let order_info = wx.getStorageSync('order_base_msg');
    that.setData({
      imgUrl:config.imgUrl,
      orderInfo: order_info,
      total_price: order_info.price
    });
   
  },
  getAddress:function(){
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    ajax.GET({
      ajaxPoint: '/getAddressList',
      params: {
        cuser_id: userInfo.id
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          that.setData({
            addressList: res.data.infolist
          })
          for (let i = 0; i < res.data.infolist.length; i++) {
            if (res.data.infolist[i].isdefult == 1) {
              that.setData({
                address_id: res.data.infolist[i].address_id
              })
            }
          }
        }
      }
    })
  },
  selectAddress: function () {
    wx.navigateTo({
      url: '/pages/my_address/index?select=1',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this;
    that.getAddress();
    that.getCouponList()
  },
  getCouponList:function(){
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    let goodsjson = [{ "goods_id": that.data.orderInfo.haveSkuBean[0].goods_id, "goods_number": that.data.orderInfo.proInfo.goods_number, "attr_id": that.data.orderInfo.haveSkuBean[0].attids }];
    ajax.POST({
      ajaxPoint:'/getValidUserCouponList',
      params:{
        user_id:userInfo.id,
        goodsjson: JSON.stringify(goodsjson)
      },
      success:function(res){
        if(res.data.retcode==0){
          that.setData({
            couponList:res.data.infolist
          })
        }
      }
    })

  },
  chooseCoupon: function () {
    let that = this;
    that.setData({
      selectCoupon: true
    })
  },
  chooseThis: function (e) {
    let that = this;
    let couponId = e.currentTarget.dataset.id;
    let couponList = that.data.couponList;
    //先判断此优惠券是否已选, 否则取消选中
    if (couponId == that.data.couponId) {
      that.setData({
        couponId: '',
        coupon: '请选择优惠券'
      })
    } else {
      for (let i = 0; i < couponList.length; i++) {
        if (couponList[i].ucou_id == couponId) {
          that.setData({
            couponId: couponId,
            coupon: couponList[i].cou_name
          })
        }
      }
    }
    that.setData({
      selectCoupon: false
    })
  },
  creatOrder: function () {
    let that = this;
    wx.showLoading({
      title: '生成订单中',
    })
    let userInfo = wx.getStorageSync('userInfo');
    let goodsjson = [{ "goods_id": that.data.orderInfo.haveSkuBean[0].goods_id, "goods_number": that.data.orderInfo.goods_number, "attr_id": that.data.orderInfo.haveSkuBean[0].attids }];
    ajax.POST({
      ajaxPoint: '/addOrder',
      params: {
        cuser_id: userInfo.id,
        address_id: that.data.address_id,
        goodsjson: JSON.stringify(goodsjson),
        ucou_id: that.data.couponId
      },
      success: function (res) {
        wx.hideLoading()
        if (res.data.retcode == 0) {
          wx.showToast({
            title: '订单已生成',
          })
          let orderId = res.data.order_id;
          wx.showLoading({
            title: '调起微信支付',
          })
          ajax.GET({
            ajaxPoint:'/orderPay_wx_mobile',
            params:{
              order_id: orderId
            },
            success:function(res){
              wx.hideLoading();
              if(res.data.retcode==0){
                let wxpayinfo = res.data;
                wx.removeStorage({
                  key: 'order_base_msg',
                  success(resdata) {
                    wx.requestPayment({
                      timeStamp: wxpayinfo.timeStamp,
                      nonceStr: wxpayinfo.nonceStr,
                      package: wxpayinfo.package,
                      signType: wxpayinfo.signType,
                      paySign: wxpayinfo.paySign,
                      success(res) {
                        wx.redirectTo({
                          url: '/pages/orderList/orderList',
                        })
                      },
                      fail(res) {
                        wx.redirectTo({
                          url: '/pages/orderList/orderList',
                        })
                      }
                    })
                  }
                })
              }
            }
          })
        } else {
          wx.showToast({
            icon: 'none',
            title: '订单生成失败,请重新尝试',
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})