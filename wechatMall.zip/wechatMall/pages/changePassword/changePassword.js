// pages/changePassword/changePassword.js

const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phoneNum:'',
    code:'',
    password:'',
    confirmPassword: ''
  },

  // 手机号
  getPhomeNum: function (e) {
    let that = this;
    that.setData({
      phoneNum: e.detail.value
    })
  },

  //验证码
  getCode: function (e) {
    let that = this;
    that.setData({
      code: e.detail.value
    })
  },

  //密码
  getPassword: function (e) {
    let that = this;
    that.setData({
      password: e.detail.value
    })
  },

  //确认密码
  getConfirmPassword: function (e) {
    let that = this;
    that.setData({
      confirmPassword: e.detail.value
    })
  },

  //发送验证码
  sendCodeAction: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getCode',
      params: {
        phone: that.data.phoneNum
      },
      success: function (res) {
        console.log(res)
        if (res.data.retcode == 0) {
          
        } else {
          wx.showToast({
            title: res.data.meg,
          })
        }
      }
    })
  },

  sureAction: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/resetPwd',
      params: {
        phone: that.data.phoneNum,
        code : that.data.code,
        password : that.data.password,
        repassword : that.data.confirmPassword
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          wx.showToast({
            title: '修改成功',
          })
        } else {
          wx.showToast({
            title: res.data.meg,
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})