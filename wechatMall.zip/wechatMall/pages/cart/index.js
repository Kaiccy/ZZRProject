// pages/cart/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
const config = require('../../config.js')
const imgError = require('../../utils/imgError.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cartList:[],
    imgUrl:'',
    userInfo:[],
    changeBtnsTit: '编辑商品',
    isLogin: false,
    isRemove:false,
    allSellect:false,
    selectNum:0,
    selectPrice:0.00
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      imgUrl:config.imgUrl
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    if (userInfo.id !== undefined) {
      that.getCartList();
      that.setData({
        userInfo: userInfo,
        changeBtnsTit: '编辑商品',
        isLogin: false,
        isRemove: false,
        allSellect: false,
        selectNum: 0,
        selectPrice: 0.00
      })
    }
  },
  changeBtns:function(){
    let that = this;
    if(that.data.isRemove){
      that.setData({
        isRemove:false,
        changeBtnsTit:'编辑商品'
      })
    }else{
      that.setData({
        isRemove: true,
        changeBtnsTit: '完成'
      })
    }
  },
  removePro:function(){
    let that = this;
    let cartList = that.data.cartList;
    var selectId = '';
    for(let i=0;i<cartList.length;i++){
      if (cartList[i].select){
        selectId += cartList[i].id +','
      }
    }
    if (selectId==''){
      wx.showToast({
        icon:'none',
        title: '请选择需要删除的产品',
      })
    }else{
      wx.showLoading({
        title: '正在删除',
      })
      ajax.GET({
        ajaxPoint:'/delCart',
        params:{
          cart_id: selectId
        },
        success:function(res){
          wx.hideLoading();
          if(res.data.retcode==0){
            wx.showToast({
              icon: 'none',
              title: '删除成功',
            })
            that.getCartList();
          }else{
            wx.showToast({
              icon: 'none',
              title: '删除失败,请重新操作',
            })
          }
        }
      })
    }
  },
  setUpOrder:function(){
    let that = this;
    let cartList = that.data.cartList;
    var selectId = '';
    var orderList = [];
    for (let i = 0; i < cartList.length; i++) {
      if (cartList[i].select) {
        selectId += cartList[i].id;
        orderList.push(cartList[i])
      }
    }
    if (selectId == '') {
      wx.showToast({
        icon: 'none',
        title: '请先选择要购买的商品',
      })
    } else {
      wx.setStorage({
        key: 'orderList',
        data: orderList,
        success:function(res){
          wx.navigateTo({
            url: '/pages/order/index',
          })
        }
      })
    }
  },
  getCartList:function(){
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    wx.showLoading({
      title: '正在加载',
    })
    ajax.GET({
      ajaxPoint:'/getCartList',
      params:{
        cuser_id:userInfo.id
      },
      success:function(res){
        wx.hideLoading();
        if (res.data.retcode==0){
          let cartList = res.data.infolist;
          for(let i=0;i<cartList.length;i++){
            cartList[i].select = false
          }
          that.setData({
            cartList:res.data.infolist,
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  minis:function(e){
    console.log(e);
    let goods_number = e.currentTarget.dataset.number;
    let attids = e.currentTarget.dataset.attids;
    let goodsid = e.currentTarget.dataset.goodsid;
    if(goods_number==1){
      return
    }else{
      this.changeCartList(-1, attids, goodsid)
    }
  },
  plus:function(e){
    let goods_number = e.currentTarget.dataset.number;
    let attids = e.currentTarget.dataset.attids;
    let goodsid = e.currentTarget.dataset.goodsid;
    this.changeCartList(1, attids, goodsid)
  },
  changeCartList: function (goods_number, attids, goodsid){
    let that = this;
    wx.showLoading({
      title: '加载中',
    });
    let userInfo = wx.getStorageSync('userInfo');
    ajax.GET({
      ajaxPoint:'/addCart',
      params:{
        cuser_id:userInfo.id,
        goods_id: goodsid,
        attids: attids,
        goods_number: goods_number
      },
      success:function(res){
        wx.hideLoading()
        if(res.data.retcode==0){
          let cartList = that.data.cartList;
          for(let i =0;i<cartList.length;i++){
            if (goodsid == cartList[i].goods_id && attids == cartList[i].goods_attr_id){
              cartList[i].goods_number = cartList[i].goods_number*1 + goods_number;
            }
          }
          that.setData({
            cartList: cartList
          })
          that.selectPrice();
        }else{
          wx.showToast({
            icon:'none',
            title: '添加商品失败',
          })
        }
      }
    })
  },
  checkboxChange:function(e){
    let that = this;
    let index = e.currentTarget.dataset.index;
    let cartList = that.data.cartList;
    cartList[index].select = !cartList[index].select;
    that.setData({
      cartList: cartList
    });
    that.selectPrice()
  },
  selectAll:function(){
    let that = this;
    let cartList = that.data.cartList;
    for (let i = 0; i < cartList.length; i++) {
      if (that.data.allSellect){
        cartList[i].select = false;
      }else{
        cartList[i].select = true;
      }
    }
    that.setData({
      cartList: cartList,
      allSellect: !that.data.allSellect
    });
    that.selectPrice()
  },
  selectPrice:function(){
    let that = this;
    let cartList = that.data.cartList;
    var selectNum = 0;
    var selectPrice = 0;
    for(let i =0;i<cartList.length;i++){
      if (cartList[i].select){
        selectNum +=1;
        selectPrice += parseFloat(cartList[i].shop_price) * parseFloat(cartList[i].goods_number)
      }
    }
    selectPrice = that.toDecimal2(selectPrice);
    if (selectNum == cartList.length){
      that.setData({
        selectNum: selectNum,
        selectPrice: selectPrice,
        allSellect: true
      })
    }else{
      that.setData({
        selectNum: selectNum,
        selectPrice: selectPrice,
        allSellect: false
      })
    }
  },
  toDecimal2:function(x){
    var f = parseFloat(x);
    if (isNaN(f)) {
      return false;
    }
    var f = Math.round(x * 100) / 100;
    var s = f.toString();
    var rs = s.indexOf('.');
    if (rs < 0) {
      rs = s.length;
      s += '.';
    }
    while (s.length <= rs + 2) {
      s += '0';
    }
    return s;
  }
})